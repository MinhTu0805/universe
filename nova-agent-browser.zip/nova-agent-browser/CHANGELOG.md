# CHANGELOG — Nova Agent Browser

## v0.7.0 — 2026-10-11 · Đồng bộ giao diện với Nova Web

Side panel được nâng cấp theo ngôn ngữ thiết kế mới của Nova Web (V7 "Pro skin" → v11). Chỉ thay đổi giao diện — logic agent, background và storage giữ nguyên.

- **Design tokens mới** (`sidepanel/app.css`): bảng màu trung tính giống Nova Web — Dark `#212121 / #181818 / #303030`, Light `#fff / #f9f9f9 / #f3f3f3`; thêm token `--comp`, `--menu`, `--sb-hover`, `--sb-active`, `--bubble`, `--shadow-menu`.
- **Chuyển động thống nhất**: một đường cong `cubic-bezier(.2,0,0,1)`, thời lượng 120/200/320ms; tin nhắn hiện mờ dần + nhích 4px; ba chấm "typing" dạng sóng mượt.
- **Top bar & context bar phẳng**: bỏ viền/blur, trạng thái agent dạng pill nhẹ; chip ngữ cảnh (Trang/DOM/A11y/Bôi đen) dạng viên thuốc viền mảnh.
- **Màn hình trống kiểu hero Nova Web**: căn giữa "Hôm nay làm gì?" + gợi ý dạng chip pill.
- **Composer viên thuốc bo 28px** có bóng đổ mềm; nút đính kèm tròn "+"; nút gửi màu chữ chính (đen/trắng); bộ chọn **Ask | Agent** dạng pill có thumb trượt.
- **Tin nhắn**: bubble người dùng nền xám nhạt bo 22px (thay cho bubble đen); avatar tròn; markdown phân cấp rõ hơn (heading có gạch chân, bảng/code bo 12–13px).
- **Thẻ công cụ, phê duyệt, câu hỏi, kế hoạch**: viền mảnh, nền trong suốt, nút dạng pill.
- **Drawer hội thoại** giống sidebar Nova Web; **Cài đặt / menu / bảng lệnh** dùng bề mặt `--menu`, bo 18–20px, tab và segmented control dạng pill, switch đen/trắng.
- Icon: lịch sử dùng icon sidebar, "Chat mới" dùng icon bút chì (như Nova Web).
- Sửa lỗi: pill trạng thái bị lệch lên khi agent chờ phê duyệt (trùng class `.ask` với thẻ hỏi); tên thương hiệu bị đè khi pill dài.

---

Tài liệu này mô tả toàn bộ thay đổi của bản **v0.6.0** theo đợt nâng cấp: sửa lỗi async/memory-leak, mở rộng LLM providers, Light Mode mặc định, tái thiết kế UI/UX side panel, nút "Lưu thay đổi" + tab Cài đặt cuộn ngang, và hướng dẫn cài terminal bridge chi tiết.

---

## v0.6.0 — 2026-10-09

### 1. Sửa lỗi nền tảng (Background / MV3)

**`background/event-bus.js`**
- `emit()`: bọc từng listener trong `try/catch`; nếu listener trả về Promise thì gắn `.catch()` — **không còn unhandled promise rejection** lan ra service worker.
- `addPort()`: giới hạn tối đa 12 port side panel (vượt quá thì disconnect port cũ nhất) — chống rò rỉ port khi mở/đóng sidebar nhiều lần; dọn `chrome.runtime.lastError` khi disconnect.
- `broadcast()`: duyệt trên bản sao của tập port và xoá port đã chết ngay khi `postMessage` ném lỗi.

**`background/cdp.js`**
- Bản đồ `pending` của Network domain trước đây **không giới hạn → rò rỉ bộ nhớ** trong phiên debug dài. Giờ có `PENDING_CAP = 200` và `PENDING_TTL = 120s`: entry quá hạn/tràn bị dọn trước khi chèn mới.
- Toàn bộ handler `chrome.debugger.onEvent` được bọc `try/catch` để một event lỗi không làm chết luồng CDP.

**`background/storage.js`**
- `persist()` debounce trả về `Promise.resolve()` thay vì `undefined`; luồng ghi không bao giờ ném lỗi ra call-site fire-and-forget.
- Thêm **`flushStore()`**: huỷ debounce timer và ghi thẳng `chrome.storage.local.set(...)` — dùng cho nút "Lưu thay đổi".

**`background/service-worker.js`**
- Mọi command qua port đều được bọc lỗi hai lớp → side panel luôn nhận được response (không treo promise pending).
- Lệnh mới **`flush_settings`**: gọi `flushStore()`, phát `SETTINGS_CHANGED` và trả về `{settings, savedAt}`.
- `chrome.runtime.onMessage` listener bọc `try/catch` ngoài cùng, reply `{ok:false}` khi throw.
- `onInstalled`: mọi `contextMenus.create` đều nuốt `runtime.lastError` — hết cảnh báo đỏ trong console khi cài lại.
- `get_state`: `chrome.storage.session.remove('pendingAction')` có `.catch(() => {})`.

**`background/native-host.js`**
- `exec()` thêm **watchdog**: nếu host không phản hồi sau `min(timeoutSec, 1800)*1000 + 15s`, promise resolve lỗi thay vì **treo vĩnh viễn**.
- `port.postMessage` bọc `try/catch` → dọn pending + ném `NO_HOST` rõ ràng khi bridge chưa cài.
- `cleanup()` huỷ cả watchdog timer.

### 2. Nâng cấp LLM providers (`background/providers.js`)

- **Thêm 2 providers** (tổng 16):
  - **Z.AI (GLM)** — `https://api.z.ai/api/paas/v4`, model `glm-4.6` / `glm-4.5v`.
  - **Qwen (DashScope)** — compatible-mode, model `qwen-plus` / `qwen-vl-max`.
- **Headers bổ sung** theo provider (`EXTRA_HEADERS`): OpenRouter nhận `HTTP-Referer` + `X-Title` (yêu cầu xếp hạng/tracking của OpenRouter), áp dụng cho cả `chat()` và `listModels()`.
- **HTTP 402** → mã lỗi `QUOTA` với thông báo thân thiện (hết quota/credit).
- **Validate cấu hình sớm**: thiếu base URL → `BAD_CONFIG`; thiếu model → `BAD_CONFIG`; `listModels` chặn base rỗng.
- **Chống rò rỉ stream**: cả hai vòng lặp streaming (OpenAI-compatible & Anthropic) đều có `finally { reader.cancel(); reader.releaseLock(); }` — trước đây abort giữa chừng để lại socket/reader treo.
- Nhận diện vision mở rộng: `qwen*-vl`, `glm-4*v`.

### 3. Giao diện mặc định & tái thiết kế UI/UX

- **Light Mode là mặc định** khi cài mới: `storage.js` (`theme: 'light'`), `index.html` (`<html data-theme="light">` chống FOUC), `mock.js`, fallback `'light'` trong `applyTheme`. Dark mode & "Theo hệ thống" vẫn đầy đủ.
- **Mode mặc định**: `agent` (đã có sẵn trong `DEFAULT_SETTINGS`, giữ nguyên).
- **`sidepanel/app.css` viết lại toàn bộ** (light-first):
  - Design tokens oklch: `:root` = Light, `[data-theme="dark"]` phủ lại; `color-scheme` đúng từng theme.
  - Bảng màu sáng kiểu "paper": nền ấm, surface trắng, viền mềm, bóng đổ tinh tế, radius lớn hơn (10–24px).
  - Composer bo tròn 22px + focus ring; topbar blur; bubble user tối màu; avatar có viền; empty state thoáng hơn.
  - Bổ sung style còn thiếu cho `.table-wrap` (bảng markdown cuộn ngang được).
  - Giữ nguyên 100% selector mà `app.js`/`index.html`/`markdown.js` đang dùng.

### 4. Cài đặt: Lưu thay đổi + tab cuộn ngang

- **Nút "Lưu thay đổi" cố định** cuối modal Cài đặt (`.st-foot` sticky):
  - Theo dõi trạng thái dirty: đổi bất kỳ setting nào → hiện "● Có thay đổi — bấm Lưu để ghi ngay".
  - Bấm Lưu → gửi lệnh `flush_settings` → ghi ngay vào `chrome.storage.local` → trạng thái "✓ Đã lưu vào chrome.storage.local" + **toast "Đã lưu cài đặt"**.
  - Lỗi ghi → toast đỏ kèm message.
- **Tab Cài đặt cuộn ngang**: `.tabs` `overflow-x:auto` + `scroll-behavior:smooth`; con lăn chuột dọc tự chuyển thành cuộn ngang; hai mũi tên ‹ › chỉ hiện khi tràn, tự disable ở đầu/cuối; tab đang chọn tự cuộn vào vùng nhìn thấy. **Không cần kéo rộng side panel để thấy hết tab.**
- Thêm icon `chevronLeft` vào `icons.js`.

### 5. Terminal bridge: hướng dẫn & installer

**Trong extension (Cài đặt → Terminal)**
- Thay khối text cũ bằng **hướng dẫn từng bước theo OS** (`.term-guide`): tự nhận diện Windows/macOS/Linux, cho phép chuyển tab OS; mỗi bước có lệnh kèm **nút copy** (`.cmd-chip` + `.copy-btn`).
- Mục **"Lỗi thường gặp"** (`<details>`): Permission denied, Python not found, Registry key missing, host not found, ping timeout — mỗi mục kèm lệnh chẩn đoán/sửa cụ thể.

**`native-host/nova_host.py` (v0.2.0)**
- Thêm chế độ **`--selftest`**: kiểm tra encode/decode native-messaging frame + in thông tin version/OS/Python, exit code 0/1. Installer và người dùng đều chạy được để chẩn đoán.

**`native-host/install.sh` (macOS/Linux)** — viết lại:
- Validate Extension ID đúng chuẩn `^[a-p]{32}$` trước khi làm bất cứ điều gì.
- Kiểm tra `python3` tồn tại và **≥ 3.8** (kèm gợi ý cài đặt theo distro).
- Tự chạy **self-test** sau khi copy host; fail thì dừng và chỉ lệnh chạy tay.
- Thông báo theo bước (✓/⚠/✗), hướng dẫn gỡ cài đặt cuối script.

**`native-host/install.ps1` (Windows)** — viết lại:
- Validate Extension ID `^[a-p]{32}$`; kiểm tra Python (`python`/`py`) ≥ 3.8; tự self-test.
- Đăng ký registry HKCU cho cả **Chrome và Edge** (không cần admin), in đường dẫn `reg query` để kiểm tra.

**`README.md`**
- Mục "Terminal bridge (native host)" viết lại hoàn chỉnh: cách lấy Extension ID, từng bước cho **Windows / macOS / Linux** (mở Terminal/PowerShell, `cd`, `chmod +x`, `-ExecutionPolicy Bypass`), kiểm tra sau cài (`Kiểm tra kết nối` + `--selftest`), và **bảng Troubleshooting** 7 lỗi phổ biến.
- Thêm mục "Có gì mới ở v0.6.0"; cập nhật số providers 14 → 16.

### 6. Khác

- `manifest.json` & `package.json`: version **0.5.0 → 0.6.0**.
- `sidepanel/mock.js`: đồng bộ mặc định light mode, thêm command `flush_settings` (dev/mock mode).
- `npm run build` ✓ · `npm test` → **115 checks, ALL CHECKS PASSED** (manifest, syntax từng file, invariants CSP, 70+ tools registry, unit tests providers/runtime/storage/cdp).

### Danh sách file thay đổi

| File | Thay đổi chính |
|---|---|
| `background/event-bus.js` | Chống unhandled rejection, giới hạn & dọn port |
| `background/cdp.js` | Chống rò rỉ bản đồ pending (cap + TTL), bọc lỗi onEvent |
| `background/storage.js` | `theme: 'light'` mặc định, thêm `flushStore()` |
| `background/service-worker.js` | Bọc lỗi toàn diện, command `flush_settings` |
| `background/native-host.js` | Watchdog chống treo exec, dọn pending khi postMessage lỗi |
| `background/providers.js` | +Z.AI/Qwen, EXTRA_HEADERS, QUOTA/402, BAD_CONFIG, stream cleanup |
| `sidepanel/index.html` | `data-theme="light"`, modal Cài đặt: `.tabs-wrap` + `.st-foot` |
| `sidepanel/app.js` | Dirty-tracking + `flushSettingsNow()`, tab cuộn ngang + mũi tên, `buildTerminalGuide()` theo OS + FAQ |
| `sidepanel/app.css` | Viết lại toàn bộ — light-first, hiện đại, thêm component mới |
| `sidepanel/icons.js` | Thêm `chevronLeft` |
| `sidepanel/mock.js` | Light default + mock `flush_settings` |
| `native-host/nova_host.py` | v0.2.0, thêm `--selftest` |
| `native-host/install.sh` | Validate ID, Python ≥ 3.8, self-test, thông báo rõ ràng |
| `native-host/install.ps1` | Validate ID, Python ≥ 3.8, self-test, registry Chrome + Edge |
| `README.md` | v0.6.0 notes, hướng dẫn terminal bridge + troubleshooting |
| `manifest.json`, `package.json` | version 0.6.0 |
| `CHANGELOG.md` | File này |
