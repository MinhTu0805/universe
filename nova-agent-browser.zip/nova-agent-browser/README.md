# Nova Agent Browser

**See. Understand. Act.** — AI Agent Browser & Computer-Use sidebar cho Chrome (Manifest V3).

Nova nhìn trang web như con người — qua **ảnh chụp màn hình (vision)**, **DOM** và **accessibility tree** — rồi tự thao tác: click, gõ phím, cuộn, kéo thả, điền form, tải file, vẽ canvas, chạy terminal thật trên máy bạn. Mọi hành động rủi ro đều hỏi trước khi thực hiện.

> **v0.7.0** — Giao diện side panel đồng bộ với Nova Web mới: bảng màu trung tính, composer viên thuốc, hero căn giữa, bộ chọn Ask | Agent có thumb trượt. Xem [CHANGELOG](CHANGELOG.md).
>
> **v0.6.0** — Light Mode mặc định · 16 LLM providers (thêm Z.AI, Qwen) · Cài đặt có nút **Lưu thay đổi** cố định + tab cuộn ngang · sửa lỗi rò rỉ bộ nhớ/promise trong background · hướng dẫn cài terminal bridge từng bước theo OS.
>
> Trước đó: v0.3.0 — 81 tools · Thinking Orb (9 trạng thái hoạt hình) · tải tài liệu lên (kéo-thả/dán) · terminal trở thành khả năng AI tự gọi · bộ nhớ dài hạn · chống lặp vòng.

---

## Mục lục

- [Tính năng](#tính-năng)
- [Có gì mới ở v0.6.0](#có-gì-mới-ở-v060)
- [Cài đặt](#cài-đặt)
- [Cấu hình provider (API key)](#cấu-hình-provider-api-key)
- [Terminal bridge (native host)](#terminal-bridge-native-host)
- [Các chế độ hoạt động](#các-chế-độ-hoạt-động)
- [Danh mục công cụ (tools)](#danh-mục-công-cụ-tools)
- [Kiến trúc](#kiến-trúc)
- [Mô hình bảo mật](#mô-hình-bảo-mật)
- [Phím tắt & menu chuột phải](#phím-tắt--menu-chuột-phải)
- [Phát triển (development)](#phát-triển-development)
- [Cấu trúc thư mục](#cấu-trúc-thư-mục)
- [Quyền riêng tư](#quyền-riêng-tư)

---

## Tính năng

**Nhận thức đa tầng (Perception)**
- Ảnh chụp màn hình có hiệu chuẩn toạ độ (viewport / scroll / DPR) cho vision model.
- DOM tương tác: danh sách phần tử click/gõ được kèm `ref`, role, nhãn, toạ độ.
- Accessibility tree: cấu trúc ngữ nghĩa gọn nhẹ, tiết kiệm token.
- **Reader mode**: trích xuất nội dung bài viết chính, loại bỏ boilerplate.
- **Chẩn đoán trang**: console errors, uncaught exception, resource load lỗi, performance timing.

**Hành động đầy đủ (Action)**
- Click / double-click / right-click / hover / focus / scroll / drag & drop.
- Gõ phím framework-safe (React/Vue/Angular), per-char cho autocomplete.
- **Điền form hàng loạt** `browser_fill_form` — nhiều trường trong một lệnh.
- Tab: mở, đóng, chuyển, nhân đôi, **gom nhóm theo domain** (`browser_organize_tabs`).
- Download (URL trực tiếp hoặc bấm nút), upload artifact vào file input.
- Canvas: click/move/drag/draw/select-region/keypress theo toạ độ tương đối — đủ cho computer-use trên editor, map, whiteboard.

**Agentic loop**
- Vòng lặp observe → plan → act → verify; không bao giờ giả định hành động thành công.
- **Kế hoạch trực quan** (`plan_update`): checklist hiển thị live trong khung chat.
- **Loop guard**: phát hiện gọi lặp cùng một hành động → ép đổi chiến lược, tự dừng khi kẹt.
- **Streaming suy luận từng bước** — xem agent "nghĩ" trực tiếp giữa các bước.
- **Bộ nhớ dài hạn** (`memory_save/recall/forget`): nhớ sở thích, ngữ cảnh dự án xuyên hội thoại; tự động recall theo mục tiêu task.
- Giới hạn an toàn: số bước, thời gian chạy, số ảnh chụp mỗi task.
- Tự động fallback sang provider dự phòng khi provider chính lỗi.

**Hệ thống**
- Terminal thật qua native bridge (Python, stdio JSON), stream stdout/stderr live.
- Artifacts: tạo file MD/CSV/JSON/HTML/code, preview & tải xuống, **append** dần cho báo cáo dài.
- Web search (DuckDuckGo, không cần key) + fetch URL thành văn bản sạch.

## Có gì mới ở v0.6.0

| Nhóm | Chi tiết |
|---|---|
| **Light Mode mặc định** | Giao diện sáng hiện đại khi cài mới; vẫn có Dark Mode và chế độ "Theo hệ thống" trong Cài đặt → Giao diện |
| **Cài đặt (Settings)** | Nút **"Lưu thay đổi"** cố định dưới cùng: ghi ngay vào `chrome.storage.local`, hiển thị trạng thái "Có thay đổi / Đã lưu" + toast xác nhận. Thanh tab Cài đặt **cuộn ngang** (kéo ngang / con lăn chuột / mũi tên ‹ ›) — không cần kéo rộng sidebar để thấy hết tab |
| **Providers** | Thêm **Z.AI (GLM-4.6)** và **Qwen (DashScope)** — tổng 16 providers. Sửa rò rỉ stream khi huỷ giữa chừng, mã lỗi `QUOTA` (HTTP 402), kiểm tra cấu hình thiếu base URL/model rõ ràng |
| **Độ ổn định background** | Vá các lỗi async: unhandled promise rejection trong event bus; rò rỉ bộ nhớ (bản đồ `pending` của CDP không giới hạn; port side panel không dọn; reader stream không huỷ khi abort); watchdog cho native-host khi host treo |
| **Terminal bridge** | Hướng dẫn cài đặt **từng bước theo OS ngay trong Cài đặt → Terminal** (Windows/macOS/Linux, kèm nút copy lệnh) + mục Troubleshooting. Installer kiểm tra Extension ID, Python ≥ 3.8 và tự chạy self-test |

## Có gì mới ở v0.3.0

| Nhóm | Chi tiết |
|---|---|
| Thinking Orb | 9 trạng thái hoạt hình vẽ bằng canvas (working, searching, solving, listening, connecting, weaving, composing, breathing, shaping) thay spinner ở status pill, agent bar và bong bóng AI; chữ "Đang suy nghĩ…" có ánh sáng chạy ngang |
| Tải tài liệu lên | Nút kẹp giấy, kéo-thả vào composer, dán ảnh từ clipboard; file văn bản/code đưa thẳng vào ngữ cảnh, ảnh đi qua vision pipeline |
| Terminal = khả năng | Bỏ chế độ Terminal — Nova tự gọi `terminal_execute` giữa task khi cần, output stream live kèm thinking; orb chuyển sang trạng thái "connecting" khi terminal đang chạy |

## Trước đó: v0.2.0

| Nhóm | Chi tiết |
|---|---|
| Công cụ mới (13) | `browser_reader_mode`, `browser_fill_form`, `browser_console_errors`, `browser_performance`, `browser_organize_tabs`, `browser_duplicate_tab`, `memory_save`, `memory_recall`, `memory_forget`, `plan_update`, `artifact_append`, `get_datetime` (+1 nội bộ) |
| Agent runtime | Loop detection (cảnh báo ở lần lặp 3, dừng ở lần 5) · stream suy luận từng bước với fallback tự động · abort signal thật cho mọi request khi bấm Dừng · ngữ cảnh thời gian thực + bộ nhớ liên quan tự nạp vào task |
| Providers | Thêm **Moonshot AI (Kimi)**, **GitHub Models**, **Cerebras** (tổng 14) |
| UI | Plan checklist live · toggle "Stream suy luận" & "Chống lặp vòng" trong Cài đặt → Agent |
| Chất lượng | Sửa validate suite (false positive tự kích hoạt) — `npm test` giờ ALL CHECKS PASSED |

## Cài đặt

Yêu cầu: **Chrome 116+** (hoặc Edge/Brave/Arc bản mới) và **Node.js ≥ 18** (chỉ để build).

```bash
npm run build      # → tạo thư mục dist/
```

1. Mở `chrome://extensions`
2. Bật **Developer mode** (góc phải trên)
3. **Load unpacked** → chọn thư mục `dist/`
4. Ghim extension, nhấn biểu tượng Nova (hoặc `Alt+N`) để mở sidebar

> Không cần build nếu bạn đã có sẵn thư mục `dist/`.

## Cấu hình provider (API key)

Vào **Cài đặt → Providers**, dán key và nhấn **Test** để kiểm tra kết nối (đo latency + liệt kê models).

| Provider | Ghi chú |
|---|---|
| OpenAI, Anthropic, Google Gemini, OpenRouter, xAI (Grok) | Đầy đủ vision + tools |
| **Moonshot AI (Kimi)**, DeepSeek, Mistral, Together, Groq, Cerebras, **Z.AI (GLM)**, **Qwen (DashScope)** | OpenAI-compatible |
| GitHub Models | Dùng GitHub personal access token |
| Ollama, LM Studio | Chạy local, không cần key |
| Custom | Bất kỳ endpoint OpenAI-compatible nào |

- **Provider dự phòng**: tự chuyển khi provider chính lỗi (Cài đặt → Models → Dự phòng).
- **Vision model riêng**: tự dùng khi model chính không hỗ trợ ảnh.
- API key chỉ lưu trong `chrome.storage.local` của trình duyệt — không gửi đi đâu khác ngoài provider tương ứng.

## Terminal bridge (native host)

Terminal **không còn là một chế độ riêng** — đó là khả năng Nova tự gọi (tool `terminal_execute`) khi cần, ở bất kỳ chế độ nào, chạy song song với suy luận. Mặc định tắt; bật ở **Cài đặt → Terminal**, sau đó cài bridge theo hướng dẫn dưới đây (cũng có sẵn ngay trong tab **Terminal** của Cài đặt, kèm nút copy từng lệnh).

Bridge là một Python host chạy local (`native-host/nova_host.py`), giao tiếp với extension qua **native messaging** (stdio + JSON đóng khung 4-byte), có thể huỷ lệnh tức thì khi bạn bấm Dừng. Yêu cầu **Python ≥ 3.8** (không cần thư viện ngoài).

> `<EXTENSION_ID>` lấy ở `chrome://extensions` → bật **Developer mode** → copy ID của Nova Agent Browser (32 ký tự `a-p`). Nếu bạn load lại extension, ID có thể đổi → chạy lại installer.

### Windows 10/11

1. Nhấn `Win + X` → chọn **Terminal** (hoặc **Windows PowerShell**).
2. `cd` tới thư mục `native-host` của project, ví dụ:

   ```powershell
   cd "$env:USERPROFILE\Downloads\nova-agent-browser\native-host"
   ```

3. Chạy installer (cờ `-ExecutionPolicy Bypass` chỉ áp dụng cho lần chạy này):

   ```powershell
   powershell -ExecutionPolicy Bypass -File install.ps1 -ExtensionId <EXTENSION_ID>
   ```

4. Installer sẽ: kiểm tra ID & Python → copy `nova_host.py` vào `%LOCALAPPDATA%\NovaAgent\` → tạo wrapper `nova_host.bat` → ghi manifest `com.nova.agent.host.json` → đăng ký registry **HKCU** cho Chrome & Edge (không cần quyền admin) → tự chạy self-test.

### macOS

1. Mở **Terminal** (`Cmd + Space`, gõ "Terminal") hoặc iTerm2.
2. `cd` tới thư mục `native-host` của project.
3. Cấp quyền thực thi rồi chạy:

   ```bash
   chmod +x install.sh
   ./install.sh <EXTENSION_ID>
   ```

4. Installer copy host vào `~/.nova-agent/`, tạo launcher, ghi manifest và đăng ký vào `~/Library/Application Support/<Browser>/NativeMessagingHosts/` cho Chrome, Chromium, Edge, Brave, Arc (cái nào có profile sẽ được đăng ký).

> Nếu chưa có Python: `brew install python` hoặc tải tại [python.org](https://www.python.org). macOS mới không cài sẵn `python3` ở một số bản — kiểm tra bằng `python3 --version`.

### Linux (Ubuntu/Debian/Fedora/…)

1. Mở terminal (`Ctrl + Alt + T`).
2. `cd` tới thư mục `native-host` của project.
3. Chạy:

   ```bash
   chmod +x install.sh
   ./install.sh <EXTENSION_ID>
   ```

4. Manifest được đăng ký vào `~/.config/<browser>/NativeMessagingHosts/` (google-chrome, chromium, microsoft-edge, Brave).

> Chưa có Python: `sudo apt install python3` (Debian/Ubuntu) hoặc `sudo dnf install python3` (Fedora).

### Kiểm tra sau khi cài

1. Mở Nova Agent → **Cài đặt → Terminal** → bấm **Kiểm tra kết nối** — trạng thái chuyển sang `đã kết nối (pong)` kèm phiên bản host, OS, shell, Python.
2. Hoặc tự chạy self-test:

   ```bash
   # macOS / Linux
   python3 ~/.nova-agent/nova_host.py --selftest
   # → NOVA_HOST_SELFTEST_OK {"version":"0.2.0","os":"...","python":"3.x.x","frame":"ok"}

   # Windows (PowerShell)
   python "$env:LOCALAPPDATA\NovaAgent\nova_host.py" --selftest
   ```

### Troubleshooting

| Lỗi | Nguyên nhân & cách sửa |
|---|---|
| `Permission denied` khi chạy `install.sh` | Chưa cấp quyền thực thi: `chmod +x install.sh` rồi chạy lại. Nếu copy từ USB/zip, quyền thường bị mất. |
| `python3: command not found` / `Không tìm thấy Python` | Cài Python ≥ 3.8 (xem theo OS ở trên). Trên Windows cài từ python.org nhớ tick **"Add python.exe to PATH"**; đã cài rồi thì đóng/mở lại PowerShell. |
| Extension ID không hợp lệ | ID phải đúng 32 ký tự `a-p` — copy lại tại `chrome://extensions` (đừng gõ tay). ID đổi sau khi load lại extension → chạy lại installer với ID mới. |
| `Registry key missing` / không thấy kết nối trên Windows | Kiểm tra: `reg query "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.nova.agent.host"` — phải trỏ tới file manifest trong `%LOCALAPPDATA%\NovaAgent\`. Thiếu thì chạy lại `install.ps1`. |
| `Specified native messaging host not found` | Manifest chưa được đăng ký cho đúng trình duyệt (vd. dùng Brave nhưng chỉ Chrome được đăng ký) hoặc extension ID sai trong `allowed_origins`. Chạy lại installer đúng ID. |
| Ping timeout / host không phản hồi | Chạy self-test như trên. Nếu self-test OK mà vẫn timeout: kiểm tra phần mềm diệt virus chặn `nova_host.bat`/launcher, hoặc đường dẫn Python trong wrapper đã cũ (cài lại Python ở chỗ khác) → chạy lại installer. |
| Lệnh chạy mãi không dừng | Mỗi lệnh có timeout (mặc định 60s, tối đa 30 phút); extension có watchdog riêng và nút **Dừng** huỷ cả process tree. |

## Các chế độ hoạt động

| Chế độ | Dùng khi |
|---|---|
| **Chat** | Hỏi đáp thường, không động vào trang |
| **Ask** | Hỏi về trang hiện tại (đọc-only) |
| **Agent** | Tự động hoá tác vụ web đầy đủ |
| **Computer Use** | Điều khiển theo ảnh màn hình + toạ độ, canvas |
| **Research** | Nghiên cứu đa nguồn: search → đọc → đối chiếu → tổng hợp, xuất artifact |

## Danh mục công cụ (tools)

81 tools, chia theo nhóm — mỗi tool có JSON Schema validate, timeout và kết quả chuẩn hoá `{success, data, error, meta}`:

| Nhóm | Ví dụ |
|---|---|
| `tabs` | list/switch/open/close/**duplicate**/**organize (tab groups)** |
| `browser` | navigate, back/forward, reload, wait_for_element/navigation |
| `dom` | page info, DOM summary, a11y tree, find element/text, links, images, forms, tables, **reader mode**, **console errors**, **performance** |
| `action` | click/dbl/right/hover/focus/type/**fill_form**/key/combo/scroll/drag/select/check/submit |
| `vision` | screenshot viewport/region/element, compare before-after |
| `canvas` | click/move/drag/draw/select-region/scroll/keypress/screenshot |
| `downloads` / `uploads` | download URL hoặc qua nút bấm, upload artifact vào form |
| `files` | artifact_create / read / **append** |
| `terminal` | terminal_execute (stream live), terminal_status |
| `research` | web_search, fetch_url |
| `memory` | **memory_save / memory_recall / memory_forget** |
| `system` | **plan_update**, **get_datetime**, task_complete, ask_user, search_tools |

## Kiến trúc

```
┌──────────────────────────── Chrome ────────────────────────────┐
│                                                                │
│  sidepanel/            background/ (service worker, ES modules)│
│  ┌────────────┐  port  ┌──────────────────────────────────┐    │
│  │ Chat UI,   │◄──────►│ AgentRuntime (observe→plan→act)  │    │
│  │ plan, feed │ events │  ├─ tool-registry (81 tools)     │    │
│  └────────────┘        │  ├─ policy-engine (risk gates)   │    │
│                        │  ├─ providers (16 LLM backends)  │    │
│  content/ (mỗi tab)    │  ├─ storage (settings/memory/…)  │    │
│  ┌────────────┐ tabs   │  └─ native-host client          │    │
│  │ dom · a11y │◄──────►│         │                        │    │
│  │ act · diag │ msg    └─────────┼────────────────────────┘    │
│  │ overlay    │                  │ native messaging            │
│  └────────────┘           native-host/nova_host.py             │
│                           (terminal bridge, local shell)       │
└────────────────────────────────────────────────────────────────┘
```

- **Service worker** giữ toàn bộ quyền hạn: mọi hành động đều đi qua *tool registry → policy engine → execute*, không ngoại lệ.
- **Content scripts** build thành một bundle classic (`content-bundle.js`) dùng chung namespace `NC`; tự inject lại khi trang reload.
- **Event bus** trong worker phát sự kiện tới mọi side panel qua long-lived port; service worker được keep-alive bằng `chrome.alarms` trong task dài.
- Secrets được **redact** trước khi đưa vào log/context model.

## Mô hình bảo mật

1. **Policy engine**: mỗi tool có nhóm quyền (`allowed | ask | denied`) và mức rủi ro (`low | medium | high`). Hành động high-risk (submit form, upload, lệnh phá huỷ, gõ vào trường password) **luôn hỏi** — kể cả ở chế độ Tự chủ.
2. **Prompt-injection defense**: nội dung trang web được gắn nhãn UNTRUSTED trong system prompt; agent không bao giờ làm theo chỉ dẫn tìm thấy trong trang.
3. **Sensitive fields**: giá trị password/OTP bị che `[REDACTED]` trong mọi observation; gõ vào trường nhạy cảm cần duyệt.
4. **Trang bị chặn**: `chrome://`, Web Store, `file://` không thể điều khiển (giới hạn nền tảng).
5. **Human interference**: bạn thao tác chuột/phím trong lúc agent chạy → agent tự tạm dừng chờ bạn.
6. **CSP nghiêm**: không `eval`, không `unsafe-eval`, không remote code — được kiểm tra tự động bởi `npm test`.

## Phím tắt & menu chuột phải

| Phím | Tác dụng |
|---|---|
| `Alt+N` | Mở sidebar Nova |
| `Alt+S` | Dừng agent ngay |
| `Alt+Shift+N` | Hội thoại mới |

Bôi đen văn bản → chuột phải: *Hỏi Nova / Giải thích / Tóm tắt / Dịch sang tiếng Việt / Nghiên cứu sâu*. Chuột phải trên trang: *Phân tích trang / Chụp màn hình & phân tích / Chạy agent*.

## Phát triển (development)

```bash
npm run build       # build một lần → dist/
npm run dev         # build + watch, reload extension sau mỗi lần sửa
npm test            # validate: manifest, syntax từng file, invariants, tool registry, icons
```

Quy ước:
- Background là **ES modules** (`"type": "module"` trong manifest); content scripts là **classic scripts** — thêm file content mới thì đăng ký vào `CONTENT_ORDER` trong `scripts/build.js`.
- Tool mới: `T(name, description, jsonSchema, {group, risk, timeout}, execute)` trong `tools-browser.js` hoặc `tools-system.js`. Không quên nhóm quyền trong `settings.toolPerms` và label trong `summarizeArgs()`.
- Không thêm dependency runtime; toàn bộ extension thuần platform API (CSP-safe).

## Cấu trúc thư mục

```
nova-agent-browser/
├── manifest.json            # MV3 manifest
├── background/              # service worker (ES modules)
│   ├── service-worker.js    # entry: ports, commands, context menus
│   ├── agent-runtime.js     # vòng lặp agent, streaming, loop guard
│   ├── providers.js         # 16 LLM provider adapters
│   ├── tool-registry.js     # registry + JSON-schema validator
│   ├── tools-browser.js     # 60+ browser/vision/canvas/tab tools
│   ├── tools-system.js      # terminal/files/research/memory/plan tools
│   ├── policy-engine.js     # risk gates + approvals
│   ├── storage.js           # settings, conversations, long-term memory
│   ├── system-prompt.js     # prompts theo từng chế độ
│   └── …
├── content/                 # perception + action trong trang
│   ├── dom-inspector.js     # DOM summary, refs, reader mode, tables…
│   ├── accessibility-tree.js
│   ├── interaction.js       # click/type/scroll/drag framework-safe
│   ├── diagnostics.js       # console errors + performance
│   ├── overlay.js/canvas.js/selection.js/content.js
├── sidepanel/               # chat UI (light/dark theme, markdown, plan…)
├── native-host/             # terminal bridge Python + installers
├── scripts/                 # build.js (bundle) · validate.js (test)
└── icons/
```

## Quyền riêng tư

- API key, hội thoại, bộ nhớ: chỉ trong `chrome.storage.local` của trình duyệt bạn.
- Ảnh chụp màn hình & artifacts: chỉ trong bộ nhớ service worker của phiên làm việc.
- Không telemetry, không analytics, không server trung gian. Request duy nhất rời máy là tới LLM provider bạn tự cấu hình.
- Xoá sạch mọi dữ liệu: **Cài đặt → Vùng nguy hiểm → Xoá tất cả**.

---

*Nova Agent Browser — See. Understand. Act.*
