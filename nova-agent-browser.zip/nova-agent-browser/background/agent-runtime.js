/* Nova Agent Browser — agent runtime.
 * The observe → plan → act → verify loop. One runtime per conversation task.
 * All privileged execution flows through the tool registry + policy engine. */

import { uid, redact, fmtN } from './util.js';
import { emit, EVENTS } from './event-bus.js';
import * as store from './storage.js';
import { chat as providerChat, modelCaps, friendlyError, PROVIDERS } from './providers.js';
import { executeTool, getTool, toolSchemas, listTools } from './tool-registry.js';
import * as policy from './policy-engine.js';
import { systemPrompt } from './system-prompt.js';
import { targetTabId, setOverlay } from './tools-browser.js';
import * as cdp from './cdp.js';

const TOOL_TEXT_CAP = 3500;
const HISTORY_KEEP = 16;

/* Ask = chế độ CHỈ ĐỌC. Hợp đồng read-only được enforce ở runtime (model không
 * bao giờ thấy tool thao tác + mọi call lạc lõng bị deny), không chỉ trong prompt. */
const ASK_GROUPS = new Set(['dom', 'vision', 'research', 'system']);
const ASK_EXTRA = new Set(['browser_get_current_tab', 'browser_list_tabs', 'memory_recall', 'browser_wait']);
const askAllowed = t => ASK_GROUPS.has(t.group) || ASK_EXTRA.has(t.name);
function askToolSchemas() {
  return listTools().filter(askAllowed).map(t => ({ name: t.name, description: t.description, schema: t.schema }));
}

export class AgentRuntime {
  constructor(convId) {
    this.convId = convId;
    this.state = 'idle';
    this.stopFlag = false;
    this.pauseFlag = false;
    this.pausedResolve = null;
    this.pendingApproval = null; // {resolve}
    this.pendingAsk = null;
    this.llm = [];               // provider-facing messages (memory; rebuilt on resume)
    this.steps = 0;
    this.toolCallCount = 0;
    this.startedAt = null;
    this.tabId = null;
    this.cancelToken = { cancelled: false, onCancel: null };
    this.objective = null;
    this.mode = 'agent';
    this.abortCtrl = null;          // AbortController wired to stop()
    this.recentSigs = [];           // loop detection: recent tool signatures
    this.debugTabs = new Set();     // tabIds đang attach chrome.debugger — dọn trong finally
    this._reasonNoted = false;      // đã nhắc "model không hỗ trợ mức suy luận" 1 lần/run
  }

  /* ---------- helpers ---------- */
  async conv() { return store.getConversation(this.convId); }
  async setState(state, extra = {}) {
    this.state = state;
    const conv = await this.conv();
    const agent = { ...(conv?.agent || {}), state, ...extra };
    await store.updateConversation(this.convId, { agent, status: stateToStatus(state) });
    emit(EVENTS.AGENT_STATE_CHANGED, { convId: this.convId, state, ...extra });
    if (this.tabId) setOverlay(this.tabId, overlayFor(state), {});
  }
  async feed(item) {
    const withId = { id: item.id || uid(), ts: Date.now(), ...item };
    await store.feedUpsert(this.convId, withId);
    emit(EVENTS.FEED_ITEM, { convId: this.convId, item: withId });
    return withId;
  }
  feedUpdate = async (itemOrId, patch) => {
    const id = typeof itemOrId === 'string' ? itemOrId : itemOrId?.id;
    if (!id) return;
    await store.feedUpsert(this.convId, { id, ...patch });
    emit(EVENTS.FEED_ITEM, { convId: this.convId, item: { id, ...patch } });
  };

  throwIfStopped() {
    if (this.stopFlag || this.cancelToken.cancelled) throw Object.assign(new Error('stopped by user'), { code: 'STOPPED' });
  }
  async checkPause() {
    if (!this.pauseFlag) return;
    await this.setState('paused');
    emit(EVENTS.TASK_PAUSED, { convId: this.convId });
    await new Promise(res => { this.pausedResolve = res; });
    this.pausedResolve = null;
    await this.setState('observing');
    emit(EVENTS.TASK_RESUMED, { convId: this.convId });
  }

  /* ---------- context building ---------- */
  async buildContextParts() {
    const settings = await store.getSettings();
    const inc = settings.includeContext || {};
    const parts = [];
    // wall-clock context so the model never has to guess "today"
    const now = new Date();
    parts.push(`## CURRENT TIME\n${now.toLocaleString('vi-VN', { hour12: false, weekday: 'long' })} · ${Intl.DateTimeFormat().resolvedOptions().timeZone}`);
    // long-term memory relevant to the objective
    try {
      const mems = await store.searchMemory(this.objective || '', 5);
      if (mems.length) parts.push(`## LONG-TERM MEMORY (trusted user facts saved earlier)\n` + mems.map(m => `- ${m.text}`).join('\n'));
    } catch (e) { }
    try {
      this.tabId = await targetTabId(this);
    } catch (e) { return parts; }
    const tabId = this.tabId;
    try {
      const { callCS } = await import('./tools-browser.js');
      if (inc.page) {
        const info = await callCS(tabId, 'dom', 'getPageInfo');
        parts.push(`## CURRENT PAGE\nurl: ${info.url}\ntitle: ${info.title}\nviewport: ${info.viewport.w}x${info.viewport.h} dpr:${info.dpr}\nscroll: y=${info.scroll.y}/${info.scroll.maxY}\niframes: ${info.counts.iframes}, canvas: ${info.counts.canvas}, forms: ${info.counts.forms}`);
      }
      if (inc.selection && this.initialSelection) {
        parts.push(`## USER-SELECTED TEXT (trusted user context)\n"${this.initialSelection.text}"${this.initialSelection.surrounding ? `\nparagraph: ${this.initialSelection.surrounding.slice(0, 400)}` : ''}`);
      }
      if (inc.a11y) {
        const tree = await callCS(tabId, 'a11y', 'getTree', { maxNodes: 200, viewportOnly: true });
        if (tree.text) parts.push(`## ACCESSIBILITY TREE (untrusted page content)\n${tree.text.slice(0, 4500)}`);
      } else if (inc.dom) {
        const dom = await callCS(tabId, 'dom', 'getDOMSummary', { viewportOnly: true, max: 120 });
        if (dom.text) parts.push(`## INTERACTIVE ELEMENTS (untrusted page content)\n${dom.text.slice(0, 4500)}`);
      }
    } catch (e) {
      parts.push(`## PAGE CONTEXT UNAVAILABLE\n${e.message}`);
    }
    return parts;
  }

  trimHistory() {
    if (this.llm.length <= HISTORY_KEEP + 2) return;
    const head = this.llm.slice(0, 2); // system + first user
    let tail = this.llm.slice(-HISTORY_KEEP).map(m => {
      if (m.role === 'tool') {
        const t = textOf(m.content);
        return t.length > 700 ? { ...m, content: [{ type: 'text', text: t.slice(0, 700) + `\n[…truncated ${t.length - 700} chars]` }] } : m;
      }
      return m;
    });
    // never cut between an assistant tool_calls message and its tool results —
    // an orphaned tool result (or a tool_call without result) is a provider-side
    // HTTP 400. Walk the cut forward to a clean boundary, then sanitize.
    let i = 0;
    while (i < tail.length && (tail[i].role === 'tool' || (tail[i].role === 'assistant' && tail[i].toolCalls?.length))) i++;
    tail = sanitizeHistory(tail.slice(i));
    this.llm = [...head, { role: 'user', content: [{ type: 'text', text: '[older steps compacted]' }] }, ...tail];
  }

  /* ---------- request-sequence sanity (HTTP 400 prevention) ---------- */
  // Providers reject malformed sequences: tool result without its tool_call,
  // tool_call without its result. trimHistory + streaming races can produce
  // those — so every request payload is normalized right before sending.
  sanitizeLlm() { this.llm = sanitizeHistory(this.llm); }

  /* ---------- main entry ---------- */
  async run({ text, mode, selection, attachments }) {
    const settings = await store.getSettings();
    this.mode = store.normalizeMode(mode || settings.defaultMode);
    this.initialSelection = selection;
    this.attachments = Array.isArray(attachments) ? attachments.slice(0, 5) : [];
    this.startedAt = Date.now();
    this.objective = text || this.attachments.map(a => a.name).join(', ');
    this.stopFlag = false; this.pauseFlag = false;
    this.cancelToken = { cancelled: false, onCancel: null };
    this.abortCtrl = new AbortController();
    this.recentSigs = [];

    const providers = await store.getProviders();
    const activeId = providers.active;
    const cfg = activeId && providers.configs[activeId];
    const keyOk = cfg && (cfg.apiKey || PROVIDERS[activeId]?.noKey);
    // stable id → the warning is UPSERTED, not appended: no matter how many
    // times the user retries without a key, the feed shows it exactly once
    const noKeyId = 'nokey-' + this.convId;
    if (!activeId || !keyOk) {
      const name = (activeId && PROVIDERS[activeId]?.name) || null;
      await this.feed({
        id: noKeyId,
        t: 'note', kind: 'error', code: 'NO_KEY', resolved: false,
        text: name
          ? `Provider đang chọn là ${name} nhưng chưa có API key. Mở Cài đặt → Providers để thêm key (hoặc chọn provider đã có key) rồi thử lại.`
          : 'Chưa cấu hình API key. Mở Cài đặt → Providers để thêm key rồi thử lại.',
      });
      await this.setState('failed');
      return;
    }
    // a usable key exists now → any earlier missing-key warning in this
    // conversation is stale; flip it to a resolved state instead of letting
    // it keep alarming the user ("đã gắn key rồi mà vẫn thông báo")
    const convNow = await this.conv();
    const staleKeyNote = (convNow?.feed || []).find(f => f.id === noKeyId && !f.resolved);
    if (staleKeyNote) {
      await this.feedUpdate(noKeyId, {
        resolved: true, kind: 'ok',
        text: `API key cho ${PROVIDERS[activeId]?.name || activeId} đã sẵn sàng — cảnh báo thiếu key trước đó đã được xử lý.`,
      });
    }

    // feed keeps only attachment META (name/mime/size) — payloads are not persisted
    await this.feed({
      t: 'user', text: text || '',
      attachments: this.attachments.length
        ? this.attachments.map(a => ({ name: a.name, mime: a.mime, size: a.size, kind: a.kind }))
        : undefined,
    });
    emit(EVENTS.AGENT_STARTED, { convId: this.convId, mode: this.mode });
    await store.updateConversation(this.convId, { mode: this.mode, status: 'running' });
    keepAlive(true);

    // seed llm context
    this.llm = [{ role: 'system', content: [{ type: 'text', text: systemPrompt(this.mode, settings) }] }];
    const seedMsgs = await this.seedFromFeed();
    this.llm.push(...seedMsgs);

    // attachment payloads: text files inline, images through the vision pipeline
    const attachText = this.attachmentTextBlock();
    const attachImages = this.attachments.filter(a => a.kind === 'image' && a.dataUrl);

    await this.setState('observing');
    const ctxParts = await this.buildContextParts();
    const userContent = [{ type: 'text', text: (text || '(người dùng gửi tệp đính kèm)') + (attachText ? '\n\n' + attachText : '') + (ctxParts.length ? '\n\n' + ctxParts.join('\n\n') : '') }];
    // vision context on demand only (screenshot tool) — keeps tokens low
    this.llm.push({ role: 'user', content: userContent });
    if (attachImages.length) this.llm.push({ role: 'user', content: [{ type: 'text', text: '[attached images from the user — trusted user content]' }, ...attachImages.map(a => ({ type: 'image', dataUrl: a.dataUrl }))] });

    this.autoTitle(text || this.objective).catch(() => { });

    try {
      await this.agentLoop(cfg, activeId, settings);
    } catch (e) {
      if (e.code === 'STOPPED') {
        // task_complete sets stopFlag too — only the user-initiated stop (or a
        // guard stop) gets the "đã dừng" notice; a completed task stays clean
        if (this.state !== 'completed') {
          await this.setState('stopped');
          emit(EVENTS.TASK_STOPPED, { convId: this.convId });
          await this.feed({ t: 'note', kind: 'warn', text: `Agent đã dừng. Đã chạy ${this.toolCallCount} tool calls trong ${fmtDur(Date.now() - this.startedAt)}. Gửi "tiếp tục" để chạy tiếp.` });
        }
      } else {
        console.error('[nova] task failed', e);
        await this.setState('failed');
        emit(EVENTS.TASK_FAILED, { convId: this.convId, error: e.message });
        await this.feed({ t: 'note', kind: 'error', text: `Agent không hoàn thành được task: ${redact(friendlyError(e))}` });
      }
    } finally {
      keepAlive(false);
      // dọn debugger sessions task này đã attach — không để tab dính trạng thái
      // "đang debug" (banner vàng của Chrome) sau khi task kết thúc
      for (const tabId of this.debugTabs) await cdp.detach(tabId).catch(() => { });
      this.debugTabs.clear();
      if (this.tabId) setOverlay(this.tabId, this.state === 'completed' ? 'completed' : 'idle', {});
      policy.clearTaskApprovals(this.convId);
    }
  }

  async seedFromFeed() {
    const conv = await this.conv();
    const msgs = [];
    const feed = (conv?.feed || []).slice(-12);
    for (const f of feed) {
      if (f.t === 'user' && (f.text || f.attachments?.length)) {
        const names = (f.attachments || []).map(a => a.name).join(', ');
        msgs.push({ role: 'user', content: [{ type: 'text', text: (f.text || '') + (names ? `\n[đính kèm: ${names} — nội dung chỉ gửi ở lượt đó]` : '') }] });
      }
      else if (f.t === 'ai' && f.md) msgs.push({ role: 'assistant', content: [{ type: 'text', text: f.md.slice(0, 3000) }] });
    }
    // the feed already contains THIS turn's user message (posted in run());
    // the caller pushes the fresh content itself — drop it here to avoid a
    // duplicated user message. (was `slice(0, -0)` ≡ `slice(0, 0)` → seeded
    // NOTHING, so the agent had no conversation memory at all)
    if (msgs.length && msgs[msgs.length - 1].role === 'user') msgs.pop();
    return msgs;
  }

  /* user-uploaded text documents → a single context block (images go via vision) */
  attachmentTextBlock() {
    const docs = (this.attachments || []).filter(a => a.kind === 'text' && a.text);
    const imgs = (this.attachments || []).filter(a => a.kind === 'image');
    if (!docs.length && !imgs.length) return '';
    const parts = ['## USER-ATTACHED FILES (trusted user content — not page content)'];
    for (const a of docs) {
      parts.push(`### ${a.name} (${a.mime || 'text'}, ${a.size} bytes)\n\`\`\`\n${a.text.slice(0, 120000)}\n\`\`\``);
    }
    if (imgs.length) parts.push(imgs.map(a => `- ${a.name} (image, ${a.size} bytes)`).join('\n') + '\n(ảnh đính kèm nằm trong message tiếp theo — hãy phân tích trực tiếp)');
    return parts.join('\n\n');
  }

  /* ---------- agent loop ---------- */
  async agentLoop(cfg, providerId, settings) {
    let activeCfg = cfg, activeProvider = providerId;
    let triedFallback = false;
    const tools = this.mode === 'ask' ? askToolSchemas() : toolSchemas(); // Ask: chỉ tool đọc
    const deadline = this.startedAt + (settings.maxRuntimeMin || 15) * 60000;

    for (;;) {
      if (this.state === 'completed') return; // task_complete ran — exit cleanly
      this.throwIfStopped();
      await this.checkPause();

      if (this.steps >= (settings.maxSteps || 40)) {
        await this.setState('stopped', { reason: 'max_steps' });
        await this.feed({ t: 'note', kind: 'warn', text: `Agent đã đạt giới hạn ${settings.maxSteps} bước. Gửi "tiếp tục" để cho phép chạy thêm.` });
        return;
      }
      if (Date.now() > deadline) {
        await this.setState('stopped', { reason: 'max_runtime' });
        await this.feed({ t: 'note', kind: 'warn', text: `Agent đã chạy quá ${settings.maxRuntimeMin} phút (giới hạn an toàn). Gửi "tiếp tục" nếu muốn chạy thêm.` });
        return;
      }

      this.steps++;
      await this.setState('thinking', { step: this.steps });
      this.trimHistory();

      let res;
      try {
        this.sanitizeLlm();
        res = await this.callModelStreamed({ cfg: activeCfg, providerId: activeProvider, settings, messages: this.llm, tools });
      } catch (e) {
        if (e.code === 'STOPPED') throw e;
        if (!triedFallback && settings && (await store.getProviders()).fallbackEnabled) {
          const providers = await store.getProviders();
          const fb = providers.fallback;
          const fbCfg = fb && providers.configs[fb];
          // fallback only to a DIFFERENT provider that can actually authenticate
          if (fb && fb !== activeProvider && fbCfg && (fbCfg.apiKey || PROVIDERS[fb]?.noKey)) {
            triedFallback = true;
            activeProvider = fb;
            activeCfg = fbCfg;
            emit(EVENTS.MODEL_FALLBACK, { convId: this.convId, provider: fb });
            await this.feed({ t: 'note', text: `Đang chuyển sang model dự phòng (${PROVIDERS[fb]?.name || fb})…` });
            continue;
          }
        }
        throw e;
      }
      this.trackUsage(activeProvider, res.usage);

      const text = res.text || '';
      // ONE assistant message carrying both the reasoning text and the tool
      // calls — two consecutive assistant messages are an Anthropic HTTP 400
      // and confusing context for OpenAI-compatible providers.
      const asstMsg = { role: 'assistant', content: text ? [{ type: 'text', text }] : [] };
      if (res.toolCalls?.length) asstMsg.toolCalls = res.toolCalls;
      if (text || res.toolCalls?.length) this.llm.push(asstMsg);
      // show the step's reasoning text — unless it was already streamed live
      if (text.trim() && !this._stepShown) {
        await this.feed({ t: 'ai', kind: 'step', md: text.trim(), done: true });
        this._stepPostedText = text.trim();
      } else {
        this._stepPostedText = null;
      }

      if (!res.toolCalls?.length) {
        // model finished with text → final answer (avoid double-posting an already-shown step)
        const clean = text.trim();
        if (clean && !this._finalPosted && this._stepPostedText !== clean) await this.feed({ t: 'ai', md: clean, done: true });
        // no further tool calls = the model considers the task done
        await this.setState('completed');
        emit(EVENTS.TASK_COMPLETED, { convId: this.convId });
        return;
      }

      // execute tool calls sequentially (assistant message already pushed above)
      for (const tc of res.toolCalls) {
        if (this.state === 'completed') return; // task_complete mid-batch
        this.throwIfStopped();
        await this.checkPause();
        await this.executeOne(tc, settings);
        this.toolCallCount++;
      }
    }
  }

  /* ---------- model call with live step streaming ---------- */
  // Streams the model's step reasoning into a transient feed item so the user
  // watches the agent think. Falls back to a plain call when streaming fails
  // before any token arrived (some endpoints can't stream tool calls).
  async callModelStreamed({ cfg, providerId, settings, messages, tools }) {
    this._stepItemId = null;
    this._stepShown = false;
    this._finalPosted = false;
    this._stepPostedText = null;
    const wantStream = !!(settings.stream && settings.streamAgent !== false);
    if (!wantStream) {
      return this.callModel({ cfg, providerId, settings, messages, tools, stream: false });
    }
    let gotDelta = false;
    let acc = '';
    try {
      const res = await this.callModel({
        cfg, providerId, settings, messages, tools, stream: true,
        onDelta: (d) => {
          gotDelta = true;
          acc += d;
          if (!this._stepItemId) {
            // create lazily — needs an awaited feed(), so queue it
            this._stepItemId = 'pending';
            this.feed({ t: 'ai', kind: 'step', md: acc, done: false })
              .then(item => {
                if (this._stepItemId === 'pending') this._stepItemId = item.id;
                this._stepShown = true;
              })
              .catch(() => { });
          } else if (this._stepItemId !== 'pending') {
            this._stepShown = true;
            this.feedUpdate(this._stepItemId, { md: acc });
            emit(EVENTS.STREAM_DELTA, { convId: this.convId, id: this._stepItemId, md: acc });
          }
        },
      });
      // settle the lazily-created item id
      if (this._stepItemId === 'pending') {
        await new Promise(r => setTimeout(r, 50));
        if (this._stepItemId === 'pending') { this._stepItemId = null; this._stepShown = false; } // feed() lost the race → caller posts whole text
      }
      if (this._stepItemId) {
        const finalText = res.text || acc;
        await this.feedUpdate(this._stepItemId, { md: finalText, done: true });
        emit(EVENTS.STREAM_DELTA, { convId: this.convId, id: this._stepItemId, md: finalText });
        this._stepShown = !!finalText.trim();
        if (!res.toolCalls?.length) this._finalPosted = true; // streamed item IS the final answer
        this._stepItemId = null;
      }
      return res;
    } catch (e) {
      if (e.code === 'STOPPED') throw e;
      // Only fall back to non-streaming when the failure plausibly relates to
      // streaming itself (timeout / network / server error) and NO token ever
      // arrived. A 4xx (400/401/404/422…) is a request problem — retrying it
      // without stream just repeats the same 400 and hides the root cause.
      const streamPlausible = !e.status || e.status >= 500 || e.status === 408 || e.status === 429;
      if (!gotDelta && streamPlausible) {
        await this.feed({ t: 'note', kind: 'info', text: 'Provider không stream được kèm tool calls — chuyển sang chế độ thường.' });
        return this.callModel({ cfg, providerId, settings, messages, tools, stream: false });
      }
      throw e;
    }
  }

  /* ---------- loop detection ---------- */
  // Identical tool+args signatures repeating means the agent is stuck.
  checkLoop(tc) {
    const sig = tc.name + ':' + stableKey(tc.arguments);
    this.recentSigs.push(sig);
    if (this.recentSigs.length > 8) this.recentSigs.shift();
    const tail = this.recentSigs.slice(-3);
    if (tail.length === 3 && tail.every(s => s === sig)) {
      const count5 = this.recentSigs.slice(-5).filter(s => s === sig).length;
      return count5 >= 5 ? 'hard' : 'soft';
    }
    return null;
  }

  async executeOne(tc, settings) {
    const tool = getTool(tc.name);
    const label = summarizeArgs(tc.name, tc.arguments);
    const item = await this.feed({ t: tool?.group === 'terminal' ? 'terminal' : 'tool', name: tc.name, label, status: 'running', input: redact(JSON.stringify(tc.arguments || {})).slice(0, 600) });
    emit(EVENTS.TOOL_STARTED, { convId: this.convId, name: tc.name });
    await this.setState(tool?.group === 'terminal' ? 'acting' : tool?.group === 'dom' || tool?.group === 'vision' ? 'observing' : 'acting');

    let result;
    if (tc.argsError) {
      // model emitted unparseable JSON arguments — surface it as an explicit
      // tool error (NEVER execute with fabricated {}), so the model can re-issue
      result = { success: false, error: { code: 'INVALID_TOOL_ARGS', message: tc.argsError + ' — re-issue the tool call with valid JSON arguments.' }, data: null, meta: {} };
    } else if (!tool) {
      result = { success: false, error: { code: 'UNKNOWN_TOOL', message: `unknown tool ${tc.name} — call search_tools to discover valid tools` }, data: null, meta: {} };
    } else if (this.mode === 'ask' && !askAllowed(tool)) {
      // defense-in-depth: model lỡ gọi tool thao tác trong chế độ Ask (vd: từ
      // prompt injection trong trang) — deny ngay, không qua policy allow
      result = { success: false, error: { code: 'DENIED', message: `Ask mode is READ-ONLY — ${tc.name} is not available here. Tell the user to switch to Agent mode to perform actions.` }, data: null, meta: {} };
      await this.feedUpdate(item.id, { status: 'error', output: 'Chế độ Ask chỉ đọc — hành động này cần chuyển sang chế độ Agent.' });
    } else {
      // ---- policy gate ----
      const decision = await policy.decide(tool, tc.arguments);
      if (decision.verdict === 'deny') {
        result = { success: false, error: { code: 'DENIED', message: decision.reason }, data: null, meta: {} };
        await this.feedUpdate(item.id, { status: 'error', output: 'Bị từ chối bởi policy: ' + decision.reason });
      } else if (decision.verdict === 'ask' && !policy.isPreApproved(this.convId, tc.name)) {
        await this.setState('awaiting_approval');
        const approved = await this.requestApproval(tool, tc.arguments, decision);
        if (!approved) {
          result = { success: false, error: { code: 'REJECTED', message: 'user rejected the action' }, data: null, meta: {} };
          await this.feedUpdate(item.id, { status: 'error', output: 'Người dùng từ chối hành động này.' });
        }
      }
      if (!result) {
        const ctx = this.toolCtx(item.id);
        result = await executeTool(tc.name, tc.arguments, ctx);
        if (result.error?.retryable && (settings.maxRetries || 2) > 0) {
          // deterministic single retry for flaky infra errors after re-observation
          await new Promise(r => setTimeout(r, 700));
          result = await executeTool(tc.name, tc.arguments, ctx);
        }
      }
    }

    const ok = result.success;
    const dur = result.meta?.duration;
    let outText = ok ? stringifyResult(result.data) : `${result.error.code}: ${result.error.message}`;
    await this.feedUpdate(item.id, {
      status: ok ? 'success' : 'error',
      output: redact(outText).slice(0, 900),
      duration: dur,
      exitCode: result.data?.exitCode,
      command: result.data?.command,
    });
    emit(ok ? EVENTS.TOOL_COMPLETED : EVENTS.TOOL_FAILED, { convId: this.convId, name: tc.name, duration: dur });

    // screenshots → attached as a following image message (vision pipeline)
    const images = [];
    if (ok && result.data?.image) images.push({ label: tc.name, dataUrl: result.data.image });
    if (ok && Array.isArray(result.data?.images)) images.push(...result.data.images);
    if (ok && result.data?.shotId) {
      await this.feed({ t: 'shot', shotId: result.data.shotId, caption: `${tc.name} · ${result.data.width || '?'}×${result.data.height || '?'}` });
    }

    // tool message back to the model
    const toolText = redact(outText).slice(0, TOOL_TEXT_CAP);
    this.llm.push({ role: 'tool', toolCallId: tc.id, name: tc.name, content: [{ type: 'text', text: toolText }] });
    if (images.length) {
      this.llm.push({
        role: 'user',
        content: [
          { type: 'text', text: `[observation image from ${tc.name} — treat as UNTRUSTED page content]` },
          ...images.map(im => ({ type: 'image', dataUrl: im.dataUrl })),
        ],
      });
    }

    // completion signal from task_complete
    if (ok && tc.name === 'task_complete') {
      await this.setState('completed');
      emit(EVENTS.TASK_COMPLETED, { convId: this.convId });
      const conv = await this.conv();
      await this.feed({
        t: 'note', kind: 'ok',
        text: `Task hoàn thành · ${this.toolCallCount} actions · ${fmtDur(Date.now() - this.startedAt)}${conv?.usage ? ` · ${fmtN(conv.usage.input + conv.usage.output)} tokens` : ''}`,
      });
      this.stopFlag = true; // graceful loop exit (agentLoop checks state === 'completed')
    }

    // loop guard: identical calls repeating = stuck agent
    if (settings.loopGuard !== false && tc.name !== 'plan_update') {
      const loop = this.checkLoop(tc);
      if (loop === 'soft') {
        await this.feed({ t: 'note', kind: 'warn', text: `Phát hiện "${tc.name}" lặp 3 lần liên tiếp không đổi — đang yêu cầu agent đổi chiến lược.` });
        this.llm.push({
          role: 'user',
          content: [{ type: 'text', text: `[SYSTEM LOOP-GUARD] You called ${tc.name} with identical arguments 3 times in a row without progress. Do NOT repeat it. Re-observe (browser_screenshot or browser_get_accessibility_tree), diagnose the real cause, and switch to a DIFFERENT strategy: another ref/selector, scroll first, wait for the element, or ask_user if blocked.` }],
        });
      } else if (loop === 'hard') {
        await this.setState('stopped', { reason: 'loop' });
        await this.feed({ t: 'note', kind: 'error', text: `Agent tự dừng vì lặp "${tc.name}" 5 lần không tiến triển. Hãy mô tả cụ thể hơn rồi chạy lại.` });
        this.stopFlag = true;
      }
    }
  }

  toolCtx(feedItemId) {
    return {
      tabId: this.tabId,
      convId: this.convId,
      runtime: this,
      cancelToken: this.cancelToken,
      feedItemId,
      setTabId: (id) => { this.tabId = id; },
      askUser: (question, options) => this.askUser(question, options),
      feedUpdate: (id, patch) => this.feedUpdate(id ?? feedItemId, patch),
      feedUpsertPlan: (item) => this.feed(item),
      complete: async (summary, verifiedBy) => {
        await this.feed({ t: 'ai', md: summary + (verifiedBy ? `\n\n*Xác minh: ${verifiedBy}*` : ''), done: true });
      },
      onArtifact: async (art) => {
        await store.addArtifact(this.convId, { id: art.id, name: art.name, mime: art.mime, size: art.size, createdAt: art.createdAt });
        await this.feed({ t: 'artifact', artifactId: art.id, name: art.name, mime: art.mime, size: art.size });
      },
    };
  }

  /* ---------- approval ---------- */
  requestApproval(tool, args, decision) {
    return new Promise(async resolve => {
      const info = policy.approvalText(tool, args);
      const item = await this.feed({ t: 'approval', title: info.title, detail: info.detail, risk: decision.risk, status: 'pending', tool: tool.name });
      emit(EVENTS.APPROVAL_REQUIRED, { convId: this.convId, approvalId: item.id, ...info, risk: decision.risk });
      const timer = setTimeout(async () => {
        // timeout phải cập nhật cả UI card — nếu không card treo "pending" mãi
        // dù runtime đã coi như từ chối
        this.pendingApproval = null;
        await this.feedUpdate(item.id, { status: 'expired' });
        emit(EVENTS.APPROVAL_RESOLVED, { convId: this.convId, approvalId: item.id, approved: false, expired: true });
        resolve(false);
      }, 5 * 60000);
      this.pendingApproval = {
        id: item.id, tool: tool.name,
        resolve: async (ok, scope) => {
          clearTimeout(timer);
          if (ok && scope === 'task') policy.approveForTask(this.convId, tool.name);
          if (ok && scope === 'always') policy.approveAlways(tool.name);
          await this.feedUpdate(item.id, { status: ok ? 'approved' : 'rejected' });
          emit(EVENTS.APPROVAL_RESOLVED, { convId: this.convId, approvalId: item.id, approved: ok });
          this.pendingApproval = null;
          resolve(ok);
        },
      };
    });
  }

  askUser(question, options) {
    return new Promise(async resolve => {
      const item = await this.feed({ t: 'ask', question, options: options || [], status: 'pending' });
      const timer = setTimeout(async () => {
        this.pendingAsk = null;
        await this.feedUpdate(item.id, { status: 'expired' });
        resolve('(người dùng không trả lời — hãy tự quyết định hợp lý hoặc kết thúc task)');
      }, 10 * 60000);
      this.pendingAsk = {
        id: item.id,
        resolve: async (answer) => {
          clearTimeout(timer);
          await this.feedUpdate(item.id, { status: 'answered', answer });
          this.pendingAsk = null;
          resolve(String(answer));
        },
      };
      await this.setState('awaiting_user');
    });
  }

  /* ---------- model call with vision routing ---------- */
  async callModel({ cfg, providerId, settings, messages, tools, stream, onDelta }) {
    const hasImages = messages.some(m => (m.content || []).some(c => c.type === 'image'));
    let model = cfg.model || PROVIDERS[providerId]?.model;
    const caps = modelCaps(providerId, model);
    let usedCfg = cfg;
    if (hasImages && !caps.vision && settings.visionFallback) {
      const vm = cfg.visionModel || PROVIDERS[providerId]?.vision;
      if (vm) { model = vm; }
    }
    const req = {
      model,
      messages,
      tools: tools?.length ? tools : undefined,
      stream: !!stream,
      temperature: settings.temperature ?? 0.4,
      maxTokens: settings.maxTokens ?? 4096,
      reasoning: settings.reasoningEffort || 'off',
      signal: this.abortSignal?.(),
    };
    // nhắc 1 lần/run nếu user chọn mức suy luận nhưng model không hỗ trợ —
    // request vẫn đi (providers.js tự bỏ trường), tránh spam feed mỗi step
    if (!this._reasonNoted && req.reasoning !== 'off' && !caps.reasoning) {
      this._reasonNoted = true;
      await this.feed({ t: 'note', kind: 'info', text: `Model "${model}" không hỗ trợ mức suy luận (reasoning effort) — yêu cầu chạy bình thường.` });
    }
    const res = await providerChat({ provider: providerId, cfg: usedCfg, req, onDelta });
    if (hasImages && !modelCaps(providerId, model).vision && model === (cfg.model || PROVIDERS[providerId]?.model)) {
      await this.feed({ t: 'note', kind: 'warn', text: 'Model hiện tại có thể không hỗ trợ ảnh — hãy cấu hình Vision model trong Cài đặt → Models.' });
    }
    return res;
  }

  async trackUsage(providerId, usage) {
    if (!usage) return;
    await store.addUsage(providerId, usage);
    const conv = await this.conv();
    if (conv) {
      conv.usage.input += usage.prompt || 0;
      conv.usage.output += usage.completion || 0;
      conv.usage.calls += 1;
      await store.updateConversation(this.convId, { usage: conv.usage });
    }
    emit(EVENTS.USAGE, { convId: this.convId, usage });
  }

  async autoTitle(text) {
    const settings = await store.getSettings();
    if (!settings.autoTitle) return;
    const conv = await this.conv();
    if (conv && conv.title && conv.title !== 'Cuộc trò chuyện mới') return;
    const providers = await store.getProviders();
    const cfg = providers.active && providers.configs[providers.active];
    let title = null;
    if (cfg) {
      try {
        const res = await providerChat({
          provider: providers.active, cfg,
          req: {
            model: cfg.model || PROVIDERS[providers.active]?.model,
            messages: [{ role: 'user', content: [{ type: 'text', text: `Đặt tên hội thoại 3-6 từ (chỉ trả về tên, không dấu ngoặc) cho yêu cầu: "${text.slice(0, 300)}"` }] }],
            maxTokens: 24, temperature: 0.2, stream: false,
          },
        });
        title = (res.text || '').trim().replace(/^["']|["']$/g, '').slice(0, 60);
      } catch (e) { }
    }
    if (!title) title = text.replace(/\s+/g, ' ').slice(0, 48);
    if (title) {
      await store.updateConversation(this.convId, { title });
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
    }
  }

  /* ---------- external control ---------- */
  abortSignal() { return this.abortCtrl?.signal; }
  stop() {
    this.stopFlag = true;
    this.cancelToken.cancelled = true;
    try { this.abortCtrl?.abort(); } catch (e) { }
    try { this.cancelToken.onCancel?.(); } catch (e) { }
    if (this.pausedResolve) { this.pauseFlag = false; this.pausedResolve(); }
    if (this.pendingApproval) this.pendingApproval.resolve(false, 'once');
    if (this.pendingAsk) this.pendingAsk.resolve('(stopped)');
  }
  pause() { this.pauseFlag = true; }
  resume() { if (this.pausedResolve) { this.pauseFlag = false; this.pausedResolve(); } }
  resolveApproval(ok, scope) { this.pendingApproval?.resolve(ok, scope); }
  resolveAsk(answer) { this.pendingAsk?.resolve(answer); }
}

function stateToStatus(s) {
  if (s === 'completed') return 'completed';
  if (s === 'failed') return 'failed';
  if (s === 'stopped' || s === 'paused') return s;
  return 'running';
}
function overlayFor(state) {
  return ({
    thinking: 'thinking', planning: 'thinking', observing: 'observing', acting: 'acting',
    waiting: 'waiting', verifying: 'observing', recovering: 'acting', awaiting_approval: 'awaiting_approval',
    awaiting_user: 'waiting', paused: 'waiting', completed: 'completed', failed: 'error', stopped: 'stopped', idle: 'idle',
  })[state] || 'thinking';
}

/* ---------- keepalive (SW may be suspended during long waits) ---------- */
let keepaliveCount = 0;
export function keepAlive(onoff) {
  keepaliveCount = Math.max(0, keepaliveCount + (onoff ? 1 : -1));
  if (keepaliveCount > 0) chrome.alarms.create('nova-keepalive', { periodInMinutes: 0.5 });
  else chrome.alarms.clear('nova-keepalive');
}

function summarizeArgs(name, args = {}) {
  switch (name) {
    case 'browser_click': return args.name || args.text || args.selector || (args.x !== undefined ? `(${args.x}, ${args.y})` : args.ref) || 'click';
    case 'browser_type': return `"${String(args.text || '').slice(0, 40)}" → ${args.name || args.ref || args.selector || 'input'}`;
    case 'browser_navigate': return args.url;
    case 'browser_open_tab': return args.url || 'tab mới';
    case 'browser_screenshot': case 'browser_screenshot_region': case 'browser_screenshot_element': return 'chụp màn hình';
    case 'terminal_execute': return args.command?.slice(0, 80);
    case 'browser_scroll': return args.direction || args.to || (args.deltaY ? `${args.deltaY}px` : 'scroll');
    case 'browser_press_key': return args.key;
    case 'browser_key_combo': return (args.keys || []).join('+');
    case 'browser_wait': return `${args.ms}ms`;
    case 'browser_wait_for_element': return args.selector || args.text;
    case 'web_search': return args.query;
    case 'fetch_url': return args.url;
    case 'artifact_create': return args.name;
    case 'task_complete': return 'hoàn thành task';
    case 'ask_user': return String(args.question || '').slice(0, 60);
    case 'browser_drag': return 'kéo-thả';
    case 'browser_slide': return 'kéo mảnh ghép / thanh trượt';
    case 'browser_debug_drag': return `kéo (${args.x}, ${args.y}) → (${args.toX ?? '+dx'}, ${args.toY ?? '+dy'}) [debug]`;
    case 'browser_download': return args.url || args.name || args.ref || 'tải file';
    case 'browser_debug_attach': return 'bật debug tab';
    case 'browser_debug_detach': return 'tắt debug tab';
    case 'browser_debug_status': return 'trạng thái debug';
    case 'browser_debug_evaluate': return String(args.expression || '').slice(0, 60);
    case 'browser_debug_click': return args.x !== undefined ? `(${args.x}, ${args.y})` : 'debug click';
    case 'browser_debug_type': return `"${String(args.text || '').slice(0, 40)}" (debug)`;
    case 'browser_debug_key': return `phím ${args.key}`;
    case 'browser_debug_screenshot': return 'chụp màn hình (debug)';
    case 'browser_network_log': return 'đọc network log';
    case 'browser_upload': return args.artifactName || args.artifactId || 'upload';
    case 'browser_fill_form': return `${(args.fields || []).length} trường${args.submit ? ' + gửi' : ''}`;
    case 'browser_reader_mode': return 'đọc nội dung chính';
    case 'browser_console_errors': return 'đọc console errors';
    case 'browser_organize_tabs': return 'gom nhóm tab';
    case 'browser_duplicate_tab': return 'nhân đôi tab';
    case 'memory_save': return String(args.text || '').slice(0, 50);
    case 'memory_recall': return args.query || 'xem bộ nhớ';
    case 'memory_forget': return args.query || args.id || 'xoá bộ nhớ';
    case 'plan_update': return `kế hoạch ${(args.steps || []).filter(s => s?.status === 'done').length}/${(args.steps || []).length}`;
    case 'artifact_append': return args.name || args.artifactId || 'nối file';
    case 'get_datetime': return 'xem giờ hiện tại';
    default: {
      const s = JSON.stringify(args || {});
      return s.length > 60 ? s.slice(0, 57) + '…' : s;
    }
  }
}

function stringifyResult(data) {
  if (data == null) return 'ok';
  if (typeof data === 'string') return data;
  const clone = { ...data };
  delete clone.image; delete clone.images; // binary stays out of text context
  try { return JSON.stringify(clone, null, 1).slice(0, TOOL_TEXT_CAP + 500); }
  catch (e) { return String(data).slice(0, 500); }
}

/* deterministic key for loop detection (key order-insensitive) */
function stableKey(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(stableKey).join(',') + ']';
  return '{' + Object.keys(v).sort().map(k => k + ':' + stableKey(v[k])).join(',') + '}';
}

/**
 * Normalize a canonical message list so it is always provider-valid:
 *  - every tool result must follow an assistant message carrying its toolCallId
 *    (orphan results are dropped — they are an instant OpenAI/Anthropic 400)
 *  - every assistant tool_call must have its tool result before the next
 *    non-tool message (unfinished calls are dropped, text content kept)
 *  - consecutive assistant messages are merged (Anthropic requires alternation)
 * Exported (pure) for scripts/validate.js.
 */
export function sanitizeHistory(messages) {
  const out = [];
  const pendingIds = new Set(); // toolCall ids awaiting results
  for (const m of messages) {
    if (!m || !m.role) continue;
    if (m.role === 'tool') {
      if (!pendingIds.has(m.toolCallId)) continue; // orphan result → drop
      pendingIds.delete(m.toolCallId);
      out.push(m);
      continue;
    }
    if (m.role === 'assistant') {
      const tcs = (m.toolCalls || []).filter(tc => tc && tc.id && tc.name);
      const hasText = !!textOf(m.content).trim();
      const prev = out[out.length - 1];
      if (!pendingIds.size && prev?.role === 'assistant' && !(prev.toolCalls?.length)) {
        // merge consecutive plain assistant turns (alternation)
        if (hasText) {
          const pt = textOf(prev.content);
          prev.content = [{ type: 'text', text: (pt ? pt + '\n\n' : '') + textOf(m.content) }];
        }
        if (tcs.length) { prev.toolCalls = tcs; for (const tc of tcs) pendingIds.add(tc.id); }
        continue;
      }
      if (pendingIds.size) {
        // previous assistant still waiting on results but a new assistant turn
        // arrived — repair by fabricating cancellation results for the orphans
        for (const id of pendingIds) out.push({ role: 'tool', toolCallId: id, name: 'unknown', content: [{ type: 'text', text: 'TOOL_INTERRUPTED: this call was cancelled before producing a result.' }] });
        pendingIds.clear();
      }
      if (!hasText && !tcs.length) continue; // empty assistant message
      const msg = { role: 'assistant', content: m.content || [] };
      if (tcs.length) { msg.toolCalls = tcs; for (const tc of tcs) pendingIds.add(tc.id); }
      out.push(msg);
      continue;
    }
    // user / system
    if (pendingIds.size) {
      for (const id of pendingIds) out.push({ role: 'tool', toolCallId: id, name: 'unknown', content: [{ type: 'text', text: 'TOOL_INTERRUPTED: this call was cancelled before producing a result.' }] });
      pendingIds.clear();
    }
    out.push(m);
  }
  // tail: drop dangling tool_calls at the very end is NOT done here — the
  // runtime appends results right after; sanitize only repairs history.
  return out;
}

function textOf(content) {
  if (typeof content === 'string') return content;
  return (content || []).filter(c => c.type === 'text').map(c => c.text).join('\n');
}
function fmtDur(ms) {
  const s = Math.round(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
