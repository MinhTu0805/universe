/* Nova Agent Browser — in-memory artifact + screenshot stores.
 * Content lives in the service worker; metadata persists in conversations.
 * Screenshots are fetched by the side panel on demand (get_shot). */

import { uid } from './util.js';

const artifacts = new Map(); // id -> {id, convId, name, mime, text?, base64?, size, createdAt}
const shots = new Map();     // id -> {id, dataUrl, meta, createdAt}
const MAX_SHOTS = 40;

export function putArtifact(a) {
  const art = { id: a.id || uid(), createdAt: Date.now(), ...a };
  art.size = a.size ?? (a.text?.length ?? (a.base64 ? Math.round(a.base64.length * 0.75) : 0));
  artifacts.set(art.id, art);
  if (artifacts.size > 120) artifacts.delete(artifacts.keys().next().value);
  return art;
}
export function getArtifact(id) { return artifacts.get(id); }
export function findArtifactByName(name) {
  for (const a of [...artifacts.values()].reverse()) if (a.name === name) return a;
  return null;
}

export function putShot(dataUrl, meta = {}) {
  const id = 's' + uid();
  shots.set(id, { id, dataUrl, meta, createdAt: Date.now() });
  while (shots.size > MAX_SHOTS) shots.delete(shots.keys().next().value);
  return id;
}
export function getShot(id) { return shots.get(id); }
