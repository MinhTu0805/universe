/* Nova Agent Browser — chrome.debugger (CDP) control plane.
 * "Chế độ debug" của Chrome cho AI: attach vào tab rồi điều khiển ở mức
 * giao thức DevTools — evaluate JS, input events THẬT (trusted), chụp tab
 * nền không cần active, theo dõi network. Chrome hiển thị thanh "đang debug"
 * khi attach — đó là hành vi chuẩn của platform, không thể ẩn.
 *
 * Master switch: settings.debuggerEnabled (Cài đặt → Trình duyệt).
 * Mọi tool CDP thuộc group 'cdp', mặc định policy = ask. */

import { getSettings } from './storage.js';
import { emit, EVENTS } from './event-bus.js';

const PROTOCOL = '1.3';
const NET_CAP = 60;
const PENDING_CAP = 200;      // requests that never finish (aborted preflights, streams) must not accumulate forever
const PENDING_TTL = 120000;   // …nor live longer than 2 minutes

const attached = new Map(); // tabId -> { attachedAt, net: [], pending: Map(requestId -> entry) }

const hasChrome = typeof chrome !== 'undefined' && !!chrome.debugger;

const dbgErr = (code, message) => Object.assign(new Error(message), { code });

export function isAttached(tabId) { return attached.has(tabId); }
export function attachedIds() { return [...attached.keys()]; }

export async function attach(tabId) {
  if (!hasChrome) throw dbgErr('DEBUG_UNSUPPORTED', 'chrome.debugger không khả dụng trong môi trường này.');
  if (attached.has(tabId)) return { attached: true, already: true, tabId };
  const settings = await getSettings();
  if (!settings.debuggerEnabled) {
    throw dbgErr('DEBUG_DISABLED', 'Chế độ debug đang TẮT. Bật trong Cài đặt → Trình duyệt → "Chế độ debug (CDP)" rồi thử lại.');
  }
  try {
    await chrome.debugger.attach({ tabId }, PROTOCOL);
  } catch (e) {
    const m = String(e?.message || e);
    if (/another debugger|already attached/i.test(m)) {
      throw dbgErr('DEBUG_BUSY', 'Tab đang bị debugger khác chiếm (DevTools đang mở?). Đóng DevTools rồi thử lại.');
    }
    if (/cannot access|chrome:\/\/|chrome web store|restricted/i.test(m)) {
      throw dbgErr('RESTRICTED_PAGE', 'Chrome không cho attach debugger vào trang này (chrome://, Web Store, trang nội bộ).');
    }
    throw dbgErr('DEBUG_ATTACH', 'Không attach được debugger: ' + m);
  }
  attached.set(tabId, { attachedAt: Date.now(), net: [], pending: new Map() });
  try { await chrome.debugger.sendCommand({ tabId }, 'Page.enable'); } catch (e) { }
  try { await chrome.debugger.sendCommand({ tabId }, 'Network.enable'); } catch (e) { }
  emit(EVENTS.DEBUGGER_CHANGED, { tabId, attached: true });
  return { attached: true, tabId };
}

export async function detach(tabId) {
  if (!hasChrome || !attached.has(tabId)) return { detached: true, was: false };
  attached.delete(tabId);
  try { await chrome.debugger.detach({ tabId }); } catch (e) { }
  emit(EVENTS.DEBUGGER_CHANGED, { tabId, attached: false });
  return { detached: true };
}

export async function detachAll() {
  for (const id of attachedIds()) await detach(id);
}

/** Dispatch a raw CDP command; auto-attach if needed; honest error mapping. */
export async function cmd(tabId, method, params = {}) {
  if (!hasChrome) throw dbgErr('DEBUG_UNSUPPORTED', 'chrome.debugger không khả dụng.');
  if (!attached.has(tabId)) await attach(tabId);
  try {
    return await chrome.debugger.sendCommand({ tabId }, method, params);
  } catch (e) {
    const m = String(e?.message || e);
    if (/not attached|no tab with given id|target closed|detached/i.test(m)) {
      attached.delete(tabId);
      emit(EVENTS.DEBUGGER_CHANGED, { tabId, attached: false });
      throw dbgErr('DEBUG_DETACHED', 'Debugger đã bị gỡ (tab đóng hoặc bạn tắt debug). Gọi browser_debug_attach rồi thử lại.');
    }
    throw dbgErr('DEBUG_CMD', `${method} failed: ${m}`);
  }
}

/* ---- external detach (user closes the banner / tab dies) → keep map honest ---- */
if (hasChrome) {
  chrome.debugger.onDetach.addListener(source => {
    if (source.tabId && attached.delete(source.tabId)) {
      emit(EVENTS.DEBUGGER_CHANGED, { tabId: source.tabId, attached: false, reason: 'external' });
    }
  });
  chrome.tabs?.onRemoved?.addListener(tabId => {
    if (attached.delete(tabId)) emit(EVENTS.DEBUGGER_CHANGED, { tabId, attached: false, reason: 'tab_closed' });
  });
  chrome.debugger.onEvent.addListener((source, method, params) => {
    try {
    const rec = attached.get(source.tabId);
    if (!rec || !method?.startsWith('Network.')) return;
    if (method === 'Network.requestWillBeSent') {
      // evict stale/overflow pending entries BEFORE inserting — a busy tab used
      // to grow this map without bound for the whole attach session
      if (rec.pending.size >= PENDING_CAP) {
        const cutoff = Date.now() - PENDING_TTL;
        for (const [id, p] of rec.pending) { if (p.t0 < cutoff) rec.pending.delete(id); }
        while (rec.pending.size >= PENDING_CAP) rec.pending.delete(rec.pending.keys().next().value);
      }
      rec.pending.set(params.requestId, {
        id: params.requestId,
        method: params.request?.method,
        url: String(params.request?.url || '').slice(0, 300),
        type: params.type,
        t0: Date.now(),
      });
    } else if (method === 'Network.responseReceived') {
      const p = rec.pending.get(params.requestId);
      if (p) { p.status = params.response?.status; p.mime = params.response?.mimeType; }
    } else if (method === 'Network.loadingFinished' || method === 'Network.loadingFailed') {
      const p = rec.pending.get(params.requestId);
      if (!p) return;
      p.ms = Date.now() - p.t0;
      if (method === 'Network.loadingFailed') p.failed = String(params.errorText || 'failed');
      rec.net.push(p);
      rec.pending.delete(params.requestId);
      if (rec.net.length > NET_CAP) rec.net.shift();
    }
    } catch (e) { /* a malformed CDP event must never kill the listener */ }
  });
}

export function networkLog(tabId, limit = 25) {
  const rec = attached.get(tabId);
  if (!rec) return null;
  const live = [...rec.pending.values()].map(p => ({ ...p, pending: true, t0: undefined }));
  return [...rec.net.slice(-limit), ...live]
    .slice(-limit)
    .map(p => ({ method: p.method, url: p.url, type: p.type, status: p.status, ms: p.ms, failed: p.failed, pending: p.pending || undefined }));
}

/* ---- key table for Input.dispatchKeyEvent (browser_debug_key) ---- */
export const KEY_DEFS = {
  enter:     { key: 'Enter', code: 'Enter', vk: 13, text: '\r' },
  tab:       { key: 'Tab', code: 'Tab', vk: 9 },
  escape:    { key: 'Escape', code: 'Escape', vk: 27 },
  esc:       { key: 'Escape', code: 'Escape', vk: 27 },
  backspace: { key: 'Backspace', code: 'Backspace', vk: 8 },
  delete:    { key: 'Delete', code: 'Delete', vk: 46 },
  arrowup:   { key: 'ArrowUp', code: 'ArrowUp', vk: 38 },
  arrowdown: { key: 'ArrowDown', code: 'ArrowDown', vk: 40 },
  arrowleft: { key: 'ArrowLeft', code: 'ArrowLeft', vk: 37 },
  arrowright:{ key: 'ArrowRight', code: 'ArrowRight', vk: 39 },
  home:      { key: 'Home', code: 'Home', vk: 36 },
  end:       { key: 'End', code: 'End', vk: 35 },
  pageup:    { key: 'PageUp', code: 'PageUp', vk: 33 },
  pagedown:  { key: 'PageDown', code: 'PageDown', vk: 34 },
  space:     { key: ' ', code: 'Space', vk: 32, text: ' ' },
};
