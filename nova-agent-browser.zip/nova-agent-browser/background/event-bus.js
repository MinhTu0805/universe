/* Nova Agent Browser — event bus.
 * In-SW pub/sub + broadcast to all connected side panel ports. */

const listeners = new Map();   // event -> Set<fn>
const ports = new Set();       // chrome.runtime.Port (side panels)

export const EVENTS = {
  AGENT_STARTED: 'AGENT_STARTED',
  AGENT_STATE_CHANGED: 'AGENT_STATE_CHANGED',
  TOOL_STARTED: 'TOOL_STARTED',
  TOOL_COMPLETED: 'TOOL_COMPLETED',
  TOOL_FAILED: 'TOOL_FAILED',
  TAB_CHANGED: 'TAB_CHANGED',
  SCREENSHOT_CAPTURED: 'SCREENSHOT_CAPTURED',
  TERMINAL_STARTED: 'TERMINAL_STARTED',
  TERMINAL_OUTPUT: 'TERMINAL_OUTPUT',
  APPROVAL_REQUIRED: 'APPROVAL_REQUIRED',
  APPROVAL_RESOLVED: 'APPROVAL_RESOLVED',
  TASK_COMPLETED: 'TASK_COMPLETED',
  TASK_FAILED: 'TASK_FAILED',
  TASK_STOPPED: 'TASK_STOPPED',
  TASK_PAUSED: 'TASK_PAUSED',
  TASK_RESUMED: 'TASK_RESUMED',
  FEED_ITEM: 'FEED_ITEM',        // append/update a feed item in a conversation
  STREAM_DELTA: 'STREAM_DELTA',  // live text streaming
  SELECTION_CHANGED: 'SELECTION_CHANGED',
  SETTINGS_CHANGED: 'SETTINGS_CHANGED',
  CONVERSATIONS_CHANGED: 'CONVERSATIONS_CHANGED',
  HUMAN_INTERFERENCE: 'HUMAN_INTERFERENCE',
  MODEL_FALLBACK: 'MODEL_FALLBACK',
  DEBUGGER_CHANGED: 'DEBUGGER_CHANGED', // chrome.debugger attached/detached on a tab
  USAGE: 'USAGE',
};

export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  return () => listeners.get(event)?.delete(fn);
}

export function emit(event, data) {
  for (const fn of listeners.get(event) || []) {
    try {
      // Listeners may be async: a rejected promise here would otherwise surface
      // as an unhandled rejection and can crash the MV3 service worker.
      const r = fn(data);
      if (r && typeof r.catch === 'function') r.catch(e => console.error('[nova] async listener error', e));
    } catch (e) { console.error('[nova] listener error', e); }
  }
  broadcast({ kind: 'event', event, data });
}

export function addPort(port) {
  ports.add(port);
  // Defensive cap: a side panel normally means one port, but a SW restart can
  // pile up half-dead ports before their onDisconnect fires.
  if (ports.size > 12) {
    const oldest = ports.values().next().value;
    ports.delete(oldest);
    try { oldest?.disconnect(); } catch (e) { }
  }
  port.onDisconnect.addListener(() => {
    ports.delete(port);
    // clear Chrome's "unchecked runtime.lastError" noise on deliberate closes
    void chrome.runtime?.lastError;
  });
}

export function broadcast(message) {
  for (const p of [...ports]) {
    try { p.postMessage(message); }
    catch (e) { ports.delete(p); } // dead port (panel closed) → forget it
  }
}

export function portCount() { return ports.size; }
