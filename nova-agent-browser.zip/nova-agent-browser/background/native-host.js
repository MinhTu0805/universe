/* Nova Agent Browser — native messaging client (terminal bridge).
 * Talks to the local Python host `com.nova.agent.host` over stdio.
 * Protocol (JSON, native-messaging framed):
 *   ext → host: {id, type:'exec', command, cwd, timeoutSec} | {id, type:'cancel'} | {type:'ping'}
 *   host → ext: {id, type:'started', pid} | {id, type:'stdout'|'stderr', data}
 *               | {id, type:'exit', code, durationMs} | {type:'pong', version, os, shell}
 */

const HOST = 'com.nova.agent.host';

let port = null;
let portError = null;
const pending = new Map(); // id -> {resolve, onEvent}
let pingInfo = null;

function connect() {
  if (port) return port;
  try {
    port = chrome.runtime.connectNative(HOST);
  } catch (e) {
    portError = String(e.message || e);
    port = null;
    throw Object.assign(new Error('Terminal bridge is not installed'), { code: 'NO_HOST' });
  }
  port.onMessage.addListener(msg => {
    if (msg?.type === 'pong') { pingInfo = msg; return; }
    const p = pending.get(msg?.id);
    if (!p) return;
    if (msg.type === 'exit' || msg.type === 'error') {
      pending.delete(msg.id);
      p.resolve(msg);
    } else {
      p.onEvent?.(msg);
    }
  });
  port.onDisconnect.addListener(() => {
    portError = chrome.runtime.lastError?.message || 'native host disconnected';
    port = null;
    const err = Object.assign(new Error('Terminal bridge is not installed or stopped: ' + portError), { code: 'NO_HOST' });
    for (const [, p] of pending) p.resolve({ type: 'error', message: err.message });
    pending.clear();
  });
  return port;
}

export async function hostStatus() {
  try {
    connect();
    pingInfo = null;
    port.postMessage({ type: 'ping' });
    const t0 = Date.now();
    while (!pingInfo && Date.now() - t0 < 2500) await new Promise(r => setTimeout(r, 100));
    return { installed: !!pingInfo, info: pingInfo, error: pingInfo ? null : 'host did not answer ping' };
  } catch (e) {
    return { installed: false, info: null, error: String(chrome.runtime.lastError?.message || e.message || e) };
  }
}

/**
 * Execute a shell command with streaming output.
 * onEvent({type:'stdout'|'stderr'|'started', data?|pid?})
 * Returns {code, durationMs, stdout, stderr, cancelled}
 */
export async function exec({ command, cwd, timeoutSec = 60, onEvent, cancelToken }) {
  connect(); // throws NO_HOST if missing
  const id = 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  let stdout = '', stderr = '';
  // Watchdog: if the host process dies silently (killed by the OS, Python
  // crash…) WITHOUT a port disconnect, no 'exit' frame ever arrives and the
  // caller would hang forever. Give the command its timeout + grace, then fail.
  let watchdog = null;
  const done = new Promise(resolve => {
    pending.set(id, {
      resolve,
      onEvent: (msg) => {
        if (msg.type === 'stdout') { stdout += msg.data; onEvent?.(msg); }
        else if (msg.type === 'stderr') { stderr += msg.data; onEvent?.(msg); }
        else onEvent?.(msg);
      },
    });
    watchdog = setTimeout(() => {
      if (pending.delete(id)) {
        resolve({ type: 'error', message: `Terminal bridge không phản hồi sau ${timeoutSec}s — host có thể đã crash. Kiểm tra lại trong Cài đặt → Terminal.` });
      }
    }, Math.min(timeoutSec, 1800) * 1000 + 15000);
  });
  const cleanup = () => clearTimeout(watchdog);
  try {
    port.postMessage({ id, type: 'exec', command, cwd, timeoutSec });
  } catch (e) {
    // port died between connect() and postMessage — do not leave a pending entry behind
    cleanup();
    pending.delete(id);
    throw Object.assign(new Error('Mất kết nối với terminal bridge: ' + String(e?.message || e)), { code: 'NO_HOST' });
  }

  if (cancelToken) {
    cancelToken.onCancel = () => {
      try { port?.postMessage({ id, type: 'cancel' }); } catch (e) { }
    };
  }
  const res = await done;
  cleanup();
  if (res.type === 'error') throw Object.assign(new Error(res.message || 'terminal error'), { code: 'TERMINAL' });
  return { code: res.code, durationMs: res.durationMs, stdout, stderr, cancelled: !!res.cancelled };
}

export function cancelAll() {
  for (const [id] of pending) {
    try { port?.postMessage({ id, type: 'cancel' }); } catch (e) { }
  }
}
