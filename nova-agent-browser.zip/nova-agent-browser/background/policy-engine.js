/* Nova Agent Browser — policy engine.
 * Risk classification + autonomy levels + tool permission groups.
 * Produces approval requests that the side panel resolves. */

import { getSettings } from './storage.js';

/* High-risk terminal command patterns (always ask unless auto-safe and safe) */
const TERMINAL_DESTRUCTIVE = [
  /\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)?/,
  /\b(del|erase|rd|rmdir)\b.*\s\/[sq]/i,
  /\bformat\b/i, /\bmkfs\b/, /\bdd\s+if=/, /\bshred\b/,
  />\s*\/dev\/(sd|nvme|disk)/,
  /\b(shutdown|reboot|halt|poweroff)\b/,
  /\bchmod\s+(-R\s+)?777\b/, /\bchown\s+-R\b/,
  /\bgit\s+(push\s+--force|reset\s+--hard|clean\s+-[fdx]+)/,
  /\b(npm|pip|pip3|apt|apt-get|brew|choco|winget)\s+(install|uninstall|remove|add)\b/,
  /\b(curl|wget|iwr|Invoke-WebRequest)\b[^|]*\|\s*(sh|bash|zsh|pwsh|powershell|cmd)/i,
  /\bsudo\b/, /\breg\s+(add|delete|import)\b/i, /\blaunchctl\b/, /\bsystemctl\s+(stop|disable|mask)\b/,
  /\b(kill|pkill|taskkill)\b/,
];

const SAFE_TERMINAL_HINT = /^(ls|dir|pwd|cd|cat|type|echo|python\s+--version|node\s+--version|git\s+status|git\s+log|git\s+diff|which|where|whoami|date|uname|head|tail|wc|grep|find\s+.\s+-name|jq\s+\.)\b/i;

export function terminalRisk(command) {
  const cmd = String(command || '').trim();
  if (TERMINAL_DESTRUCTIVE.some(re => re.test(cmd))) return 'high';
  if (SAFE_TERMINAL_HINT.test(cmd)) return 'low';
  return 'medium';
}

/** Map a tool to its permission group + default risk. */
export function classify(tool, args) {
  let risk = tool.risk || 'low';
  if (tool.group === 'terminal' && args?.command) risk = terminalRisk(args.command) === 'high' ? 'high' : Math.max(risk === 'high' ? 2 : risk === 'medium' ? 1 : 0, terminalRisk(args.command) === 'medium' ? 1 : 0) === 2 ? 'high' : terminalRisk(args.command);
  // uploading sensitive inputs is high risk
  if (tool.name === 'browser_type' && args?.sensitive) risk = 'high';
  if (tool.name === 'browser_fill_form' && (args?.submit || (args?.fields || []).some(f => f?.sensitive))) risk = 'high';
  if (tool.name === 'browser_submit') risk = 'high';
  return { group: tool.group || 'browser', risk };
}

const RANK = { low: 0, medium: 1, high: 2 };

/**
 * Decide: 'allow' | 'ask' | 'deny'
 * - toolPerms[group]: allowed | ask | denied
 * - autonomy: manual (ask ≥ medium), assisted (ask high), autonomous (ask high)
 */
export async function decide(tool, args) {
  const settings = await getSettings();
  const { group, risk } = classify(tool, args);
  const perm = settings.toolPerms?.[group] || 'allowed';
  if (perm === 'denied') return { verdict: 'deny', group, risk, reason: `Tool group "${group}" is denied in settings` };
  if (perm === 'ask') return { verdict: 'ask', group, risk };
  const autonomy = settings.autonomy || 'assisted';
  if (autonomy === 'manual' && RANK[risk] >= 1) return { verdict: 'ask', group, risk };
  if (risk === 'high') return { verdict: 'ask', group, risk }; // high risk always asks (all autonomy levels)
  if (tool.group === 'terminal') {
    const tp = settings.terminalPolicy || 'ask-risky';
    if (tp === 'ask-all') return { verdict: 'ask', group, risk };
    if (tp === 'ask-risky' && risk !== 'low') return { verdict: 'ask', group, risk };
  }
  return { verdict: 'allow', group, risk };
}

/* Approval memory: "approve for this task" / "always allow this action" */
const taskApprovals = new Map(); // taskId -> Set<toolName>
const alwaysApprovals = new Set(); // toolName

export function approveForTask(taskId, toolName) {
  if (!taskApprovals.has(taskId)) taskApprovals.set(taskId, new Set());
  taskApprovals.get(taskId).add(toolName);
}
export function approveAlways(toolName) { alwaysApprovals.add(toolName); }
export function isPreApproved(taskId, toolName) {
  return alwaysApprovals.has(toolName) || taskApprovals.get(taskId)?.has(toolName) || false;
}
export function clearTaskApprovals(taskId) { taskApprovals.delete(taskId); }

/** Human-readable approval text */
export function approvalText(tool, args) {
  const name = tool.name;
  switch (name) {
    case 'terminal_execute': return { title: 'Chạy lệnh terminal', detail: args.command, risk: terminalRisk(args.command) };
    case 'browser_submit': return { title: 'Gửi form trên trang', detail: args.ref || args.selector || 'form hiện tại' };
    case 'browser_upload': return { title: 'Upload tệp lên trang web', detail: (args.files || []).map(f => f.name).join(', ') || args.ref };
    case 'browser_download': return { title: 'Tải tệp xuống', detail: args.url || 'từ nút tải trên trang' };
    case 'browser_execute_script': return { title: 'Chạy thao tác DOM tuỳ chỉnh', detail: String(args.op?.op || args.op || '').slice(0, 120) };
    case 'browser_type': return args.sensitive ? { title: 'Nhập vào trường nhạy cảm', detail: 'Trường password/OTP (giá trị được che)' } : { title: 'Nhập văn bản vào trang', detail: String(args.text || '').slice(0, 80) };
    case 'browser_fill_form': return {
      title: args.submit ? 'Điền và GỬI form trên trang' : 'Điền form tự động',
      detail: `${(args.fields || []).length} trường${(args.fields || []).some(f => f?.sensitive) ? ' · có trường nhạy cảm' : ''}: ${(args.fields || []).slice(0, 4).map(f => f.name || f.ref || f.selector || '?').join(', ')}`,
    };
    case 'memory_forget': return { title: 'Xoá bộ nhớ dài hạn', detail: args.query || args.id || '' };
    case 'browser_click': return { title: 'Click phần tử có rủi ro', detail: args.name || args.text || args.ref || args.selector || '' };
    case 'browser_debug_attach': return { title: 'Bật chế độ debug của Chrome (CDP)', detail: 'Chrome sẽ hiện banner "đang debug" trên tab — cho phép AI điều khiển tab ở mức thấp (JS, input tin cậy, network log).' };
    case 'browser_debug_evaluate': return { title: 'Chạy JavaScript trong trang (CDP)', detail: String(args.expression || '').slice(0, 120) };
    case 'browser_debug_click': return { title: 'Click tin cậy qua debugger (CDP)', detail: args.x !== undefined ? `toạ độ (${args.x}, ${args.y})` : 'click chuột hệ thống' };
    case 'browser_debug_type': return { title: 'Nhập văn bản qua debugger (CDP)', detail: String(args.text || '').slice(0, 80) };
    default: return { title: `Cho phép ${name}`, detail: JSON.stringify(args || {}).slice(0, 120) };
  }
}
