/* Nova Agent Browser — LLM provider layer.
 * Canonical request → provider adapter → canonical response.
 * Supports OpenAI-compatible APIs (OpenAI, OpenRouter, Groq, DeepSeek,
 * Mistral, Together, xAI, Gemini-OAI, Ollama, LM Studio, custom) and
 * Anthropic Messages API natively. Keys never leave this context. */

import { redact } from './util.js';

export const PROVIDERS = {
  openai:     { name: 'OpenAI',            type: 'openai', base: 'https://api.openai.com/v1',                        model: 'gpt-4o-mini',                        vision: 'gpt-4o',               keyUrl: 'https://platform.openai.com/api-keys' },
  anthropic:  { name: 'Anthropic',         type: 'anthropic', base: 'https://api.anthropic.com',                     model: 'claude-sonnet-4-5',                  vision: 'claude-sonnet-4-5',    keyUrl: 'https://console.anthropic.com/settings/keys' },
  gemini:     { name: 'Google Gemini',     type: 'openai', base: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-2.0-flash',         vision: 'gemini-2.0-flash',     keyUrl: 'https://aistudio.google.com/app/apikey' },
  openrouter: { name: 'OpenRouter',        type: 'openai', base: 'https://openrouter.ai/api/v1',                     model: 'openai/gpt-4o-mini',                 vision: 'openai/gpt-4o',        keyUrl: 'https://openrouter.ai/keys' },
  groq:       { name: 'Groq',              type: 'openai', base: 'https://api.groq.com/openai/v1',                   model: 'llama-3.3-70b-versatile',            vision: '',                     keyUrl: 'https://console.groq.com/keys' },
  deepseek:   { name: 'DeepSeek',          type: 'openai', base: 'https://api.deepseek.com/v1',                      model: 'deepseek-chat',                     vision: '',                     keyUrl: 'https://platform.deepseek.com/api_keys' },
  mistral:    { name: 'Mistral',           type: 'openai', base: 'https://api.mistral.ai/v1',                        model: 'mistral-large-latest',              vision: 'pixtral-large-latest', keyUrl: 'https://console.mistral.ai/api-keys' },
  together:   { name: 'Together AI',       type: 'openai', base: 'https://api.together.xyz/v1',                      model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo', vision: '',              keyUrl: 'https://api.together.xyz/settings/api-keys' },
  xai:        { name: 'xAI (Grok)',        type: 'openai', base: 'https://api.x.ai/v1',                              model: 'grok-4-fast',                       vision: 'grok-4-fast',          keyUrl: 'https://console.x.ai/' },
  moonshot:   { name: 'Moonshot AI (Kimi)', type: 'openai', base: 'https://api.moonshot.ai/v1',                      model: 'kimi-k2-0905-preview',              vision: 'kimi-k2-0905-preview', keyUrl: 'https://platform.moonshot.ai/console/api-keys' },
  github:     { name: 'GitHub Models',     type: 'openai', base: 'https://models.github.ai/inference',               model: 'openai/gpt-4o-mini',                vision: 'openai/gpt-4o',        keyUrl: 'https://github.com/settings/tokens', note: 'Dùng GitHub personal access token' },
  cerebras:   { name: 'Cerebras',          type: 'openai', base: 'https://api.cerebras.ai/v1',                       model: 'llama-3.3-70b',                     vision: '',                     keyUrl: 'https://cloud.cerebras.ai/platform' },
  zai:        { name: 'Z.AI (GLM)',        type: 'openai', base: 'https://api.z.ai/api/paas/v4',                     model: 'glm-4.6',                           vision: 'glm-4.5v',             keyUrl: 'https://z.ai/manage-apikey/apikey-list' },
  qwen:       { name: 'Qwen (DashScope)',  type: 'openai', base: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus',                        vision: 'qwen-vl-max',          keyUrl: 'https://bailian.console.aliyun.com/#/api-key' },
  ollama:     { name: 'Ollama (local)',    type: 'openai', base: 'http://localhost:11434/v1',                        model: 'llama3.2',                          vision: '', noKey: true,        note: 'Chạy local — không cần API key' },
  lmstudio:   { name: 'LM Studio (local)', type: 'openai', base: 'http://localhost:1234/v1',                         model: 'local-model',                       vision: '', noKey: true,        note: 'Chạy local — không cần API key' },
  custom:     { name: 'Custom (OpenAI-compatible)', type: 'openai', base: '',                                        model: '',                                  vision: '',                     note: 'Endpoint bất kỳ tương thích OpenAI' },
};

/* Headers riêng theo provider. OpenRouter khuyến nghị HTTP-Referer + X-Title:
 * thiếu chúng request vẫn chạy nhưng dễ dính rate-limit chung và không hiện
 * tên app trong dashboard của người dùng. */
const EXTRA_HEADERS = {
  openrouter: { 'HTTP-Referer': 'https://nova-agent.local/', 'X-Title': 'Nova Agent Browser' },
};

/* ---------------- capability heuristics (overridable by test) ---------------- */
export function modelCaps(providerId, model) {
  const m = String(model || '').toLowerCase();
  const vision =
    /gpt-4o|gpt-4\.1|gpt-5|o[134]|vision|claude-3|claude-sonnet-4|claude-opus-4|claude-haiku|gemini|pixtral|grok-4|grok-2-vision|llama-3\.2-(11|90)b|qwen\d*-vl|llava|minicpm-v|moondream|glm-4(\.\d+)?v|doubao-vision|kimi|moonshot-v1-.*-vision/.test(m) ||
    (providerId === 'anthropic' && /claude/.test(m));
  const tools =
    !/llama3\.2:1b|gemma:2b|phi3:mini|tiny/.test(m);
  // reasoning models: o-series, gpt-5, deepseek-r1/reasoner, qwq, grok-4/3-mini,
  // anything with reason/thinking in the name (kimi-k2-thinking, glm-4.5-air-thinking…)
  const reasoning = /\bo[134](-mini|-pro)?\b|gpt-5|deepseek-r1|deepseek-reasoner|qwq|grok-4|grok-3-mini|reason|thinking/.test(m);
  // strict OpenAI-spec endpoints: reject temperature/max_tokens for reasoning
  // models and REQUIRE max_completion_tokens instead (a hard HTTP 400 otherwise)
  const strictSpec = providerId === 'openai' && /^(o[134]|gpt-5)/.test(m);
  return { text: true, vision, tools, streaming: true, json: tools, reasoning, strictSpec };
}

/* Providers known to accept the OpenAI `reasoning_effort` field. Others
 * (DeepSeek, Gemini-compat, Ollama…) either switch reasoning by model name or
 * reject unknown params with a 400 — so we never send it to them. */
const REASONING_EFFORT_PROVIDERS = new Set(['openai', 'openrouter', 'github', 'xai', 'groq']);

/* Anthropic extended-thinking token budgets per effort level (no-tool turns) */
const THINKING_BUDGET = { low: 1024, medium: 5000, high: 16000 };

/**
 * Build the OpenAI-compatible request body (pure — unit-tested in validate.js).
 * Fixes a real 400: reasoning models on strict-spec endpoints reject
 * `max_tokens`/`temperature`; they need `max_completion_tokens` and no sampling
 * params. `reasoning_effort` is sent only to providers known to accept it.
 */
export function buildOpenAIBody(providerId, req) {
  const caps = modelCaps(providerId, req.model);
  const effort = req.reasoning && req.reasoning !== 'off' ? req.reasoning : null;
  const body = {
    model: req.model,
    messages: toOpenAI(req.messages, { gemini: !!req.gemini }),
    stream: !!req.stream,
  };
  if (caps.strictSpec) {
    body.max_completion_tokens = req.maxTokens; // o-series / gpt-5: no max_tokens, no temperature
  } else {
    if (req.temperature !== undefined && !caps.reasoning) body.temperature = req.temperature;
    body.max_tokens = req.maxTokens;
  }
  if (req.tools?.length) { body.tools = toOpenAITools(req.tools); body.tool_choice = req.toolChoice || 'auto'; }
  if (req.stream) body.stream_options = { include_usage: true };
  if (effort && caps.reasoning && REASONING_EFFORT_PROVIDERS.has(providerId)) {
    body.reasoning_effort = effort === 'auto' ? 'medium' : effort;
  }
  return body;
}

/**
 * Build the Anthropic Messages request body (pure — unit-tested).
 * Extended thinking (`thinking: {type:'enabled', budget_tokens}`) is applied
 * ONLY on tool-free turns: with tools, the API requires the thinking blocks to
 * be replayed verbatim across the tool round-trip, which our compact history
 * deliberately doesn't keep — so agent-loop turns stay non-thinking.
 */
export function buildAnthropicBody(req, mapped) {
  const { system, messages } = mapped;
  const effort = req.reasoning && req.reasoning !== 'off' ? req.reasoning : null;
  const wantThinking = !!effort && !req.tools?.length;
  const body = {
    model: req.model,
    system,
    messages,
    max_tokens: req.maxTokens || 4096,
    stream: !!req.stream,
  };
  if (wantThinking) {
    const budget = THINKING_BUDGET[effort] || THINKING_BUDGET.medium;
    body.thinking = { type: 'enabled', budget_tokens: budget };
    if (body.max_tokens <= budget) body.max_tokens = budget + 4096; // API: max_tokens must exceed budget
    // thinking is incompatible with temperature/top_p overrides — omit them
  } else if (req.temperature !== undefined) {
    body.temperature = req.temperature;
  }
  if (req.tools?.length) body.tools = toAnthropicTools(req.tools);
  return body;
}

/* ---------------- HTTP with timeout + backoff ---------------- */
const RETRY_STATUS = new Set([408, 409, 425, 429]); // 5xx handled via >= 500
async function httpJson(url, { method = 'GET', headers = {}, body, timeout = 60000, signal, stream = false, retries = 2 } = {}) {
  let attempt = 0, lastErr = null;
  while (attempt <= retries) {
    // the caller cancelled (user pressed Stop / task aborted) → never retry
    if (signal?.aborted) throw Object.assign(new Error('aborted by user'), { code: 'STOPPED' });
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(Object.assign(new Error('provider timeout'), { code: 'TIMEOUT', retryable: true })), timeout);
    const link = signal && AbortSignal.any ? AbortSignal.any([signal, ctrl.signal]) : ctrl.signal;
    try {
      const res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined, signal: link });
      clearTimeout(timer);
      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        const err = new Error(`HTTP ${res.status}: ${redact(txt).slice(0, 500)}`);
        err.status = res.status;
        err.retryable = RETRY_STATUS.has(res.status) || res.status >= 500;
        err.code = res.status === 401 || res.status === 403 ? 'AUTH'
          : res.status === 402 ? 'QUOTA'
          : res.status === 429 ? 'RATE_LIMIT'
          : res.status === 404 ? 'NOT_FOUND'
          : res.status === 400 || res.status === 422 ? 'BAD_REQUEST'
          : res.status === 408 ? 'TIMEOUT'
          : res.status >= 500 ? 'SERVER' : 'HTTP';
        // honor Retry-After (seconds) for rate limits, capped
        if (res.status === 429) {
          const ra = parseInt(res.headers.get('retry-after') || '', 10);
          if (ra > 0) err.retryAfterMs = Math.min(15000, ra * 1000);
        }
        throw err;
      }
      return res;
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
      if (signal?.aborted && e.code !== 'TIMEOUT') throw Object.assign(new Error('aborted by user'), { code: 'STOPPED' });
      // AbortError here is OUR timeout abort only when coded TIMEOUT; any other
      // AbortError is an external cancel → do not retry
      const retryable = e.code === 'TIMEOUT' || e.retryable || (!e.status && /network|fetch|failed/i.test(String(e.message)));
      if (attempt >= retries || !retryable) throw e;
      const wait = (e.retryAfterMs || Math.min(8000, 600 * Math.pow(2, attempt))) + Math.random() * 300;
      await new Promise(r => setTimeout(r, wait));
      attempt++;
    }
  }
  throw lastErr;
}

/* Gemini 3.x (via the OpenAI-compatible endpoint) attaches an encrypted
 * `thought_signature` to function calls and hard-rejects (HTTP 400) any
 * follow-up request whose replayed tool_calls lack it:
 *   "Function call is missing a thought_signature in functionCall parts…"
 * The signature arrives on the tool_call as extra_content.google.thought_signature
 * (both streaming deltas and non-streaming messages). We capture it on the
 * canonical tool call (extraContent) and replay it verbatim. For history that
 * lost the signature (compaction, resume from feed), Google's documented
 * migration value skips validation instead of 400-ing the whole request. */
const GEMINI_SKIP_THOUGHT_SIG = { google: { thought_signature: 'skip_thought_signature_validator' } };
export function isGeminiEndpoint(providerId, base) {
  return providerId === 'gemini' || /generativelanguage\.googleapis\.com/i.test(String(base || ''));
}

/* ---------------- canonical message mapping ---------------- */
function toOpenAI(messages, opts = {}) {
  return messages.map(m => {
    if (m.role === 'tool') {
      return { role: 'tool', tool_call_id: m.toolCallId, content: textOf(m.content) || '(empty result)' };
    }
    if (m.role === 'assistant' && m.toolCalls?.length) {
      return {
        role: 'assistant',
        content: textOf(m.content) || null,
        tool_calls: m.toolCalls.map(tc => {
          const out = { id: tc.id, type: 'function', function: { name: tc.name, arguments: typeof tc.arguments === 'string' ? tc.arguments : JSON.stringify(tc.arguments || {}) } };
          const ec = tc.extraContent || (opts.gemini ? GEMINI_SKIP_THOUGHT_SIG : null);
          if (ec) out.extra_content = ec;
          return out;
        }),
      };
    }
    const parts = [];
    for (const c of m.content || []) {
      if (c.type === 'text') parts.push({ type: 'text', text: c.text });
      else if (c.type === 'image') parts.push({ type: 'image_url', image_url: { url: c.dataUrl } });
    }
    return { role: m.role, content: parts.length && parts.some(p => p.type === 'image_url') ? parts : (parts.map(p => p.text).join('\n') || '') };
  });
}

function toOpenAITools(tools) {
  return tools.map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.schema } }));
}

function dataUrlParts(dataUrl) {
  const m = /^data:([^;]+);base64,(.*)$/s.exec(dataUrl || '');
  return m ? { mediaType: m[1], data: m[2] } : { mediaType: 'image/jpeg', data: '' };
}

function toAnthropic(messages) {
  let system = [];
  const out = [];
  // Anthropic hard-rejects (HTTP 400): consecutive same-role messages,
  // empty text blocks, and tool_result without a preceding tool_use.
  // So we merge into strictly alternating user/assistant turns.
  const pushMerged = (role, blocks) => {
    const prev = out[out.length - 1];
    if (prev && prev.role === role && !hasToolUse(prev.content) && !blocks.some(b => b.type === 'tool_result')) {
      prev.content.push(...blocks);
    } else {
      out.push({ role, content: blocks });
    }
  };
  const hasToolUse = content => Array.isArray(content) && content.some(b => b.type === 'tool_use');
  for (const m of messages) {
    if (m.role === 'system') { system.push(textOf(m.content)); continue; }
    if (m.role === 'tool') {
      // merge consecutive tool results into one user message
      const block = { type: 'tool_result', tool_use_id: m.toolCallId, content: anthropicContent(m.content) };
      const prev = out[out.length - 1];
      if (prev && prev.role === 'user' && Array.isArray(prev.content) && prev.content[0]?.type === 'tool_result') prev.content.push(block);
      else out.push({ role: 'user', content: [block] });
      continue;
    }
    if (m.role === 'assistant' && m.toolCalls?.length) {
      const blocks = [];
      const t = textOf(m.content);
      if (t) blocks.push({ type: 'text', text: t });
      for (const tc of m.toolCalls) blocks.push({ type: 'tool_use', id: tc.id, name: tc.name, input: tc.arguments || {} });
      out.push({ role: 'assistant', content: blocks }); // tool_use must start a fresh assistant turn
      continue;
    }
    const role = m.role === 'assistant' ? 'assistant' : 'user';
    pushMerged(role, anthropicContent(m.content));
  }
  // first message must be role 'user'
  if (out.length && out[0].role !== 'user') out.unshift({ role: 'user', content: [{ type: 'text', text: '(tiếp tục)' }] });
  return { system: system.join('\n\n') || undefined, messages: out };
}

function anthropicContent(content) {
  const blocks = [];
  for (const c of content || []) {
    if (c.type === 'text') {
      if (!c.text || !c.text.trim()) continue; // empty text blocks → HTTP 400
      blocks.push({ type: 'text', text: c.text });
    }
    else if (c.type === 'image') {
      const p = dataUrlParts(c.dataUrl);
      if (!p.data) continue;
      blocks.push({ type: 'image', source: { type: 'base64', media_type: p.mediaType, data: p.data } });
    }
  }
  return blocks.length ? blocks : [{ type: 'text', text: '(empty)' }];
}

function toAnthropicTools(tools) {
  return tools.map(t => ({ name: t.name, description: t.description, input_schema: t.schema }));
}

function textOf(content) {
  if (typeof content === 'string') return content;
  return (content || []).filter(c => c.type === 'text').map(c => c.text).join('\n');
}

/* ---------------- OpenAI-compatible adapter ---------------- */
async function callOpenAI(providerId, cfg, req, onDelta) {
  if (!cfg.base) {
    throw Object.assign(
      new Error(`Provider "${PROVIDERS[providerId]?.name || providerId}" chưa có Base URL — mở Cài đặt → Providers để nhập endpoint.`),
      { code: 'BAD_CONFIG' });
  }
  const headers = { 'Content-Type': 'application/json', ...(EXTRA_HEADERS[providerId] || {}) };
  if (cfg.apiKey) headers['Authorization'] = `Bearer ${cfg.apiKey}`;
  // Gemini endpoints enforce thought_signature replay on tool calls
  req.gemini = isGeminiEndpoint(providerId, cfg.base);
  const body = buildOpenAIBody(providerId, req);

  const res = await httpJson(cfg.base.replace(/\/$/, '') + '/chat/completions', {
    method: 'POST', headers, body, timeout: req.timeout || 120000, signal: req.signal,
  });

  if (!req.stream) {
    const j = await res.json();
    const choice = j.choices?.[0] || {};
    const msg = choice.message || {};
    return {
      text: msg.content || '',
      toolCalls: (msg.tool_calls || []).map(tc => ({
        id: tc.id, name: tc.function?.name,
        ...(tc.extra_content ? { extraContent: tc.extra_content } : null),
        ...parseToolArgs(tc.function?.arguments, tc.function?.name),
      })).filter(tc => tc.name),
      usage: j.usage ? { prompt: j.usage.prompt_tokens, completion: j.usage.completion_tokens, total: j.usage.total_tokens } : null,
      finishReason: choice.finish_reason,
    };
  }

  /* streaming */
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '', text = '', usage = null;
  const toolAcc = new Map(); // key -> {id, name, argsStr, extra}
  // Keying: OpenAI tags every delta with `index`; Gemini's compat endpoint
  // sends complete tool calls WITHOUT index (one delta per call). Keying
  // everything by `?? 0` used to merge Gemini's parallel calls into one
  // corrupted call (concatenated names/args). Prefer index, then call id,
  // then "whatever the previous delta continued".
  let lastKey = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        const s = line.trim();
        if (!s.startsWith('data:')) continue;
        const payload = s.slice(5).trim();
        if (payload === '[DONE]') continue;
        let j; try { j = JSON.parse(payload); } catch (e) { continue; }
        if (j.usage) usage = { prompt: j.usage.prompt_tokens, completion: j.usage.completion_tokens, total: j.usage.total_tokens };
        const delta = j.choices?.[0]?.delta;
        if (!delta) continue;
        if (delta.content) { text += delta.content; onDelta?.(delta.content, text); }
        for (const tc of delta.tool_calls || []) {
          const key = tc.index ?? (tc.id ? 'id:' + tc.id : lastKey);
          lastKey = key;
          const acc = toolAcc.get(key) || { id: tc.id || `call_${toolAcc.size}`, name: '', argsStr: '', extra: null };
          if (tc.id) acc.id = tc.id;
          if (tc.extra_content) acc.extra = tc.extra_content; // Gemini thought_signature lives here
          if (tc.function?.name) acc.name += tc.function.name;
          if (tc.function?.arguments) acc.argsStr += tc.function.arguments;
          toolAcc.set(key, acc);
        }
      }
    }
  } finally {
    // release the stream on abort/stop — an orphaned reader pins the socket
    // and keeps the fetch body alive in the service worker
    try { await reader.cancel(); } catch (e) { }
    try { reader.releaseLock(); } catch (e) { }
  }
  return {
    text,
    toolCalls: [...toolAcc.values()].map(a => ({ id: a.id, name: a.name, ...(a.extra ? { extraContent: a.extra } : null), ...parseToolArgs(a.argsStr, a.name) })).filter(t => t.name),
    usage,
    finishReason: toolAcc.size ? 'tool_calls' : 'stop',
  };
}

/* ---------------- Anthropic adapter ---------------- */
async function callAnthropic(cfg, req, onDelta) {
  const headers = {
    'Content-Type': 'application/json',
    'x-api-key': cfg.apiKey || '',
    'anthropic-version': '2023-06-01',
    'anthropic-dangerous-direct-browser-access': 'true',
  };
  const mapped = toAnthropic(req.messages);
  const body = buildAnthropicBody(req, mapped);

  const res = await httpJson(cfg.base.replace(/\/$/, '') + '/v1/messages', {
    method: 'POST', headers, body, timeout: req.timeout || 120000, signal: req.signal,
  });

  if (!req.stream) {
    const j = await res.json();
    return parseAnthropic(j);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '', text = '', usage = null;
  const blocks = new Map(); // index -> {type, text?, name?, id?, jsonStr?}
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        const s = line.trim();
        if (!s.startsWith('data:')) continue;
        let j; try { j = JSON.parse(s.slice(5).trim()); } catch (e) { continue; }
        if (j.type === 'message_start' && j.message?.usage) usage = { prompt: j.message.usage.input_tokens, completion: j.message.usage.output_tokens };
        if (j.type === 'message_delta' && j.usage) usage = usage ? { ...usage, completion: j.usage.output_tokens } : { completion: j.usage.output_tokens };
        if (j.type === 'content_block_start') {
          blocks.set(j.index, j.content_block?.type === 'tool_use'
            ? { type: 'tool_use', id: j.content_block.id, name: j.content_block.name, jsonStr: '' }
            : { type: 'text', text: '' });
        }
        if (j.type === 'content_block_delta') {
          const b = blocks.get(j.index);
          if (!b) continue;
          if (j.delta?.type === 'text_delta') { b.text += j.delta.text; text += j.delta.text; onDelta?.(j.delta.text, text); }
          if (j.delta?.type === 'input_json_delta') b.jsonStr += j.delta.partial_json;
          // thinking_delta / signature_delta are intentionally not replayed
          // (thinking is only enabled on tool-free turns — see buildAnthropicBody)
        }
      }
    }
  } finally {
    // giải phóng stream khi abort/stop — reader mồ côi giữ socket và fetch body
    // sống mãi trong service worker
    try { await reader.cancel(); } catch (e) { }
    try { reader.releaseLock(); } catch (e) { }
  }
  const toolCalls = [...blocks.values()].filter(b => b.type === 'tool_use').map(b => ({ id: b.id, name: b.name, ...parseToolArgs(b.jsonStr, b.name) }));
  return { text, toolCalls, usage: usage ? { prompt: usage.prompt || 0, completion: usage.completion || 0, total: (usage.prompt || 0) + (usage.completion || 0) } : null, finishReason: toolCalls.length ? 'tool_calls' : 'stop' };
}

function parseAnthropic(j) {
  const text = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  const toolCalls = (j.content || []).filter(b => b.type === 'tool_use').map(b => ({ id: b.id, name: b.name, arguments: b.input || {} }));
  return {
    text, toolCalls,
    usage: j.usage ? { prompt: j.usage.input_tokens, completion: j.usage.output_tokens, total: j.usage.input_tokens + j.usage.output_tokens } : null,
    finishReason: j.stop_reason === 'tool_use' ? 'tool_calls' : 'stop',
  };
}

/**
 * Parse tool-call arguments from the model. NEVER silently converts broken
 * JSON to {} (that hid the root cause and made the agent act on empty args).
 * Returns { args } on success or { argsError } with a precise diagnostic —
 * the agent runtime turns argsError into an explicit tool error so the model
 * can re-issue the call, instead of executing with fabricated arguments.
 */
function parseToolArgs(raw, toolName) {
  if (raw == null || raw === '') return { args: {} };
  if (typeof raw === 'object') return { args: raw };
  try { return { args: JSON.parse(raw) }; } catch (e) {
    return { argsError: `invalid JSON arguments for ${toolName || 'tool'}: ${e.message} — raw: ${String(raw).slice(0, 300)}` };
  }
}

/* ---------------- public API ---------------- */
export async function chat({ provider, cfg, req, onDelta }) {
  const def = PROVIDERS[provider];
  if (!def) throw new Error('unknown provider: ' + provider);
  const merged = { base: cfg.base || def.base, apiKey: cfg.apiKey, model: req.model || cfg.model || def.model };
  if (!merged.model) {
    throw Object.assign(
      new Error(`Chưa chọn model cho ${def.name} — mở Cài đặt → Models và nhập tên model.`),
      { code: 'BAD_CONFIG' });
  }
  req.model = merged.model;
  if (def.type === 'anthropic') return callAnthropic(merged, req, onDelta);
  return callOpenAI(provider, merged, req, onDelta);
}

export async function listModels(provider, cfg) {
  const def = PROVIDERS[provider];
  if (!def) throw new Error('unknown provider');
  const base = (cfg.base || def.base || '').replace(/\/$/, '');
  if (!base) throw Object.assign(new Error('Chưa nhập Base URL cho provider này.'), { code: 'BAD_CONFIG' });
  if (def.type === 'anthropic') {
    const res = await httpJson(base + '/v1/models', { headers: { 'x-api-key': cfg.apiKey || '', 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, timeout: 20000 });
    const j = await res.json();
    return (j.data || []).map(m => m.id);
  }
  const headers = { ...(EXTRA_HEADERS[provider] || {}) };
  if (cfg.apiKey) headers['Authorization'] = `Bearer ${cfg.apiKey}`;
  const res = await httpJson(base + '/models', { headers, timeout: 20000 });
  const j = await res.json();
  return (j.data || []).map(m => m.id).sort();
}

export async function testConnection(provider, cfg) {
  const def = PROVIDERS[provider];
  const t0 = Date.now();
  try {
    let models = [];
    try { models = await listModels(provider, cfg); } catch (e) { /* some endpoints lack /models */ }
    const model = cfg.model || def.model;
    const caps = modelCaps(provider, model);
    // minimal real completion to verify auth + model
    await chat({
      provider, cfg,
      req: { model, messages: [{ role: 'user', content: [{ type: 'text', text: 'ping' }] }], maxTokens: 8, temperature: 0, stream: false, timeout: 30000 },
    });
    return {
      ok: true, latencyMs: Date.now() - t0, model,
      models: models.slice(0, 300),
      capabilities: caps,
      message: `Connected · ${models.length ? models.length + ' models' : 'model available'}`,
    };
  } catch (e) {
    return { ok: false, code: e.code || 'ERROR', message: friendlyError(e), raw: redact(String(e.message || e)).slice(0, 300) };
  }
}

export function friendlyError(e) {
  const s = e.status;
  if (e.code === 'STOPPED') return 'Đã dừng theo yêu cầu';
  if (e.code === 'BAD_CONFIG') return String(e.message || 'Provider chưa được cấu hình đầy đủ');
  if (s === 401 || s === 403) return 'API key không hợp lệ hoặc thiếu quyền (401/403) — kiểm tra lại key trong Cài đặt → Providers';
  if (s === 402 || e.code === 'QUOTA') return 'Tài khoản provider hết credit / cần thanh toán (402) — nạp thêm hoặc đổi provider';
  if (s === 429) return 'Hết hạn mức / rate limit (429) — chậm lại hoặc đổi model';
  if (s === 404) return 'Model không tồn tại hoặc sai endpoint (404)';
  if (s === 400 || s === 422) return `Provider từ chối request (${s}) — thường do model không hỗ trợ tham số/tool. Chi tiết: ${redact(String(e.message || '')).replace(/^HTTP \d+: */, '').slice(0, 220)}`;
  if (s === 408 || e.code === 'TIMEOUT') return 'Provider timeout — kiểm tra mạng/endpoint';
  if (s >= 500) return `Provider đang lỗi (${s}) — thử lại sau`;
  if (/Failed to fetch|NetworkError|ERR_/i.test(String(e.message))) return 'Không kết nối được provider (mạng/CORS/endpoint)';
  return redact(String(e.message || e)).slice(0, 220);
}

/* exported for scripts/validate.js — pure serializers/shapers, no network */
export const __test = { toOpenAI, toAnthropic, toOpenAITools, toAnthropicTools, parseToolArgs, buildOpenAIBody, buildAnthropicBody, THINKING_BUDGET, REASONING_EFFORT_PROVIDERS, GEMINI_SKIP_THOUGHT_SIG, isGeminiEndpoint };
