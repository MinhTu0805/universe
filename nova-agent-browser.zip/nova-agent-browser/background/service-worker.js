/* Nova Agent Browser — service worker entry.
 * Registers all tools, owns AgentRuntime instances, bridges the side panel
 * (long-lived Port "nova-sidepanel"), context menus, commands and tab events. */

import './tools-browser.js';
import { registerCanvasTools } from './tools-browser.js';
import './tools-system.js';
import './tools-cdp.js';
registerCanvasTools();

import { AgentRuntime } from './agent-runtime.js';
import { emit, on, addPort, broadcast, EVENTS } from './event-bus.js';
import * as store from './storage.js';
import { listTools } from './tool-registry.js';
import { PROVIDERS, testConnection, listModels, friendlyError } from './providers.js';
import * as nativeHost from './native-host.js';
import * as cdp from './cdp.js';
import { getShot, getArtifact } from './artifacts.js';
import { targetTabId } from './tools-browser.js';

/* ==================== runtime registry ==================== */

const runtimes = new Map(); // convId -> AgentRuntime
function getRuntime(convId) {
  if (!runtimes.has(convId)) runtimes.set(convId, new AgentRuntime(convId));
  return runtimes.get(convId);
}
function runningRuntime() {
  for (const rt of runtimes.values()) {
    if (!['idle', 'completed', 'failed', 'stopped'].includes(rt.state)) return rt;
  }
  return null;
}

/* ==================== side panel port ==================== */

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'nova-sidepanel') return;
  addPort(port);
  port.onMessage.addListener(async msg => {
    if (msg?.kind !== 'cmd') return;
    const reply = (ok, data) => { try { port.postMessage({ kind: 'res', id: msg.id, ok, data }); } catch (e) { void chrome.runtime?.lastError; } };
    try { reply(true, await handleCommand(msg, port)); }
    catch (e) {
      // every command must produce a response — a dangling one hangs the
      // panel-side pending map until the watchdog timeout
      try { reply(false, { code: e?.code || 'ERROR', message: friendlyError(e) }); }
      catch (e2) { console.error('[nova] command failed AND reply failed', e, e2); }
    }
  });
});

async function handleCommand(msg) {
  const d = msg.data || {};
  switch (msg.cmd) {

    case 'get_state': {
      const [settings, providers, convs, pending] = await Promise.all([
        store.getSettings(), store.getProviders(), store.listConversations(),
        chrome.storage.session.get('pendingAction'),
      ]);
      const raw = await store.loadStore();
      if (pending.pendingAction) await chrome.storage.session.remove('pendingAction').catch(() => { });
      return {
        settings,
        providers: maskProviders(providers),
        providerPresets: providerPresets(),
        conversations: convs,
        activeConvId: raw.prefs?.activeConvId || null,
        usage: raw.usage,
        prefs: raw.prefs,
        pendingAction: pending.pendingAction || null,
        toolsCount: listTools().length,
        debugTabs: cdp.attachedIds(),
      };
    }

    case 'get_conversation': {
      const c = await store.getConversation(d.convId);
      if (!c) throw new Error('conversation not found');
      return { conversation: c };
    }

    case 'new_conversation': {
      const c = await store.createConversation({ mode: d.mode });
      await setActiveConv(c.id);
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      return { conversation: c };
    }

    case 'set_active_conv': { await setActiveConv(d.convId); return { ok: true }; }

    case 'set_conversation_mode': {
      // keeps conversation.mode, the UI mode and run_task.mode in sync
      const conv = await store.getConversation(d.convId);
      if (!conv) throw new Error('conversation not found');
      const mode = store.normalizeMode(d.mode); // legacy chat/computer/research → ask/agent
      const rt = runtimes.get(d.convId);
      if (rt && !['idle', 'completed', 'failed', 'stopped'].includes(rt.state)) throw new Error('agent is busy — stop it before switching mode');
      await store.updateConversation(d.convId, { mode });
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      return { ok: true, mode };
    }

    case 'rename_conversation': {
      await store.updateConversation(d.convId, { title: String(d.title || '').slice(0, 80) });
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      return { ok: true };
    }

    case 'delete_conversation': {
      const rt = runtimes.get(d.convId);
      if (rt) rt.stop();
      await store.deleteConversation(d.convId);
      runtimes.delete(d.convId);
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      return { ok: true };
    }

    case 'clear_conversations': {
      for (const rt of runtimes.values()) rt.stop();
      runtimes.clear();
      await store.clearConversations();
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      return { ok: true };
    }

    case 'run_task': {
      const convId = d.convId;
      if (!convId) throw new Error('missing convId');
      const rt = getRuntime(convId);
      if (!['idle', 'completed', 'failed', 'stopped'].includes(rt.state)) throw new Error('agent is busy — stop it first');
      rt.run({ text: d.text, mode: d.mode, selection: d.selection, attachments: d.attachments }).catch(e => console.error('[nova] run error', e));
      return { ok: true };
    }

    case 'stop': { if (!d.convId) throw new Error('missing convId'); getRuntime(d.convId).stop(); return { ok: true }; }
    case 'pause': { if (!d.convId) throw new Error('missing convId'); getRuntime(d.convId).pause(); return { ok: true }; }
    case 'resume': { if (!d.convId) throw new Error('missing convId'); getRuntime(d.convId).resume(); return { ok: true }; }
    case 'approval_response': { if (!d.convId) throw new Error('missing convId'); getRuntime(d.convId).resolveApproval(d.ok, d.scope); return { ok: true }; }
    case 'ask_response': { if (!d.convId) throw new Error('missing convId'); getRuntime(d.convId).resolveAsk(d.answer); return { ok: true }; }

    case 'update_settings': {
      const clean = sanitizeSettings(d.patch || {});
      await store.updateSettings(clean);
      // tắt master switch debug → gỡ mọi debugger session ngay lập tức
      if (clean.debuggerEnabled === false) await cdp.detachAll().catch(() => { });
      emit(EVENTS.SETTINGS_CHANGED, { settings: await store.getSettings() });
      return { settings: await store.getSettings() };
    }

    case 'flush_settings': {
      // nút "Lưu thay đổi" ở panel: ép ghi ngay mọi thay đổi đang debounce,
      // để toast "Đã lưu" là một bảo đảm thật — không phải lời hứa 250ms
      await store.flushStore();
      emit(EVENTS.SETTINGS_CHANGED, { settings: await store.getSettings() });
      return { settings: await store.getSettings(), savedAt: Date.now() };
    }

    case 'set_prefs': {
      const raw = await store.loadStore();
      Object.assign(raw.prefs, d.patch || {});
      await store.persist(true); // prefs (mode UI, panel state…) phải sống sót qua SW restart
      return { prefs: raw.prefs };
    }

    case 'set_provider': {
      const cfg = { ...(d.cfg || {}) };
      const cur = (await store.getProviders()).configs[d.id] || {};
      if (!('apiKey' in cfg)) cfg.apiKey = cur.apiKey; // keep existing key unless explicitly sent
      await store.setProviderConfig(d.id, cfg); // trims, drops empty keys, persists immediately
      // SINGLE SOURCE OF TRUTH, fixed here: saving a usable key for a provider
      // while the ACTIVE provider has no usable key used to leave `active`
      // pointing at the keyless one — the agent then reported "Chưa cấu hình
      // API key" even though a key existed in storage.
      const providers = await store.getProviders();
      const activeCfg = providers.active && providers.configs[providers.active];
      const activeUsable = activeCfg && (activeCfg.apiKey || PROVIDERS[providers.active]?.noKey);
      const thisUsable = PROVIDERS[d.id]?.noKey || providers.configs[d.id]?.apiKey;
      if (thisUsable && !activeUsable) await store.setActiveProvider(d.id);
      return { providers: maskProviders(await store.getProviders()) };
    }

    case 'set_active_provider': {
      await store.setActiveProvider(d.id, d.fallback, d.fallbackEnabled);
      return { providers: maskProviders(await store.getProviders()) };
    }

    case 'test_provider': {
      const cfg = await resolveProviderCfg(d.id, d.cfg);
      return await testConnection(d.id, cfg);
    }

    case 'list_models': {
      const cfg = await resolveProviderCfg(d.id, d.cfg);
      return { models: await listModels(d.id, cfg) };
    }

    case 'get_shot': {
      const shot = getShot(d.shotId);
      if (!shot) throw new Error('screenshot expired (kept in memory only)');
      return { shot };
    }

    case 'get_artifact': {
      const art = getArtifact(d.artifactId);
      if (!art) throw new Error('artifact not found (artifacts live in memory for the session)');
      return { artifact: { id: art.id, name: art.name, mime: art.mime, size: art.size, text: art.text, base64: art.base64 } };
    }

    case 'terminal_status': return await nativeHost.hostStatus();

    case 'debug_detach': {
      if (d.tabId) await cdp.detach(d.tabId);
      else await cdp.detachAll();
      return { debugTabs: cdp.attachedIds() };
    }

    case 'list_tools': {
      const grouped = {};
      for (const t of listTools()) {
        (grouped[t.group] = grouped[t.group] || []).push({ name: t.name, risk: t.risk, description: t.description });
      }
      return { groups: grouped, total: listTools().length };
    }

    case 'wipe_all': {
      for (const rt of runtimes.values()) rt.stop();
      runtimes.clear();
      await store.wipeAll();
      emit(EVENTS.CONVERSATIONS_CHANGED, {});
      emit(EVENTS.SETTINGS_CHANGED, { settings: await store.getSettings() });
      return { ok: true };
    }

    case 'open_tab_url': {
      const tab = await chrome.tabs.create({ url: d.url, active: true });
      return { tabId: tab.id };
    }

    default: throw new Error('unknown command: ' + msg.cmd);
  }
}

async function setActiveConv(convId) {
  const raw = await store.loadStore();
  raw.prefs.activeConvId = convId;
  store.persist();
}

async function resolveProviderCfg(id, override) {
  const providers = await store.getProviders();
  const cfg = { ...(providers.configs[id] || {}), ...(override || {}) };
  if (override && !('apiKey' in override)) cfg.apiKey = providers.configs[id]?.apiKey;
  return cfg;
}

function maskProviders(providers) {
  const configs = {};
  for (const [id, cfg] of Object.entries(providers.configs || {})) {
    configs[id] = {
      base: cfg.base, model: cfg.model, visionModel: cfg.visionModel,
      hasKey: !!cfg.apiKey,
      keyPreview: cfg.apiKey ? '•••' + String(cfg.apiKey).slice(-4) : null,
    };
  }
  return { active: providers.active, fallback: providers.fallback, fallbackEnabled: providers.fallbackEnabled, configs };
}

function providerPresets() {
  const out = {};
  for (const [id, p] of Object.entries(PROVIDERS)) {
    out[id] = { name: p.name, base: p.base, model: p.model, vision: p.vision, noKey: !!p.noKey, keyUrl: p.keyUrl, note: p.note };
  }
  return out;
}

const SETTINGS_KEYS = new Set(Object.keys(store.DEFAULT_SETTINGS.settings));
function sanitizeSettings(patch) {
  const out = {};
  for (const [k, v] of Object.entries(patch)) if (SETTINGS_KEYS.has(k)) out[k] = v;
  return out;
}

/* ==================== selection & interference from content scripts ==================== */

let lastSelection = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  try {
  if (msg?.type === 'nova-selection') {
    lastSelection = { ...msg.payload, tabId: sender.tab?.id, url: sender.tab?.url };
    emit(EVENTS.SELECTION_CHANGED, { selection: lastSelection });
    sendResponse?.({ ok: true });
    return;
  }
  if (msg?.type === 'nova-human-interference') {
    emit(EVENTS.HUMAN_INTERFERENCE, { tabId: sender.tab?.id });
    const rt = runningRuntime();
    if (rt && rt.state === 'acting') {
      rt.pause();
      rt.feed({ t: 'note', kind: 'warn', text: 'Phát hiện bạn đang thao tác trực tiếp — agent tạm dừng. Nhấn Tiếp tục để agent chạy lại.' }).catch(() => { });
    }
    sendResponse?.({ ok: true });
    return;
  }
  if (msg?.type === 'nova-content-ready') { sendResponse?.({ ok: true }); return; }
  } catch (e) {
    // a throwing listener would drop the sender's sendResponse callback
    console.error('[nova] onMessage error', e);
    try { sendResponse?.({ ok: false, error: String(e?.message || e) }); } catch (e2) { }
  }
});

export function getLastSelection() { return lastSelection; }

/* ==================== context menus ==================== */

const MENUS = [
  { id: 'nova-ask', title: 'Hỏi Nova về đoạn này', contexts: ['selection'], mode: 'ask', tpl: s => s },
  { id: 'nova-explain', title: 'Giải thích đoạn này', contexts: ['selection'], mode: 'ask', tpl: s => `Giải thích ngắn gọn đoạn sau:\n\n"${s}"` },
  { id: 'nova-summarize', title: 'Tóm tắt đoạn này', contexts: ['selection'], mode: 'ask', tpl: s => `Tóm tắt đoạn sau:\n\n"${s}"` },
  { id: 'nova-research', title: 'Nghiên cứu sâu chủ đề này', contexts: ['selection'], mode: 'agent', tpl: s => `Nghiên cứu sâu chủ đề: ${s}` },
  { id: 'nova-translate', title: 'Dịch sang tiếng Việt', contexts: ['selection'], mode: 'ask', tpl: s => `Dịch sang tiếng Việt:\n\n"${s}"` },
  { id: 'nova-sep1', type: 'separator', contexts: ['page'] },
  { id: 'nova-analyze', title: 'Phân tích trang này', contexts: ['page'], mode: 'ask', tpl: () => 'Phân tích trang hiện tại: nội dung chính, cấu trúc, các hành động có thể thực hiện.' },
  { id: 'nova-agent-page', title: 'Chạy agent trên trang này…', contexts: ['page'], mode: 'agent', tpl: () => '' },
  { id: 'nova-screenshot', title: 'Chụp màn hình & phân tích', contexts: ['page'], mode: 'agent', tpl: () => 'Chụp màn hình trang hiện tại rồi mô tả những gì bạn thấy.' },
];

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    void chrome.runtime.lastError; // clear "unchecked lastError" noise
    for (const m of MENUS) {
      try { chrome.contextMenus.create({ id: m.id, title: m.title, contexts: m.contexts, type: m.type }, () => void chrome.runtime.lastError); }
      catch (e) { console.warn('[nova] menu create failed', m.id, e); }
    }
  });
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch (e) { }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const menu = MENUS.find(m => m.id === info.menuItemId);
  if (!menu) return;
  const selection = info.selectionText || lastSelection?.text || '';
  const text = menu.tpl(selection).slice(0, 4000);
  await chrome.storage.session.set({
    pendingAction: {
      type: 'context-task', mode: menu.mode, text,
      selection: selection ? { text: selection } : null,
      autoRun: !!text,
    },
  });
  try { await chrome.sidePanel.open({ windowId: tab?.windowId }); } catch (e) { }
});

/* ==================== keyboard commands ==================== */

chrome.commands.onCommand.addListener(async command => {
  if (command === 'stop-agent') {
    for (const rt of runtimes.values()) rt.stop();
  } else if (command === 'new-chat') {
    broadcast({ kind: 'event', event: 'NEW_CHAT', data: {} });
  }
});

/* ==================== tab tracking (context bar) ==================== */

async function emitTabChanged(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) return;
    // chỉ báo tab của cửa sổ ĐANG FOCUS — một tab "active" trong cửa sổ nền
    // (vd: popup, cửa sổ khác) từng làm context bar nhảy loạn mỗi lần nó load xong
    const win = await chrome.windows.get(tab.windowId);
    if (!win?.focused) return;
    emit(EVENTS.TAB_CHANGED, { tabId, url: tab.url, title: tab.title, favIconUrl: tab.favIconUrl });
  } catch (e) { }
}
chrome.tabs.onActivated.addListener(({ tabId }) => emitTabChanged(tabId));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete' || changeInfo.title || changeInfo.url) emitTabChanged(tabId);
});

/* ==================== keepalive ==================== */

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'nova-keepalive') { /* wake only — keeps SW alive during long tasks */ }
});

console.log('[nova] service worker ready ·', listTools().length, 'tools registered');
