/* Nova Agent Browser — storage layer (chrome.storage.local, schema v1).
 * Settings, providers (keys masked in UI), conversations, prefs, permissions. */

import { uid } from './util.js';

const KEY = 'nova-agent';
const SCHEMA_VERSION = 1;

/* v0.4: modes collapsed to two — ask (read-only Q&A) + agent (full control,
 * absorbing computer-use and research). Legacy values must never survive a
 * migration, otherwise the UI and run_task.mode diverge again. */
export const MODES = ['ask', 'agent'];
const LEGACY_MODE_MAP = { chat: 'ask', computer: 'agent', research: 'agent' };
export function normalizeMode(mode) {
  if (MODES.includes(mode)) return mode;
  return LEGACY_MODE_MAP[mode] || 'agent';
}

export const DEFAULT_SETTINGS = {
  version: SCHEMA_VERSION,
  settings: {
    defaultMode: 'agent',
    autonomy: 'assisted',            // manual | assisted | autonomous
    showActionOverlay: true,
    edgeLightning: true,
    showStatusBadge: true,
    showTimeline: true,
    autoTitle: true,
    enterSend: true,
    actionDelay: 'fast',             // natural | fast | instant
    maxSteps: 40,
    maxRetries: 2,
    maxRuntimeMin: 15,
    maxScreenshots: 24,
    visionQuality: 'balanced',       // low | balanced | high
    verification: 'standard',        // relaxed | standard | strict
    recovery: 'standard',            // conservative | standard | aggressive
    visionFallback: true,
    stream: true,
    streamAgent: true,               // stream step-by-step reasoning in agent modes
    loopGuard: true,                 // detect & break repetitive tool-call loops
    temperature: 0.4,
    maxTokens: 4096,
    reasoningEffort: 'off',          // off | low | medium | high — sent to reasoning-capable models only
    debuggerEnabled: false,          // master switch for chrome.debugger (CDP) tools
    terminalEnabled: false,
    terminalPolicy: 'ask-risky',     // ask-all | ask-risky | auto-safe
    terminalTimeout: 60,
    workspace: '~/nova-agent',
    toolPerms: {                     // allowed | ask | denied
      browser: 'allowed', screenshots: 'allowed', vision: 'allowed',
      downloads: 'ask', uploads: 'ask', files: 'allowed',
      terminal: 'ask', multitab: 'allowed', canvas: 'allowed',
      research: 'allowed', scripts: 'ask', cdp: 'ask',
    },
    includeContext: { page: true, screenshot: false, dom: true, a11y: true, selection: true },
    theme: 'light',                  // light (default since v0.6) | dark | system
    accent: 'mono',
    fontSize: 15,
    debug: false,
  },
  providers: {
    active: null,                    // provider id
    fallback: null,
    fallbackEnabled: true,
    configs: {},                     // id -> { apiKey, base, model, visionModel, customModels? }
  },
  conversations: {},                 // id -> conversation
  order: [],                         // conversation ids, most recent first
  usage: { input: 0, output: 0, calls: 0, byProvider: {} },
  memory: [],                        // long-term memory entries {id, text, tags, createdAt}
  prefs: { onboarded: false },
};

let cache = null;
let saveTimer = null;
let listeners = new Set();

export function onStoreChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function notify() { for (const fn of listeners) { try { fn(cache); } catch (e) { } } }

export async function loadStore() {
  if (cache) return cache;
  const raw = await chrome.storage.local.get(KEY);
  const data = raw[KEY];
  cache = migrate(data);
  return cache;
}

function migrate(data) {
  if (!data || typeof data !== 'object' || !data.version) return structuredClone(DEFAULT_SETTINGS);
  // v1 is current; future migrations go here
  const merged = structuredClone(DEFAULT_SETTINGS);
  const dSettings = (data.settings && typeof data.settings === 'object') ? data.settings : {};
  merged.settings = Object.assign(merged.settings, dSettings);
  // NOTE: merge into the CLONE — never into DEFAULT_SETTINGS (mutating the
  // singleton used to leak one session's perms/context into every fresh store)
  if (merged.settings.toolPerms && typeof merged.settings.toolPerms === 'object')
    merged.settings.toolPerms = Object.assign({}, DEFAULT_SETTINGS.settings.toolPerms, dSettings.toolPerms || {});
  else merged.settings.toolPerms = structuredClone(DEFAULT_SETTINGS.settings.toolPerms);
  if (merged.settings.includeContext && typeof merged.settings.includeContext === 'object')
    merged.settings.includeContext = Object.assign({}, DEFAULT_SETTINGS.settings.includeContext, dSettings.includeContext || {});
  else merged.settings.includeContext = structuredClone(DEFAULT_SETTINGS.settings.includeContext);
  const dProviders = (data.providers && typeof data.providers === 'object') ? data.providers : {};
  merged.providers = Object.assign(merged.providers, dProviders);
  if (!merged.providers.configs || typeof merged.providers.configs !== 'object') merged.providers.configs = {};
  // normalize keys: trim, drop empty/whitespace-only keys (they used to count as "hasKey")
  for (const [pid, cfg] of Object.entries(merged.providers.configs)) {
    if (!cfg || typeof cfg !== 'object') { delete merged.providers.configs[pid]; continue; }
    if (typeof cfg.apiKey === 'string') cfg.apiKey = cfg.apiKey.trim();
    if (!cfg.apiKey) delete cfg.apiKey;
  }
  merged.conversations = (data.conversations && typeof data.conversations === 'object') ? data.conversations : {};
  // normalize legacy modes everywhere they can hide (settings + every conv)
  merged.settings.defaultMode = normalizeMode(merged.settings.defaultMode);
  for (const c of Object.values(merged.conversations)) {
    if (c && typeof c === 'object') c.mode = normalizeMode(c.mode);
  }
  merged.order = Array.isArray(data.order) ? data.order.filter(id => merged.conversations[id]) : Object.keys(merged.conversations);
  merged.usage = Object.assign(merged.usage, data.usage || {});
  merged.memory = Array.isArray(data.memory) ? data.memory : [];
  merged.prefs = Object.assign(merged.prefs, data.prefs || {});
  merged.version = SCHEMA_VERSION;
  return merged;
}

export function persist(immediate = false) {
  clearTimeout(saveTimer);
  const write = async () => {
    // never throws: several call sites fire-and-forget persist(true) —
    // a rejection there would be an unhandled rejection in the SW
    try { await chrome.storage.local.set({ [KEY]: cache }); } catch (e) { console.error('[nova] persist failed', e); }
    notify();
  };
  if (immediate) return write();
  saveTimer = setTimeout(write, 250);
  return Promise.resolve();
}

/** Force-flush any pending debounced write NOW. Backs the side panel's explicit
 * "Lưu thay đổi" button: the user must get a hard guarantee that
 * chrome.storage.local has actually been written before we show "Đã lưu". */
export async function flushStore() {
  clearTimeout(saveTimer);
  saveTimer = null;
  if (!cache) await loadStore();
  await chrome.storage.local.set({ [KEY]: cache });
  notify();
}

export async function getSettings() { return (await loadStore()).settings; }
export async function updateSettings(patch) {
  const st = await loadStore();
  st.settings = deepMerge(st.settings, patch);
  persist();
  notify();
  return st.settings;
}
function deepMerge(a, b) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    out[k] = (v && typeof v === 'object' && !Array.isArray(v) && a && typeof a[k] === 'object') ? deepMerge(a[k], v) : v;
  }
  return out;
}

/* ---------- providers ---------- */
const PROVIDER_CFG_KEYS = ['apiKey', 'base', 'model', 'visionModel', 'customModels'];
export async function getProviders() { return (await loadStore()).providers; }
export async function setProviderConfig(id, cfg) {
  const st = await loadStore();
  if (!id || typeof id !== 'string') throw new Error('provider id required');
  const clean = {};
  for (const k of PROVIDER_CFG_KEYS) {
    if (!(k in (cfg || {}))) continue;
    let v = cfg[k];
    if (typeof v === 'string') v = v.trim();
    if (k === 'apiKey') {
      // explicit empty/whitespace key = remove the key; never store whitespace
      if (!v) { const cur = { ...(st.providers.configs[id] || {}) }; delete cur.apiKey; st.providers.configs[id] = cur; continue; }
    }
    clean[k] = v;
  }
  st.providers.configs[id] = Object.assign({}, st.providers.configs[id], clean);
  // provider config holds API keys → flush immediately; a debounced write can be
  // lost when the MV3 service worker is terminated right after "Lưu"
  await persist(true);
  notify();
  return st.providers.configs[id];
}
export async function setActiveProvider(id, fallback, fallbackEnabled) {
  const st = await loadStore();
  st.providers.active = id;
  if (fallback !== undefined) st.providers.fallback = fallback;
  if (fallbackEnabled !== undefined) st.providers.fallbackEnabled = fallbackEnabled;
  await persist(true);
  notify();
}

/* ---------- usage ---------- */
export async function addUsage(providerId, usage) {
  if (!usage) return;
  const st = await loadStore();
  const i = usage.prompt || usage.input || 0, o = usage.completion || usage.output || 0;
  st.usage.input += i; st.usage.output += o; st.usage.calls += 1;
  const bp = st.usage.byProvider[providerId] || { input: 0, output: 0, calls: 0 };
  bp.input += i; bp.output += o; bp.calls += 1;
  st.usage.byProvider[providerId] = bp;
  persist();
}

/* ---------- conversations ---------- */
export async function listConversations() {
  const st = await loadStore();
  return st.order.map(id => st.conversations[id]).filter(Boolean)
    .map(c => ({
      id: c.id, title: c.title, pinned: !!c.pinned, updatedAt: c.updatedAt, createdAt: c.createdAt,
      status: c.status, mode: c.mode, usage: c.usage, agent: c.agent,
      feedCount: (c.feed || []).length, artifacts: (c.artifacts || []).length,
    }));
}

export async function getConversation(id) {
  const st = await loadStore();
  return st.conversations[id] || null;
}

export async function createConversation({ mode = 'agent', title } = {}) {
  const st = await loadStore();
  mode = normalizeMode(mode);
  const id = uid();
  const conv = {
    id, title: title || 'Cuộc trò chuyện mới', pinned: false,
    createdAt: Date.now(), updatedAt: Date.now(),
    mode, status: 'idle',
    feed: [], artifacts: [], usage: { input: 0, output: 0, calls: 0 },
    agent: { state: 'idle', objective: null, startedAt: null, steps: 0, toolCalls: 0, tabs: [] },
    llm: [], // provider-facing message history (may contain tool calls)
  };
  st.conversations[id] = conv;
  st.order = [id, ...st.order.filter(x => x !== id)];
  await persist(true); // a brand-new conversation must survive an instant SW restart
  notify();
  return conv;
}

export async function updateConversation(id, patch, { reorder = false } = {}) {
  const st = await loadStore();
  const c = st.conversations[id];
  if (!c) return null;
  Object.assign(c, patch, { updatedAt: Date.now() });
  // only real activity (feed) reorders the list — status/usage updates used to
  // bounce the conversation to the top on every agent step
  if (reorder) st.order = [id, ...st.order.filter(x => x !== id)];
  persist();
  return c;
}

export async function deleteConversation(id) {
  const st = await loadStore();
  delete st.conversations[id];
  st.order = st.order.filter(x => x !== id);
  persist(true);
}

export async function clearConversations() {
  const st = await loadStore();
  st.conversations = {};
  st.order = [];
  persist(true);
}

/** Append or update a feed item; keeps storage bounded. */
export async function feedUpsert(convId, item) {
  const st = await loadStore();
  const c = st.conversations[convId];
  if (!c) return;
  const idx = c.feed.findIndex(x => x.id === item.id);
  if (idx >= 0) c.feed[idx] = { ...c.feed[idx], ...item };
  else {
    c.feed.push(item);
    // genuinely new activity → bubble the conversation to the top of the list
    st.order = [convId, ...st.order.filter(x => x !== convId)];
  }
  if (c.feed.length > 400) c.feed = c.feed.slice(-400);
  c.updatedAt = Date.now();
  persist();
  return item;
}

export async function addArtifact(convId, art) {
  const st = await loadStore();
  const c = st.conversations[convId];
  if (!c) return;
  c.artifacts.push(art);
  persist();
}

/* ---------- long-term memory ---------- */
const MEMORY_CAP = 200;
export async function listMemory() { return (await loadStore()).memory || []; }
export async function addMemory({ text, tags = [] }) {
  const st = await loadStore();
  const entry = { id: uid(), text: String(text).slice(0, 500), tags: (tags || []).map(t => String(t).slice(0, 30)).slice(0, 8), createdAt: Date.now() };
  st.memory = [entry, ...(st.memory || [])];
  // de-dupe near-identical entries, keep bounded
  const seen = new Set();
  st.memory = st.memory.filter(m => { const k = m.text.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, MEMORY_CAP);
  persist();
  return entry;
}
export async function searchMemory(query, limit = 8) {
  const mem = await listMemory();
  if (!query) return mem.slice(0, limit);
  const terms = String(query).toLowerCase().split(/\s+/).filter(w => w.length > 1);
  const scored = mem.map(m => {
    const hay = (m.text + ' ' + (m.tags || []).join(' ')).toLowerCase();
    const score = terms.reduce((n, t) => n + (hay.includes(t) ? 1 : 0), 0);
    return { m, score };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score || b.m.createdAt - a.m.createdAt);
  return scored.slice(0, limit).map(x => x.m);
}
export async function deleteMemory({ id, query }) {
  const st = await loadStore();
  const before = (st.memory || []).length;
  if (id) st.memory = (st.memory || []).filter(m => m.id !== id);
  else if (query) {
    const hits = new Set((await searchMemory(query, 5)).map(m => m.id));
    st.memory = (st.memory || []).filter(m => !hits.has(m.id));
  }
  persist();
  return { removed: before - (st.memory || []).length };
}

export async function wipeAll() {
  cache = structuredClone(DEFAULT_SETTINGS);
  await chrome.storage.local.clear();
  persist(true);
  notify();
}
