/* Nova Agent Browser — central tool registry.
 * The agent may only act through registered, schema-validated tools. */

const tools = new Map();

/**
 * registerTool({
 *   name, description, schema (JSON Schema object),
 *   group: 'browser'|'dom'|'vision'|'action'|'canvas'|'tabs'|'files'|'downloads'|'terminal'|'research'|'system',
 *   risk: 'low'|'medium'|'high',
 *   timeout: ms,
 *   execute: async (args, ctx) => result
 * })
 */
export function registerTool(def) {
  if (!def?.name || typeof def.execute !== 'function') throw new Error('invalid tool def');
  if (tools.has(def.name)) throw new Error('duplicate tool: ' + def.name);
  tools.set(def.name, {
    risk: 'low', group: 'browser', timeout: 30000, retries: 0,
    ...def,
  });
}

export function getTool(name) { return tools.get(name); }
export function listTools() { return [...tools.values()]; }

/** Compact tool descriptors for the LLM (function-calling schema). */
export function toolSchemas({ groups } = {}) {
  return listTools()
    .filter(t => !groups || groups.includes(t.group))
    .map(t => ({ name: t.name, description: t.description, schema: t.schema }));
}

/* ---------- minimal JSON-schema validator (no deps, CSP-safe) ---------- */
function validate(schema, args, path = '') {
  const errs = [];
  if (!schema) return errs;
  if (schema.type === 'object' || schema.properties) {
    if (typeof args !== 'object' || args === null || Array.isArray(args)) { errs.push(`${path || 'args'} must be object`); return errs; }
    for (const req of schema.required || []) {
      if (args[req] === undefined || args[req] === null || args[req] === '') errs.push(`missing required: ${path}${req}`);
    }
    for (const [k, spec] of Object.entries(schema.properties || {})) {
      const v = args[k];
      if (v === undefined) continue;
      const t = spec.type;
      if (t === 'string' && typeof v !== 'string') errs.push(`${path}${k} must be string`);
      if (t === 'number' && typeof v !== 'number') errs.push(`${path}${k} must be number`);
      if (t === 'integer' && !Number.isInteger(v)) errs.push(`${path}${k} must be integer`);
      if (t === 'boolean' && typeof v !== 'boolean') errs.push(`${path}${k} must be boolean`);
      if (t === 'array' && !Array.isArray(v)) errs.push(`${path}${k} must be array`);
      if (t === 'object' && (typeof v !== 'object' || v === null)) errs.push(`${path}${k} must be object`);
      if (spec.enum && !spec.enum.includes(v)) errs.push(`${path}${k} must be one of ${spec.enum.join('|')}`);
      if (t === 'object' && spec.properties) errs.push(...validate(spec, v, path + k + '.'));
      if (typeof v === 'number') {
        if (spec.minimum !== undefined && v < spec.minimum) errs.push(`${path}${k} < ${spec.minimum}`);
        if (spec.maximum !== undefined && v > spec.maximum) errs.push(`${path}${k} > ${spec.maximum}`);
      }
    }
  }
  return errs;
}

export function validateArgs(name, args) {
  const t = tools.get(name);
  if (!t) return [`unknown tool: ${name}`];
  return validate(t.schema, args || {});
}

/**
 * Execute with validation, timeout and normalized result.
 * Returns { success, data, error: {code,message,retryable}|null, meta }
 */
export async function executeTool(name, args, ctx = {}) {
  const t0 = Date.now();
  const tool = tools.get(name);
  if (!tool) {
    return { success: false, data: null, error: { code: 'UNKNOWN_TOOL', message: `unknown tool: ${name}`, retryable: false }, meta: meta(t0, ctx) };
  }
  const errs = validate(tool.schema, args || {});
  if (errs.length) {
    return { success: false, data: null, error: { code: 'BAD_ARGS', message: errs.join('; '), retryable: false }, meta: meta(t0, ctx) };
  }
  try {
    const data = await withTimeout(tool.execute(args || {}, ctx), tool.timeout, name);
    return { success: true, data, error: null, meta: meta(t0, ctx) };
  } catch (e) {
    return {
      success: false, data: null,
      error: { code: e.code || 'TOOL_ERROR', message: String(e.message || e).slice(0, 400), retryable: !!e.retryable },
      meta: meta(t0, ctx),
    };
  }
}

function withTimeout(promise, ms, name) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Object.assign(new Error(`${name} timed out after ${ms}ms`), { code: 'TIMEOUT', retryable: true })), ms);
    promise.then(v => { clearTimeout(timer); resolve(v); }, e => { clearTimeout(timer); reject(e); });
  });
}

const meta = (t0, ctx) => ({ duration: Date.now() - t0, timestamp: t0, tabId: ctx.tabId });
