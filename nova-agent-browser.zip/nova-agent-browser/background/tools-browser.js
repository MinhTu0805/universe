/* Nova Agent Browser — browser / vision / canvas / tab tools.
 * Every tool: schema + validation + timeout + structured result.
 * Action tools return a fresh post-observation (url/title/visible change). */

import { registerTool } from './tool-registry.js';
import { putShot, getShot, getArtifact } from './artifacts.js';
import { getSettings } from './storage.js';

/* ==================== tab & content-script plumbing ==================== */

const lastKnown = new Map(); // tabId -> {url, title}

export async function targetTabId(ctx) {
  if (ctx?.tabId) {
    // the remembered target may be gone (user closed it mid-task) — verify
    // before trusting it, otherwise every tool fails with TAB_GONE until the
    // agent happens to open a new tab itself
    try { await chrome.tabs.get(ctx.tabId); return ctx.tabId; }
    catch (e) { ctx.setTabId?.(null); /* fall through to the active tab */ }
  }
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) throw Object.assign(new Error('no active tab'), { code: 'NO_TAB' });
  ctx?.setTabId?.(tab.id);
  return tab.id;
}

export async function getTab(tabId) {
  try { return await chrome.tabs.get(tabId); }
  catch (e) { throw Object.assign(new Error('tab no longer exists'), { code: 'TAB_GONE' }); }
}

function restricted(url = '') {
  return /^(chrome|chrome-extension|edge|about|view-source|devtools):/i.test(url)
    || /chromewebstore\.google\.com/.test(url)
    || /^(file|ftp):/i.test(url);
}

async function pingCS(tabId) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { cmd: 'ping' });
    return !!res?.ok;
  } catch (e) { return false; }
}

async function injectCS(tabId) {
  await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content/content-bundle.js'] });
  await new Promise(r => setTimeout(r, 150));
}

/** Call a content-script function with auto-injection fallback. */
export async function callCS(tabId, module, fn, ...args) {
  const tab = await getTab(tabId);
  if (restricted(tab.url)) {
    throw Object.assign(new Error('This page is restricted by Chrome (chrome://, Web Store, file://). The agent cannot control it.'), { code: 'RESTRICTED_PAGE' });
  }
  if (!(await pingCS(tabId))) {
    try { await injectCS(tabId); } catch (e) {
      throw Object.assign(new Error('Cannot access this page: ' + (e.message || e)), { code: 'NO_ACCESS' });
    }
  }
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { cmd: 'call', module, fn, args });
  } catch (e) {
    // one retry after re-inject (page may have reloaded)
    try { await injectCS(tabId); res = await chrome.tabs.sendMessage(tabId, { cmd: 'call', module, fn, args }); }
    catch (e2) { throw Object.assign(new Error('content script unreachable: ' + (e2.message || e2)), { code: 'CS_UNREACHABLE', retryable: true }); }
  }
  if (!res?.ok) {
    const err = new Error(res?.error || 'content script error');
    err.code = res?.code || 'CS_ERROR';
    err.retryable = res?.code === 'STALE_REF' || res?.code === 'TIMEOUT';
    throw err;
  }
  return res.data;
}

export async function setOverlay(tabId, state, opts) {
  try { await chrome.tabs.sendMessage(tabId, { cmd: 'set-agent-state', active: state !== 'idle' && state !== 'stopped', overlay: state, opts }); }
  catch (e) { }
}

/* ==================== screenshots (vision pipeline) ==================== */

function qualityFor(q) { return { low: { f: 'jpeg', q: 55, maxDim: 1152 }, balanced: { f: 'jpeg', q: 72, maxDim: 1568 }, high: { f: 'jpeg', q: 88, maxDim: 2200 } }[q || 'balanced']; }

async function dataUrlToBitmap(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  return createImageBitmap(blob);
}
async function bitmapToJpeg(bmp, quality, maxDim) {
  let { width: w, height: h } = bmp;
  if (Math.max(w, h) > maxDim) { const s = maxDim / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s); }
  const oc = new OffscreenCanvas(w, h);
  oc.getContext('2d').drawImage(bmp, 0, 0, w, h);
  const blob = await oc.convertToBlob({ type: 'image/jpeg', quality });
  const buf = await blob.arrayBuffer();
  let bin = ''; const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return { dataUrl: 'data:image/jpeg;base64,' + btoa(bin), w, h };
}
async function cropJpeg(dataUrl, rect, quality, maxDim) {
  const bmp = await dataUrlToBitmap(dataUrl);
  // rect is in CSS px of viewport; scale to image px
  const info = rect._viewportW ? rect._viewportW : null;
  const scale = info ? bmp.width / info : 1;
  const sx = Math.max(0, Math.round(rect.x * scale)), sy = Math.max(0, Math.round(rect.y * scale));
  const sw = Math.min(bmp.width - sx, Math.round(rect.w * scale)), sh = Math.min(bmp.height - sy, Math.round(rect.h * scale));
  if (sw <= 0 || sh <= 0) throw new Error('crop region outside viewport');
  const oc = new OffscreenCanvas(sw, sh);
  oc.getContext('2d').drawImage(bmp, sx, sy, sw, sh, 0, 0, sw, sh);
  const blob = await oc.convertToBlob({ type: 'image/jpeg', quality });
  const buf = await blob.arrayBuffer();
  let bin = ''; const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return { dataUrl: 'data:image/jpeg;base64,' + btoa(bin), w: sw, h: sh };
}

/** Shared screenshot pipeline: compress → store → structured result.
 * Used by captureTab (chrome.tabs) and the CDP screenshot tool. */
export async function shotPipeline(dataUrl, meta = {}) {
  const settings = await getSettings();
  const q = qualityFor(settings.visionQuality);
  const out = await bitmapToJpeg(await dataUrlToBitmap(dataUrl), q.q, q.maxDim);
  const shotId = putShot(out.dataUrl, { imageW: out.w, imageH: out.h, ...meta });
  return { shotId, image: out.dataUrl, width: out.w, height: out.h, ...meta };
}

export async function captureTab(ctx, { crop } = {}) {
  const settings = await getSettings();
  const q = qualityFor(settings.visionQuality);
  const tabId = await targetTabId(ctx);
  const tab = await getTab(tabId);
  if (restricted(tab.url)) throw Object.assign(new Error('cannot screenshot a restricted page'), { code: 'RESTRICTED_PAGE' });
  if (!tab.active) await chrome.tabs.update(tabId, { active: true });
  await new Promise(r => setTimeout(r, 120));
  const raw = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: q.q });
  let out, page = null;
  try { page = await callCS(tabId, 'dom', 'getPageInfo'); } catch (e) { }
  if (crop) { crop._viewportW = page?.viewport?.w; out = await cropJpeg(raw, crop, q.q, q.maxDim); }
  else out = await bitmapToJpeg(await dataUrlToBitmap(raw), q.q, q.maxDim);
  const shotId = putShot(out.dataUrl, {
    tabId, url: tab.url, title: tab.title,
    imageW: out.w, imageH: out.h,
    viewport: page?.viewport, scroll: page?.scroll, dpr: page?.dpr,
  });
  return {
    shotId, image: out.dataUrl,
    width: out.w, height: out.h,
    viewport: page?.viewport, scroll: page?.scroll, dpr: page?.dpr,
    url: tab.url, title: tab.title,
    note: 'Coordinates in CSS px of the current viewport.',
  };
}

/* ==================== post-action observation ==================== */

async function postObserve(ctx, tabId, { before } = {}) {
  const settings = await getSettings();
  const delay = { instant: 120, fast: 420, natural: 900 }[settings.actionDelay || 'fast'];
  await new Promise(r => setTimeout(r, delay));
  let page = null;
  try { page = await callCS(tabId, 'dom', 'getPageInfo'); } catch (e) { }
  const tab = await getTab(tabId).catch(() => null);
  const after = { url: tab?.url, title: tab?.title, readyState: page?.readyState, scroll: page?.scroll };
  after.changed = !!(before && (before.url !== after.url || before.title !== after.title));
  return after;
}

async function beforeSnap(ctx) {
  try {
    const tabId = await targetTabId(ctx);
    const tab = await getTab(tabId);
    return { url: tab.url, title: tab.title };
  } catch (e) { return null; }
}

/* ==================== registration helper ==================== */
const tools = [];
function T(name, description, schema, opts, execute) {
  registerTool({ name, description, schema, ...opts, execute });
  tools.push(name);
}

const TARGET_PROPS = {
  ref: { type: 'string', description: 'Element ref from the latest observation, e.g. e12' },
  selector: { type: 'string', description: 'CSS selector (fallback)' },
  role: { type: 'string', description: 'ARIA role, e.g. button/link/textbox' },
  name: { type: 'string', description: 'Accessible name / label / button text' },
  text: { type: 'string', description: 'Visible text content (fallback)' },
  x: { type: 'number', description: 'CSS px from viewport left (last resort)' },
  y: { type: 'number', description: 'CSS px from viewport top (last resort)' },
};
const TARGET_SCHEMA = { type: 'object', properties: TARGET_PROPS };

/* ==================== tabs ==================== */

T('browser_get_current_tab', 'Get the tab the agent is working on (id, url, title, state).', { type: 'object', properties: {} },
  { group: 'tabs', risk: 'low' }, async (_, ctx) => {
    const tabId = await targetTabId(ctx);
    const tab = await getTab(tabId);
    return { id: tab.id, url: tab.url, title: tab.title, active: tab.active, status: tab.status, windowId: tab.windowId };
  });

T('browser_list_tabs', 'List open tabs in the current window with ids, urls, titles.', { type: 'object', properties: { all: { type: 'boolean', description: 'include all windows' } } },
  { group: 'tabs', risk: 'low' }, async ({ all }, ctx) => {
    const tabs = await chrome.tabs.query(all ? {} : { currentWindow: true });
    return tabs.map(t => ({ id: t.id, url: t.url, title: t.title, active: t.active, windowId: t.windowId, status: t.status }));
  });

T('browser_switch_tab', 'Switch the agent focus to another tab (by id, or title/url match).',
  { type: 'object', properties: { tabId: { type: 'number' }, title: { type: 'string' }, url: { type: 'string' } } },
  { group: 'tabs', risk: 'low' }, async ({ tabId, title, url }, ctx) => {
    let target = tabId;
    if (!target) {
      const tabs = await chrome.tabs.query({});
      const t = tabs.find(t => title && t.title?.toLowerCase().includes(title.toLowerCase())) || tabs.find(t => url && t.url?.includes(url));
      if (!t) throw new Error('no matching tab');
      target = t.id;
    }
    const tab = await chrome.tabs.update(target, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    ctx.setTabId?.(target);
    lastKnown.set(target, { url: tab.url, title: tab.title });
    return { id: tab.id, url: tab.url, title: tab.title };
  });

T('browser_open_tab', 'Open a new tab (optionally with a URL) and make it the agent target.',
  { type: 'object', properties: { url: { type: 'string' }, active: { type: 'boolean' } } },
  { group: 'tabs', risk: 'low' }, async ({ url, active = true }, ctx) => {
    const tab = await chrome.tabs.create({ url: url || 'about:blank', active });
    if (active) ctx.setTabId?.(tab.id);
    return { id: tab.id, url: tab.url || url, status: tab.status };
  });

T('browser_close_tab', 'Close a tab by id (defaults to the agent target tab).',
  { type: 'object', properties: { tabId: { type: 'number' } } },
  { group: 'tabs', risk: 'medium' }, async ({ tabId }, ctx) => {
    const id = tabId || await targetTabId(ctx);
    await chrome.tabs.remove(id);
    return { closed: id };
  });

T('browser_duplicate_tab', 'Duplicate a tab (by id, default the agent target tab).',
  { type: 'object', properties: { tabId: { type: 'number' } } },
  { group: 'tabs', risk: 'low' }, async ({ tabId }, ctx) => {
    const id = tabId || await targetTabId(ctx);
    const t = await chrome.tabs.duplicate(id);
    return { id: t.id, url: t.url, title: t.title };
  });

T('browser_organize_tabs', 'Group tabs by site domain into colored tab groups (research cleanup). Optionally only in the current window.',
  { type: 'object', properties: { currentWindowOnly: { type: 'boolean' } } },
  { group: 'tabs', risk: 'low' }, async ({ currentWindowOnly = true } = {}) => {
    const tabs = await chrome.tabs.query(currentWindowOnly ? { currentWindow: true } : {});
    const byDomain = new Map();
    for (const t of tabs) {
      if (!t.id || t.pinned) continue;
      let host = '';
      try { host = new URL(t.url).hostname.replace(/^www\./, ''); } catch (e) { continue; }
      if (!host) continue;
      if (!byDomain.has(host)) byDomain.set(host, []);
      byDomain.get(host).push(t.id);
    }
    const COLORS = ['blue', 'cyan', 'green', 'yellow', 'orange', 'red', 'pink', 'purple'];
    const groups = [];
    let ci = 0;
    for (const [host, ids] of byDomain) {
      if (ids.length < 2) continue; // only group domains with multiple tabs
      try {
        const groupId = await chrome.tabs.group({ tabIds: ids });
        const title = host.split('.')[0].slice(0, 12);
        await chrome.tabGroups.update(groupId, { title, color: COLORS[ci++ % COLORS.length], collapsed: ids.length > 4 });
        groups.push({ host, tabs: ids.length, groupId });
      } catch (e) { }
    }
    return { groups, groupedTabs: groups.reduce((n, g) => n + g.tabs, 0) };
  });

/* ==================== navigation ==================== */

T('browser_navigate', 'Navigate the target tab to a URL and wait for load.',
  { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] },
  { group: 'browser', risk: 'low' }, async ({ url }, ctx) => {
    const tabId = await targetTabId(ctx);
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    const done = waitNav(tabId, 20000);
    await chrome.tabs.update(tabId, { url });
    await done;
    const after = await postObserve(ctx, tabId);
    return { navigated: true, ...after };
  });

T('browser_go_back', 'Go back in history.', { type: 'object', properties: {} },
  { group: 'browser', risk: 'low' }, async (_, ctx) => {
    const tabId = await targetTabId(ctx);
    const before = await beforeSnap(ctx);
    await chrome.tabs.goBack(tabId);
    return postObserve(ctx, tabId, { before });
  });

T('browser_go_forward', 'Go forward in history.', { type: 'object', properties: {} },
  { group: 'browser', risk: 'low' }, async (_, ctx) => {
    const tabId = await targetTabId(ctx);
    const before = await beforeSnap(ctx);
    try { await chrome.tabs.goForward(tabId); } catch (e) { throw new Error('cannot go forward'); }
    return postObserve(ctx, tabId, { before });
  });

T('browser_reload', 'Reload the target tab.', { type: 'object', properties: { hard: { type: 'boolean' } } },
  { group: 'browser', risk: 'low' }, async ({ hard }, ctx) => {
    const tabId = await targetTabId(ctx);
    const done = waitNav(tabId, 20000);
    await chrome.tabs.reload(tabId, { bypassCache: !!hard });
    await done;
    return postObserve(ctx, tabId);
  });

T('browser_wait', 'Wait N milliseconds (for animations, debounce, etc.). Prefer wait_for_* tools when possible.',
  { type: 'object', properties: { ms: { type: 'number', minimum: 100, maximum: 30000 } }, required: ['ms'] },
  { group: 'browser', risk: 'low' }, async ({ ms }) => { await new Promise(r => setTimeout(r, ms)); return { waited: ms }; });

function waitNav(tabId, timeout = 20000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => { chrome.webNavigation.onCompleted.removeListener(l); resolve(false); }, timeout);
    function l(details) {
      if (details.tabId === tabId && details.frameId === 0) {
        clearTimeout(timer);
        chrome.webNavigation.onCompleted.removeListener(l);
        resolve(true);
      }
    }
    chrome.webNavigation.onCompleted.addListener(l);
  });
}

T('browser_wait_for_navigation', 'Wait until the target tab finishes a navigation (or timeout).',
  { type: 'object', properties: { timeout: { type: 'number' } } },
  { group: 'browser', risk: 'low' }, async ({ timeout = 15000 }, ctx) => {
    const tabId = await targetTabId(ctx);
    const okDone = await waitNav(tabId, timeout);
    return { completed: okDone, ...(await postObserve(ctx, tabId)) };
  });

/* ==================== observation / DOM ==================== */

T('browser_get_page_info', 'URL, title, viewport, scroll position, element counts of the target tab.',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'dom', 'getPageInfo'));

T('browser_get_dom', 'Compact list of interactive elements (refs, roles, names, positions). Viewport-scoped by default.',
  { type: 'object', properties: { all: { type: 'boolean', description: 'scan whole page instead of viewport' }, max: { type: 'number' } } },
  { group: 'dom', risk: 'low' }, async ({ all, max } = {}, ctx) => callCS(await targetTabId(ctx), 'dom', 'getDOMSummary', { viewportOnly: !all, max }));

T('browser_get_visible_text', 'Readable text content of the page (truncated).',
  { type: 'object', properties: { maxChars: { type: 'number' } } },
  { group: 'dom', risk: 'low' }, async ({ maxChars } = {}, ctx) => callCS(await targetTabId(ctx), 'dom', 'getVisibleText', { maxChars }));

T('browser_get_accessibility_tree', 'Simplified accessibility tree: role "name" [state] with element refs. Best first perception step.',
  { type: 'object', properties: { maxNodes: { type: 'number' }, all: { type: 'boolean' } } },
  { group: 'dom', risk: 'low' }, async ({ maxNodes, all } = {}, ctx) => callCS(await targetTabId(ctx), 'a11y', 'getTree', { maxNodes, viewportOnly: !all }));

T('browser_find_element', 'Find elements by ref / css selector / role+name / visible text. Returns refs and bounds for acting.',
  { type: 'object', properties: { ...TARGET_PROPS, index: { type: 'number' }, all: { type: 'boolean' } } },
  { group: 'dom', risk: 'low' }, async (args, ctx) => callCS(await targetTabId(ctx), 'dom', 'findElements', args, { viewportOnly: !args.all }));

T('browser_find_text', 'Find visible text occurrences on the page (with refs to scroll/click).',
  { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
  { group: 'dom', risk: 'low' }, async ({ text }, ctx) => callCS(await targetTabId(ctx), 'dom', 'findText', text, {}));

T('browser_get_links', 'List visible links (text + href).',
  { type: 'object', properties: { all: { type: 'boolean' } } },
  { group: 'dom', risk: 'low' }, async ({ all } = {}, ctx) => callCS(await targetTabId(ctx), 'dom', 'getLinks', { viewportOnly: !all }));

T('browser_get_images', 'List visible images (src, alt, size).',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'dom', 'getImages', {}));

T('browser_get_forms', 'List forms with fields (labels, types, required, sensitive flags).',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'dom', 'getForms', {}));

T('browser_get_tables', 'List data tables on the page.',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'dom', 'getTables', {}));

T('browser_extract_table', 'Extract a table as columns+rows (for datasets / spreadsheets).',
  { type: 'object', properties: { ref: { type: 'string' }, selector: { type: 'string' }, index: { type: 'number' } } },
  { group: 'dom', risk: 'low' }, async (args, ctx) => callCS(await targetTabId(ctx), 'dom', 'extractTable', args));

T('browser_get_selected_text', 'Text the user has currently selected on the page.',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'dom', 'getSelectionContext'));

T('browser_reader_mode', 'Extract the main article content of the page as clean reading text (title, byline, paragraphs). Best for long articles/docs — much denser than get_visible_text.',
  { type: 'object', properties: { maxChars: { type: 'number' } } },
  { group: 'dom', risk: 'low' }, async ({ maxChars } = {}, ctx) => callCS(await targetTabId(ctx), 'dom', 'getReaderText', { maxChars }));

T('browser_console_errors', 'Read console errors/warnings, uncaught exceptions and failed resource loads captured on the page. Use to debug why a page/action is broken.',
  { type: 'object', properties: { level: { type: 'string', enum: ['error', 'warn'] }, limit: { type: 'number' } } },
  { group: 'dom', risk: 'low' }, async (args, ctx) => callCS(await targetTabId(ctx), 'diag', 'getErrors', args || {}));

T('browser_performance', 'Page performance snapshot: load timings, slow resources, JS heap. Use when a page feels stuck or slow.',
  { type: 'object', properties: {} },
  { group: 'dom', risk: 'low' }, async (_, ctx) => callCS(await targetTabId(ctx), 'diag', 'getPerf'));

/* ==================== actions ==================== */

async function actCommon(ctx, fn, ...args) {
  const tabId = await targetTabId(ctx);
  const before = await beforeSnap(ctx);
  const out = await callCS(tabId, 'act', fn, ...args);
  const after = await postObserve(ctx, tabId, { before });
  return { ...out, after };
}

T('browser_click', 'Click an element (ref | role+name | text | selector | x,y). Semantic targets preferred.',
  { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'medium' }, async (args, ctx) => {
    const tabId = await targetTabId(ctx);
    const before = await beforeSnap(ctx);
    const settings = await getSettings();
    if (settings.showActionOverlay && !args.x) {
      try {
        const { matches } = await callCS(tabId, 'dom', 'findElements', args, {});
        if (matches?.[0]) await chrome.tabs.sendMessage(tabId, { cmd: 'overlay', action: 'highlight', ref: matches[0].ref, opts: { label: args.name || args.text || 'click', ms: 650 } });
        await new Promise(r => setTimeout(r, 220));
      } catch (e) { }
    }
    const out = await callCS(tabId, 'act', 'click', args, {});
    return { ...out, after: await postObserve(ctx, tabId, { before }) };
  });

T('browser_double_click', 'Double-click an element.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'medium' }, async (args, ctx) => actCommon(ctx, 'click', args, { dblclick: true }));

T('browser_right_click', 'Right-click (context menu) an element.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'medium' }, async (args, ctx) => actCommon(ctx, 'click', args, { button: 2 }));

T('browser_hover', 'Hover over an element (reveals menus/tooltips).', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'low' }, async (args, ctx) => actCommon(ctx, 'hover', args));

T('browser_focus', 'Focus an input/element.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'low' }, async (args, ctx) => actCommon(ctx, 'focus', args));

T('browser_type', 'Type text into an input/textarea/contenteditable (framework-safe). Use clear:true to replace. Never type into SENSITIVE fields without user approval.',
  { type: 'object', properties: { ...TARGET_PROPS, text: { type: 'string' }, clear: { type: 'boolean' }, append: { type: 'boolean' }, perChar: { type: 'boolean', description: 'send per-key events (for autocomplete fields)' } }, required: ['text'] },
  { group: 'action', risk: 'medium' }, async (args, ctx) => {
    const tabId = await targetTabId(ctx);
    // sensitive detection → flag for policy layer on retry
    try {
      const { matches } = await callCS(tabId, 'dom', 'findElements', args, {});
      if (matches?.[0]?.sensitive) args.sensitive = true;
    } catch (e) { }
    const before = await beforeSnap(ctx);
    const out = await callCS(tabId, 'act', 'type', args, args.text || '', { clear: args.clear, append: args.append, perChar: args.perChar, delay: 12 });
    return { ...out, text: undefined, typed: out.typed, after: await postObserve(ctx, tabId, { before }) };
  });

T('browser_clear_input', 'Clear an input field.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'low' }, async (args, ctx) => actCommon(ctx, 'clearInput', args));

T('browser_fill_form', 'Fill multiple form fields in ONE call: fields = [{ref|selector|name, value, clear?}]. Much faster than repeated browser_type. Sensitive fields (password/OTP) require approval — set sensitive:true.',
  {
    type: 'object',
    properties: {
      fields: {
        type: 'array',
        description: 'list of {ref?, selector?, name?, value, clear?, perChar?, sensitive?}',
      },
      submit: { type: 'boolean', description: 'also submit the form after filling (high risk → approval)' },
    },
    required: ['fields'],
  },
  { group: 'action', risk: 'medium', timeout: 60000 }, async ({ fields = [], submit }, ctx) => {
    if (!Array.isArray(fields) || !fields.length) throw new Error('fields must be a non-empty array');
    if (fields.length > 30) throw new Error('too many fields (max 30)');
    const tabId = await targetTabId(ctx);
    const before = await beforeSnap(ctx);
    const results = [];
    let anySensitive = false;
    for (const f of fields) {
      const { value, clear = true, perChar, sensitive, ...target } = f || {};
      if (value === undefined) { results.push({ target: target.ref || target.selector || target.name, ok: false, error: 'missing value' }); continue; }
      try {
        // sensitive detection → flags the whole call for the policy layer
        let isSens = !!sensitive;
        try {
          const { matches } = await callCS(tabId, 'dom', 'findElements', target, {});
          if (matches?.[0]?.sensitive) isSens = true;
        } catch (e) { }
        if (isSens) anySensitive = true;
        await callCS(tabId, 'act', 'type', { ...target, sensitive: isSens }, String(value), { clear, perChar, delay: 10 });
        results.push({ target: target.ref || target.selector || target.name || target.text, ok: true, sensitive: isSens || undefined });
      } catch (e) {
        results.push({ target: target.ref || target.selector || target.name, ok: false, error: String(e.message || e).slice(0, 120) });
      }
    }
    let submitted = false;
    if (submit && results.every(r => r.ok)) {
      await callCS(tabId, 'act', 'submit', fields[0], {});
      submitted = true;
    }
    const filled = results.filter(r => r.ok).length;
    return { filled, failed: results.length - filled, results, submitted, sensitive: anySensitive || undefined, after: await postObserve(ctx, tabId, { before }) };
  });

T('browser_press_key', 'Press a single key (Enter, Escape, Tab, Backspace, ArrowUp/Down/Left/Right, Home, End, PageUp, PageDown, Space, or a character).',
  { type: 'object', properties: { key: { type: 'string' }, ...TARGET_PROPS }, required: ['key'] },
  { group: 'action', risk: 'medium' }, async ({ key, ...target }, ctx) => actCommon(ctx, 'pressKey', key, target));

T('browser_key_combo', 'Press a key combo, e.g. ["ctrl","a"] or ["ctrl","shift","p"].',
  { type: 'object', properties: { keys: { type: 'array' }, ...TARGET_PROPS }, required: ['keys'] },
  { group: 'action', risk: 'medium' }, async ({ keys, ...target }, ctx) => actCommon(ctx, 'keyCombo', keys, target));

T('browser_scroll', 'Scroll the page or a container. direction up/down, or to top/bottom, or to text, or explicit deltas.',
  { type: 'object', properties: { direction: { type: 'string', enum: ['up', 'down'] }, to: { type: 'string', enum: ['top', 'bottom'] }, text: { type: 'string' }, deltaY: { type: 'number' }, deltaX: { type: 'number' }, ref: { type: 'string' }, selector: { type: 'string' } } },
  { group: 'action', risk: 'low' }, async (args, ctx) => actCommon(ctx, 'scroll', args));

T('browser_drag', 'Drag from one point/element to another with a human-like path (sortable lists, maps, custom drag UIs). For sliders & puzzle pieces prefer browser_slide.',
  { type: 'object', properties: { from: { type: 'object' }, to: { type: 'object' }, steps: { type: 'number' } }, required: ['from', 'to'] },
  { group: 'action', risk: 'medium' }, async (args, ctx) => actCommon(ctx, 'drag', args.from, args.to, { steps: args.steps }));

T('browser_slide', 'Drag a SLIDER handle or a jigsaw/PUZZLE PIECE into place — for pages that ask the user to slide a piece/handle to answer a question or unlock content (non-CAPTCHA). handle = the knob/piece (required). Destination priority: `to` (element/point, e.g. the gap) > dx/dy (px) > omitted = full track travel. Human-like path (accelerate→decelerate, slight jitter). ALWAYS verify with browser_screenshot afterwards and nudge again with small dx/dy if undershot. If the handle barely moved (synthetic events blocked), use browser_debug_drag instead (trusted CDP input). NEVER use this to bypass CAPTCHAs — call ask_user for those.',
  {
    type: 'object',
    properties: {
      handle: { type: 'object', properties: TARGET_PROPS, description: 'the slider knob / puzzle piece (ref preferred, or selector / role+name / x,y)' },
      to: { type: 'object', properties: TARGET_PROPS, description: 'destination: puzzle gap / target element or point (optional)' },
      dx: { type: 'number', description: 'horizontal distance in px (positive = right)' },
      dy: { type: 'number', description: 'vertical distance in px (positive = down)' },
      axis: { type: 'string', enum: ['auto', 'x', 'y'], description: 'lock movement axis (auto = detect / both when `to` is given)' },
      steps: { type: 'number', description: 'movement resolution (default 28; higher = smoother)' },
    },
    required: ['handle'],
  },
  { group: 'action', risk: 'medium', timeout: 45000 }, async (args, ctx) => actCommon(ctx, 'slide', args));

T('browser_select', 'Select an option in a <select> by value/label/index.',
  { type: 'object', properties: { ...TARGET_PROPS, value: { type: 'string' }, label: { type: 'string' }, index: { type: 'number' } } },
  { group: 'action', risk: 'medium' }, async (args, ctx) => { const { value, label, index, ...t } = args; return actCommon(ctx, 'selectOption', t, { value, label, index }); });

T('browser_check', 'Check a checkbox/switch.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'medium' }, async (args, ctx) => actCommon(ctx, 'setChecked', args, true));

T('browser_uncheck', 'Uncheck a checkbox.', { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'medium' }, async (args, ctx) => actCommon(ctx, 'setChecked', args, false));

T('browser_submit', 'Submit a form (high-risk: sends data). Requires user approval.',
  { type: 'object', properties: TARGET_PROPS },
  { group: 'action', risk: 'high' }, async (args, ctx) => actCommon(ctx, 'submit', args));

T('browser_wait_for_element', 'Wait until a selector or text appears (for SPAs/async content).',
  { type: 'object', properties: { selector: { type: 'string' }, text: { type: 'string' }, timeout: { type: 'number' } } },
  { group: 'browser', risk: 'low' }, async (args, ctx) => callCS(await targetTabId(ctx), 'act', 'waitFor', args));

T('browser_execute_script', 'Run a whitelisted DOM micro-op (query/text/attr/setAttr/remove/clickAll/count) as JSON. High-risk, approval required.',
  { type: 'object', properties: { op: { type: 'object', description: '{op, selector, name?, value?}' } }, required: ['op'] },
  { group: 'scripts', risk: 'high' }, async ({ op }, ctx) => callCS(await targetTabId(ctx), 'act', 'executeScript', op));

/* ==================== vision ==================== */

T('browser_screenshot', 'Capture the visible viewport (image is attached for the vision model). Includes viewport/scroll/DPR calibration.',
  { type: 'object', properties: {} },
  { group: 'vision', risk: 'low' }, async (_, ctx) => captureTab(ctx));

T('browser_screenshot_region', 'Capture a region of the viewport (x,y,w,h in CSS px).',
  { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' }, w: { type: 'number' }, h: { type: 'number' } }, required: ['x', 'y', 'w', 'h'] },
  { group: 'vision', risk: 'low' }, async (args, ctx) => captureTab(ctx, { crop: args }));

T('browser_screenshot_element', 'Capture a specific element (ref/selector/role+name).',
  { type: 'object', properties: TARGET_PROPS },
  { group: 'vision', risk: 'low' }, async (args, ctx) => {
    const tabId = await targetTabId(ctx);
    const { matches } = await callCS(tabId, 'dom', 'findElements', args, {});
    if (!matches?.length) throw new Error('element not found for screenshot');
    const b = matches[0].bounds;
    return captureTab(ctx, { crop: { x: b.x, y: b.y, w: b.w, h: b.h } });
  });

T('browser_compare_screenshot', 'Capture a fresh screenshot and return it alongside an earlier shot (by shotId) for visual verification.',
  { type: 'object', properties: { previousShotId: { type: 'string' } }, required: ['previousShotId'] },
  { group: 'vision', risk: 'low' }, async ({ previousShotId }, ctx) => {
    const prev = getShot(previousShotId);
    if (!prev) throw new Error('previous screenshot not found (expired)');
    const fresh = await captureTab(ctx);
    return { ...fresh, images: [{ label: 'before', dataUrl: prev.dataUrl }, { label: 'after', dataUrl: fresh.image }], note: 'Compare before/after and confirm the visual change.' };
  });

/* ==================== downloads / uploads ==================== */

function waitDownloadComplete(id, timeout = 90000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { chrome.downloads.onChanged.removeListener(l); reject(Object.assign(new Error('download timeout'), { code: 'TIMEOUT', retryable: true })); }, timeout);
    function l(delta) {
      if (delta.id !== id) return;
      if (delta.state?.current === 'complete') { chrome.downloads.onChanged.removeListener(l); clearTimeout(timer); resolve(true); }
      if (delta.state?.current === 'interrupted') { chrome.downloads.onChanged.removeListener(l); clearTimeout(timer); reject(new Error('download interrupted: ' + (delta.error?.current || 'unknown'))); }
    }
    chrome.downloads.onChanged.addListener(l);
  });
}

T('browser_download', 'Download a file: direct {url} or click a download {ref}/button and wait for the file.',
  { type: 'object', properties: { url: { type: 'string' }, filename: { type: 'string' }, ...TARGET_PROPS } },
  { group: 'downloads', risk: 'medium', timeout: 120000 }, async (args, ctx) => {
    const startedAfter = Date.now() - 1000;
    if (args.url) {
      const id = await chrome.downloads.download({ url: args.url, filename: args.filename, saveAs: false });
      await waitDownloadComplete(id);
      const [item] = await chrome.downloads.search({ id });
      return { downloaded: true, filename: item.filename, size: item.fileSize, mime: item.mime, url: item.url };
    }
    // click-triggered
    const before = await beforeSnap(ctx);
    const tabId = await targetTabId(ctx);
    await callCS(tabId, 'act', 'click', args, {});
    const t0 = Date.now();
    let item = null;
    while (Date.now() - t0 < 30000) {
      const items = await chrome.downloads.search({ orderBy: ['-startTime'], limit: 5 });
      const cand = items.find(i => new Date(i.startTime).getTime() >= startedAfter);
      if (cand) { item = cand; break; }
      await new Promise(r => setTimeout(r, 500));
    }
    if (!item) throw Object.assign(new Error('no download started after click'), { code: 'NO_DOWNLOAD', retryable: true });
    if (item.state !== 'complete') await waitDownloadComplete(item.id);
    const [done] = await chrome.downloads.search({ id: item.id });
    return { downloaded: true, filename: done.filename, size: done.fileSize, mime: done.mime, url: done.url, after: await postObserve(ctx, tabId, { before }) };
  });

T('browser_get_downloads', 'List recent downloads (name, size, state, path).',
  { type: 'object', properties: { limit: { type: 'number' } } },
  { group: 'downloads', risk: 'low' }, async ({ limit = 10 }) => {
    const items = await chrome.downloads.search({ orderBy: ['-startTime'], limit });
    return items.map(i => ({ id: i.id, filename: i.filename, size: i.fileSize, mime: i.mime, state: i.state, startTime: i.startTime, url: i.url }));
  });

T('browser_upload', 'Upload an agent-created artifact into a file input on the page (by ref/selector + artifactId or artifact name).',
  { type: 'object', properties: { ...TARGET_PROPS, artifactId: { type: 'string' }, artifactName: { type: 'string' } } },
  { group: 'uploads', risk: 'high' }, async (args, ctx) => {
    let art = args.artifactId ? getArtifact(args.artifactId) : null;
    if (!art && args.artifactName) {
      const { findArtifactByName } = await import('./artifacts.js');
      art = findArtifactByName(args.artifactName);
    }
    if (!art) throw new Error('artifact not found — create it first with artifact_create');
    const base64 = art.base64 || btoa(unescape(encodeURIComponent(art.text || '')));
    const tabId = await targetTabId(ctx);
    const before = await beforeSnap(ctx);
    const out = await callCS(tabId, 'act', 'uploadFiles', args, [{ name: art.name, type: art.mime, base64 }]);
    return { ...out, after: await postObserve(ctx, tabId, { before }) };
  });

/* ==================== canvas (computer use) ==================== */

T('canvas_list', 'List canvases on the page (id, bounds, css/pixel size, scale).',
  { type: 'object', properties: {} },
  { group: 'canvas', risk: 'low' }, async (_, ctx) => ({ canvases: await callCS(await targetTabId(ctx), 'canvas', 'list') }));

T('canvas_inspect', 'Inspect a canvas: bounds, pixel size, context type, scale, DPR.',
  { type: 'object', properties: { id: { type: 'string', description: 'canvas id from canvas_list; omit for first visible canvas' } } },
  { group: 'canvas', risk: 'low' }, async ({ id } = {}, ctx) => callCS(await targetTabId(ctx), 'canvas', 'inspect', id));

/* canvas actions reach NC.canvas directly; args order is explicit per tool */
function canvasTool(name, desc, props, required, mapArgs, risk = 'medium') {
  registerTool({
    name, description: desc, group: 'canvas', risk, timeout: 30000,
    schema: { type: 'object', properties: props, required },
    execute: async (args, ctx) => {
      const tabId = await targetTabId(ctx);
      const before = await beforeSnap(ctx);
      const [fnName, callArgs] = mapArgs(args);
      const out = await callCS(tabId, 'canvas', fnName, ...callArgs);
      return { ...out, after: await postObserve(ctx, tabId, { before }) };
    },
  });
  tools.push(name);
}

export function registerCanvasTools() {
  const P = { id: { type: 'string' }, x: { type: 'number' }, y: { type: 'number' } };
  canvasTool('canvas_click', 'Click inside a canvas at canvas-relative CSS px (x,y).', P, ['x', 'y'], a => ['click', [a.id, a.x, a.y]]);
  canvasTool('canvas_double_click', 'Double-click inside a canvas.', P, ['x', 'y'], a => ['dblclick', [a.id, a.x, a.y]]);
  canvasTool('canvas_move', 'Move the pointer over a canvas (hover).', P, ['x', 'y'], a => ['move', [a.id, a.x, a.y]], 'low');
  canvasTool('canvas_mouse_down', 'Press mouse button down on canvas.', { ...P, button: { type: 'number' } }, ['x', 'y'], a => ['down', [a.id, a.x, a.y, a.button ?? 0]]);
  canvasTool('canvas_mouse_up', 'Release mouse button on canvas.', { ...P, button: { type: 'number' } }, ['x', 'y'], a => ['up', [a.id, a.x, a.y, a.button ?? 0]]);
  canvasTool('canvas_drag', 'Drag inside a canvas from (x1,y1) to (x2,y2), canvas-relative CSS px.',
    { id: { type: 'string' }, x1: { type: 'number' }, y1: { type: 'number' }, x2: { type: 'number' }, y2: { type: 'number' }, steps: { type: 'number' } },
    ['x1', 'y1', 'x2', 'y2'], a => ['drag', [a.id, a.x1, a.y1, a.x2, a.y2, { steps: a.steps }]]);
  canvasTool('canvas_draw', 'Draw a polyline path on a canvas: points [{x,y}, ...] canvas-relative CSS px (pen down → move → pen up).',
    { id: { type: 'string' }, points: { type: 'array' }, close: { type: 'boolean' } },
    ['points'], a => ['draw', [a.id, a.points, { close: a.close }]]);
  canvasTool('canvas_select_region', 'Drag-select a rectangular region on a canvas (x,y,w,h canvas-relative).',
    { id: { type: 'string' }, x: { type: 'number' }, y: { type: 'number' }, w: { type: 'number' }, h: { type: 'number' } },
    ['x', 'y', 'w', 'h'], a => ['selectRegion', [a.id, a.x, a.y, a.w, a.h]]);
  canvasTool('canvas_scroll', 'Wheel-scroll inside a canvas (zoom/pan in editors, maps).',
    { id: { type: 'string' }, x: { type: 'number' }, y: { type: 'number' }, deltaY: { type: 'number' } },
    ['x', 'y', 'deltaY'], a => ['scroll', [a.id, a.x, a.y, a.deltaY]], 'low');
  canvasTool('canvas_keypress', 'Send a key to a focused canvas.',
    { id: { type: 'string' }, key: { type: 'string' } }, ['key'], a => ['keypress', [a.id, a.key]]);
}

T('canvas_screenshot', 'Screenshot a canvas element (vision verification for drawing tasks).',
  { type: 'object', properties: { id: { type: 'string' } } },
  { group: 'canvas', risk: 'low' }, async ({ id } = {}, ctx) => {
    const tabId = await targetTabId(ctx);
    const info = await callCS(tabId, 'canvas', 'inspect', id);
    const b = info.bounds;
    return captureTab(ctx, { crop: { x: b.x, y: b.y, w: b.w, h: b.h } });
  });

export const BROWSER_TOOLS = tools;
