/* Nova Agent Browser — CDP tools (chrome.debugger / "chế độ debug của Chrome").
 * Low-level, trusted control of a tab through the DevTools protocol:
 * JS evaluation, trusted input events, background screenshots, network log.
 * Group 'cdp' — policy default is ASK, master switch settings.debuggerEnabled. */

import { registerTool } from './tool-registry.js';
import * as cdp from './cdp.js';
import { targetTabId, getTab, shotPipeline, callCS } from './tools-browser.js';
import { getSettings } from './storage.js';

const tools = [];
function T(name, description, schema, opts, execute) {
  registerTool({ name, description, schema, ...opts, execute });
  tools.push(name);
}

/* remember which runtime attached which tab → auto-detach when the task ends */
function markAttached(ctx, tabId) {
  (ctx.runtime?.debugTabs || ctx.debugTabs)?.add?.(tabId);
}

/* targetTabId + attach có tracking — cdp.cmd() tự auto-attach nhưng runtime
 * sẽ không biết để dọn khi task kết thúc (tab kẹt banner "đang debug") */
async function cdpTab(ctx) {
  const tabId = await targetTabId(ctx);
  if (!cdp.isAttached(tabId)) {
    await cdp.attach(tabId);
    markAttached(ctx, tabId);
  }
  return tabId;
}

T('browser_debug_attach', 'Attach the Chrome debugger (CDP) to the target tab — enables low-level control: JS evaluation, trusted input events, background screenshots, network log. Chrome shows a "debugging" banner while attached (normal). Requires Settings → Browser → "Chế độ debug (CDP)".',
  { type: 'object', properties: {} },
  { group: 'cdp', risk: 'medium', timeout: 20000 }, async (_, ctx) => {
    const tabId = await targetTabId(ctx);
    const tab = await getTab(tabId);
    const r = await cdp.attach(tabId);
    markAttached(ctx, tabId);
    return {
      ...r, url: tab.url, title: tab.title,
      note: 'Debugger attached. Chrome shows a banner while debugging — that is expected. Use browser_debug_detach when done.',
    };
  });

T('browser_debug_detach', 'Detach the Chrome debugger from the target tab (removes the debugging banner).',
  { type: 'object', properties: {} },
  { group: 'cdp', risk: 'low', timeout: 15000 }, async (_, ctx) => {
    const tabId = await targetTabId(ctx);
    ctx.runtime?.debugTabs?.delete?.(tabId);
    return cdp.detach(tabId);
  });

T('browser_debug_status', 'Debugger status: master switch, which tabs are attached, since when.',
  { type: 'object', properties: {} },
  { group: 'cdp', risk: 'low', timeout: 10000 }, async (_, ctx) => {
    let current = null;
    try { current = await targetTabId(ctx); } catch (e) { }
    return {
      enabled: (await getSettings()).debuggerEnabled,
      attachedTabIds: cdp.attachedIds(),
      currentTabAttached: current ? cdp.isAttached(current) : false,
    };
  });

T('browser_debug_evaluate', 'Evaluate a JavaScript expression IN the page context (full page JS power: read state, call functions, manipulate anything). Returns the JSON-serializable result. High risk — page-modifying; requires approval.',
  {
    type: 'object',
    properties: {
      expression: { type: 'string', description: 'JS expression or IIFE, e.g. "document.title" or "(() => { ... })()"' },
      awaitPromise: { type: 'boolean', description: 'await the result if it is a Promise (default true)' },
    },
    required: ['expression'],
  },
  { group: 'cdp', risk: 'high', timeout: 30000 }, async ({ expression, awaitPromise = true }, ctx) => {
    const tabId = await cdpTab(ctx);
    const res = await cdp.cmd(tabId, 'Runtime.evaluate', {
      expression: String(expression),
      returnByValue: true,
      awaitPromise: !!awaitPromise,
      userGesture: true,
    });
    if (res.exceptionDetails) {
      const ex = res.exceptionDetails;
      const desc = ex.exception?.description || ex.text || 'evaluation failed';
      throw Object.assign(new Error('JS exception: ' + String(desc).slice(0, 400)), { code: 'JS_EXCEPTION' });
    }
    const r = res.result || {};
    let out;
    try { out = r.value !== undefined ? JSON.stringify(r.value).slice(0, 8000) : String(r.description || r.type).slice(0, 2000); }
    catch (e) { out = String(r.description || '[unserializable result]').slice(0, 2000); }
    return { type: r.type, value: out, note: 'Executed with full page privileges — verify the effect if it modified the page.' };
  });

T('browser_debug_click', 'TRUSTED mouse click at viewport coordinates (x,y CSS px) via CDP Input domain — works where synthetic DOM clicks fail (anti-bot pages, canvas games, shadow-heavy UI). Move → press → release.',
  {
    type: 'object',
    properties: {
      x: { type: 'number' }, y: { type: 'number' },
      button: { type: 'string', enum: ['left', 'right', 'middle'] },
      clicks: { type: 'number', description: 'click count (2 = double click)' },
    },
    required: ['x', 'y'],
  },
  { group: 'cdp', risk: 'medium', timeout: 20000 }, async ({ x, y, button = 'left', clicks = 1 }, ctx) => {
    const tabId = await cdpTab(ctx);
    await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    for (let i = 0; i < Math.min(3, clicks); i++) {
      await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button, clickCount: i + 1 });
      await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button, clickCount: i + 1 });
    }
    return { clicked: { x, y, button, clicks }, note: 'Trusted input event — verify with an observation (screenshot/DOM).' };
  });

T('browser_debug_drag', 'TRUSTED drag / slider-slide via CDP Input domain — the fallback when browser_drag/browser_slide had no effect (page blocks synthetic events: anti-bot sliders, canvas puzzles, games). Give the START point (x,y = center of the knob/piece, CSS px in viewport) and the destination via toX/toY or dx/dy. Path is humanized (fast→slow, slight jitter, exact settle). Verify with browser_screenshot afterwards. Requires "Chế độ debug (CDP)". NEVER for CAPTCHAs.',
  {
    type: 'object',
    properties: {
      x: { type: 'number', description: 'start X (CSS px, viewport) — center of the slider knob / puzzle piece' },
      y: { type: 'number', description: 'start Y (CSS px, viewport)' },
      toX: { type: 'number', description: 'destination X (CSS px)' },
      toY: { type: 'number', description: 'destination Y (CSS px)' },
      dx: { type: 'number', description: 'or relative distance X in px (positive = right)' },
      dy: { type: 'number', description: 'or relative distance Y in px (positive = down)' },
      steps: { type: 'number', description: 'movement resolution (default 28)' },
    },
    required: ['x', 'y'],
  },
  { group: 'cdp', risk: 'high', timeout: 30000 }, async ({ x, y, toX, toY, dx = 0, dy = 0, steps = 28 }, ctx) => {
    if (toX === undefined && toY === undefined && !dx && !dy) throw new Error('need a destination: toX/toY or dx/dy');
    const tabId = await cdpTab(ctx);
    const ex = Math.round(toX ?? (x + dx)), ey = Math.round(toY ?? (y + dy));
    await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
    const n = Math.max(10, Math.min(80, steps | 0));
    for (let i = 1; i <= n; i++) {
      const t = i / n, e = 1 - Math.pow(1 - t, 3), decay = 1 - t;
      const px = Math.round(x + (ex - x) * e + (Math.random() - 0.5) * 2.2 * decay);
      const py = Math.round(y + (ey - y) * e + (Math.random() - 0.5) * 3.4 * decay);
      await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: px, y: py, buttons: 1 });
      await new Promise(r => setTimeout(r, 8 + Math.random() * 18 + (t > 0.82 ? 18 : 0)));
    }
    await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: ex, y: ey, buttons: 1 });
    await new Promise(r => setTimeout(r, 60 + Math.random() * 60));
    await cdp.cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: ex, y: ey, button: 'left', buttons: 0, clickCount: 1 });
    return {
      dragged: { from: { x, y }, to: { x: ex, y: ey } },
      note: 'Trusted CDP drag dispatched. Verify the landing position with browser_screenshot; if the piece undershot, call again with a small dx/dy correction.',
    };
  });

T('browser_debug_type', 'TRUSTED text input via CDP — types into the currently focused element. mode "insert" (default, fast) uses Input.insertText; mode "keys" dispatches per-key events (for fields that need keydown handlers, e.g. autocomplete). Focus the field first (browser_click / browser_debug_click).',
  {
    type: 'object',
    properties: {
      text: { type: 'string' },
      mode: { type: 'string', enum: ['insert', 'keys'] },
    },
    required: ['text'],
  },
  { group: 'cdp', risk: 'medium', timeout: 30000 }, async ({ text, mode = 'insert' }, ctx) => {
    const tabId = await cdpTab(ctx);
    text = String(text);
    if (mode === 'insert') {
      await cdp.cmd(tabId, 'Input.insertText', { text });
    } else {
      for (const ch of text.slice(0, 2000)) {
        await cdp.cmd(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', key: ch, text: ch });
        await cdp.cmd(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: ch });
      }
    }
    return { typed: text.length, mode };
  });

T('browser_debug_key', 'TRUSTED special key press via CDP (Enter, Tab, Escape, Backspace, Delete, ArrowUp/Down/Left/Right, Home, End, PageUp, PageDown, Space).',
  { type: 'object', properties: { key: { type: 'string' } }, required: ['key'] },
  { group: 'cdp', risk: 'medium', timeout: 15000 }, async ({ key }, ctx) => {
    const tabId = await cdpTab(ctx);
    const def = cdp.KEY_DEFS[String(key).toLowerCase()];
    if (!def) throw new Error('unsupported key — use one of: ' + Object.keys(cdp.KEY_DEFS).join(', '));
    await cdp.cmd(tabId, 'Input.dispatchKeyEvent', {
      type: def.text ? 'keyDown' : 'rawKeyDown',
      key: def.key, code: def.code,
      windowsVirtualKeyCode: def.vk, nativeVirtualKeyCode: def.vk,
      text: def.text,
    });
    await cdp.cmd(tabId, 'Input.dispatchKeyEvent', {
      type: 'keyUp', key: def.key, code: def.code,
      windowsVirtualKeyCode: def.vk, nativeVirtualKeyCode: def.vk,
    });
    return { pressed: def.key };
  });

T('browser_debug_screenshot', 'Screenshot via CDP — works on BACKGROUND tabs (no need to activate the tab, unlike the normal screenshot). fullPage captures the entire scrollable page.',
  { type: 'object', properties: { fullPage: { type: 'boolean' } } },
  { group: 'cdp', risk: 'low', timeout: 45000 }, async ({ fullPage }, ctx) => {
    const tabId = await cdpTab(ctx);
    const tab = await getTab(tabId);
    const params = { format: 'jpeg', quality: 80 };
    if (fullPage) {
      const m = await cdp.cmd(tabId, 'Page.getLayoutMetrics');
      const cs = m.cssContentSize || m.contentSize;
      params.clip = { x: 0, y: 0, width: Math.min(cs.width, 4000), height: Math.min(cs.height, 16000), scale: 1 };
      params.captureBeyondViewport = true;
    }
    const shot = await cdp.cmd(tabId, 'Page.captureScreenshot', params);
    let viewport = null;
    try { viewport = (await callCS(tabId, 'dom', 'getPageInfo')).viewport; } catch (e) { }
    return {
      ...(await shotPipeline('data:image/jpeg;base64,' + shot.data, { tabId, url: tab.url, title: tab.title, viewport })),
      url: tab.url, title: tab.title, viewport,
      note: 'Captured via CDP (background-safe). Coordinates in CSS px of the viewport.',
    };
  });

T('browser_network_log', 'Recent network requests of the target tab (method, url, status, timing, failures) — captured while the debugger is attached. Use to debug broken buttons/APIs (browser_console_errors for JS errors).',
  { type: 'object', properties: { limit: { type: 'number' } } },
  { group: 'cdp', risk: 'low', timeout: 10000 }, async ({ limit = 25 }, ctx) => {
    const tabId = await targetTabId(ctx);
    if (!cdp.isAttached(tabId)) throw Object.assign(new Error('debugger not attached — call browser_debug_attach first'), { code: 'DEBUG_DETACHED' });
    const log = cdp.networkLog(tabId, Math.min(60, limit));
    return { tabId, requests: log, count: log.length };
  });

export const CDP_TOOLS = tools;
