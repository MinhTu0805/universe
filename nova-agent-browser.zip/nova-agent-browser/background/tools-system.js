/* Nova Agent Browser — system / terminal / files / research / memory tools. */

import { registerTool, listTools } from './tool-registry.js';
import { putArtifact, getArtifact, findArtifactByName } from './artifacts.js';
import { getSettings, addMemory, searchMemory, deleteMemory, listMemory } from './storage.js';
import * as nativeHost from './native-host.js';
import { redact } from './util.js';

const tools = [];
function T(name, description, schema, opts, execute) {
  registerTool({ name, description, schema, ...opts, execute });
  tools.push(name);
}

/* ==================== terminal ==================== */

T('terminal_execute', 'Run a real shell command on the user\'s machine via the local Nova bridge (native messaging). Returns exitCode/stdout/stderr. Use for file processing, Python/Node scripts, data transforms, git, zip, JSON/CSV processing.',
  {
    type: 'object',
    properties: {
      command: { type: 'string' },
      cwd: { type: 'string', description: 'working directory; defaults to the configured workspace' },
      timeoutSec: { type: 'number', description: 'default from settings' },
    },
    required: ['command'],
  },
  { group: 'terminal', risk: 'medium', timeout: 180000 },
  async ({ command, cwd, timeoutSec }, ctx) => {
    const settings = await getSettings();
    if (!settings.terminalEnabled) throw Object.assign(new Error('Terminal is disabled in Settings → Terminal'), { code: 'TERMINAL_DISABLED' });
    const status = await nativeHost.hostStatus();
    if (!status.installed) throw Object.assign(new Error('Terminal bridge is not installed. Tell the user to run the native host installer (see Settings → Terminal).'), { code: 'NO_HOST' });

    let stdout = '', stderr = '';
    const fid = ctx.feedItemId;
    try {
      const res = await nativeHost.exec({
        command, cwd: cwd || settings.workspace, timeoutSec: timeoutSec || settings.terminalTimeout || 60,
        cancelToken: ctx.cancelToken,
        onEvent: (msg) => {
          if (msg.type === 'stdout') { stdout += msg.data; ctx.feedUpdate?.(fid, { output: redact((stdout + stderr).slice(-4000)) }); }
          if (msg.type === 'stderr') { stderr += msg.data; ctx.feedUpdate?.(fid, { output: redact((stdout + stderr).slice(-4000)) }); }
        },
      });
      const output = redact((stdout + (stderr ? '\n[stderr]\n' + stderr : ''))).slice(-6000);
      ctx.feedUpdate?.(fid, { status: res.code === 0 ? 'success' : 'error', output, exitCode: res.code, duration: res.durationMs });
      if (res.code !== 0) throw Object.assign(new Error(`exit code ${res.code}: ${output.slice(-600)}`), { code: 'EXIT_' + res.code });
      return { exitCode: res.code, stdout: redact(stdout).slice(-5000), stderr: redact(stderr).slice(-2000), durationMs: res.durationMs, cwd: cwd || settings.workspace };
    } catch (e) {
      if (e.code === 'NO_HOST' || e.code === 'TERMINAL_DISABLED') throw e;
      ctx.feedUpdate?.(fid, { status: 'error', output: redact(String(e.message || e)) });
      throw e;
    }
  });

T('terminal_status', 'Check whether the local terminal bridge (native host) is installed and reachable.',
  { type: 'object', properties: {} },
  { group: 'terminal', risk: 'low' }, async () => nativeHost.hostStatus());

/* ==================== artifacts / files ==================== */

T('artifact_create', 'Create a file artifact (md/txt/json/csv/html/svg/code) that the user can preview and download. For binary or large processing, use terminal_execute instead.',
  {
    type: 'object',
    properties: {
      name: { type: 'string', description: 'file name with extension, e.g. results.csv' },
      content: { type: 'string', description: 'full file content (text)' },
      mime: { type: 'string' },
    },
    required: ['name', 'content'],
  },
  { group: 'files', risk: 'low' }, async ({ name, content, mime }, ctx) => {
    if (!/^[ \wÀ-ỹ.\-()[\]]+\.[a-z0-9]{1,6}$/i.test(name)) throw new Error('invalid file name');
    const art = putArtifact({ convId: ctx.convId, name, text: String(content), mime: mime || guessMime(name) });
    ctx.onArtifact?.(art);
    return { artifactId: art.id, name: art.name, size: art.size, note: 'artifact is attached in the chat UI with Preview/Download' };
  });

T('artifact_read', 'Read back the content of a previously created artifact.',
  { type: 'object', properties: { artifactId: { type: 'string' } }, required: ['artifactId'] },
  { group: 'files', risk: 'low' }, async ({ artifactId }) => {
    const art = getArtifact(artifactId);
    if (!art) throw new Error('artifact not found');
    return { name: art.name, mime: art.mime, size: art.size, content: (art.text || '').slice(0, 20000) };
  });

T('artifact_append', 'Append content to an existing text artifact (by artifactId or name). Useful for building reports/CSVs incrementally.',
  {
    type: 'object',
    properties: {
      artifactId: { type: 'string' }, name: { type: 'string' },
      content: { type: 'string', description: 'text to append' },
    },
    required: ['content'],
  },
  { group: 'files', risk: 'low' }, async ({ artifactId, name, content }) => {
    let art = artifactId ? getArtifact(artifactId) : null;
    if (!art && name) art = findArtifactByName(name);
    if (!art) throw new Error('artifact not found — create it first with artifact_create');
    art.text = (art.text || '') + String(content);
    art.size = art.text.length;
    return { artifactId: art.id, name: art.name, size: art.size };
  });

function guessMime(name) {
  const ext = name.split('.').pop().toLowerCase();
  return { md: 'text/markdown', txt: 'text/plain', json: 'application/json', csv: 'text/csv', html: 'text/html', svg: 'image/svg+xml', js: 'text/javascript', ts: 'text/typescript', py: 'text/x-python', css: 'text/css', xml: 'application/xml', yaml: 'text/yaml', yml: 'text/yaml' }[ext] || 'text/plain';
}

/* ==================== research ==================== */

T('web_search', 'Search the web (DuckDuckGo HTML endpoint — no API key needed). Returns titles, urls, snippets.',
  { type: 'object', properties: { query: { type: 'string' }, max: { type: 'number' } }, required: ['query'] },
  { group: 'research', risk: 'low', timeout: 30000 }, async ({ query, max = 8 }) => {
    const url = 'https://html.duckduckgo.com/html/?q=' + encodeURIComponent(query);
    const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36' } });
    if (!res.ok) throw new Error('search failed: HTTP ' + res.status);
    const html = await res.text();
    const results = [];
    const re = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>)?/g;
    let m;
    const clean = s => s ? s.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim() : '';
    while ((m = re.exec(html)) && results.length < max) {
      let href = m[1];
      const uddg = /[?&]uddg=([^&]+)/.exec(href);
      if (uddg) href = decodeURIComponent(uddg);
      results.push({ title: clean(m[2]), url: href, snippet: clean(m[3] || '') });
    }
    if (!results.length) throw new Error('no results parsed — the search page format may have changed; use browser_navigate to a search engine instead');
    return { query, results };
  });

T('fetch_url', 'Fetch a URL and return readable text (tags stripped, truncated). For reading public pages without opening a tab.',
  { type: 'object', properties: { url: { type: 'string' }, maxChars: { type: 'number' } }, required: ['url'] },
  { group: 'research', risk: 'low', timeout: 40000 }, async ({ url, maxChars = 8000 }) => {
    const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36' }, redirect: 'follow' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const html = await res.text();
    const text = html
      .replace(/<(script|style|noscript|svg|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li|h[1-6]|tr)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
      .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n')
      .trim();
    return { url: res.url, chars: text.length, truncated: text.length > maxChars, text: text.slice(0, maxChars) };
  });

/* ==================== long-term memory ==================== */

T('memory_save', 'Save a durable fact to long-term memory (user preferences, account details, project context, recurring instructions). Survives across conversations. Do NOT store passwords or secrets.',
  {
    type: 'object',
    properties: {
      text: { type: 'string', description: 'the fact to remember, one clear sentence' },
      tags: { type: 'array', description: 'optional short tags, e.g. ["user","preference"]' },
    },
    required: ['text'],
  },
  { group: 'memory', risk: 'low' }, async ({ text, tags }) => {
    const entry = await addMemory({ text, tags });
    return { saved: true, id: entry.id, text: entry.text };
  });

T('memory_recall', 'Search long-term memory for facts relevant to a query (or list recent memories when query is omitted).',
  { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } } },
  { group: 'memory', risk: 'low' }, async ({ query, limit = 8 }) => {
    const hits = await searchMemory(query, limit);
    return { query: query || null, hits, total: (await listMemory()).length };
  });

T('memory_forget', 'Delete memories by id or by matching query. Requires user approval.',
  { type: 'object', properties: { id: { type: 'string' }, query: { type: 'string' } } },
  { group: 'memory', risk: 'high' }, async ({ id, query }) => {
    if (!id && !query) throw new Error('provide id or query');
    const r = await deleteMemory({ id, query });
    if (!r.removed) throw new Error('no matching memory found');
    return r;
  });

/* ==================== planning ==================== */

T('plan_update', 'Create or update the visible task plan (checklist shown to the user). steps = full ordered list, each {content, status: pending|in_progress|done}. Use at the start of multi-step tasks and update as you progress.',
  {
    type: 'object',
    properties: {
      steps: {
        type: 'array',
        description: '[{content: string, status: "pending"|"in_progress"|"done"}]',
      },
    },
    // intentionally NOT required: some models (notably Gemini flash-lite)
    // emit `plan_update {}`; a hard BAD_ARGS there just burns a step. An empty
    // call is a no-op that returns usage guidance the model can act on.
  },
  { group: 'system', risk: 'low' }, async ({ steps }, ctx) => {
    if (!Array.isArray(steps) || !steps.length) {
      return { planned: 0, note: 'no steps provided — plan unchanged. To create/update the plan, call plan_update with steps: [{content, status: "pending"|"in_progress"|"done"}].' };
    }
    const clean = steps.slice(0, 20).map(s => ({
      content: String(s?.content || '').slice(0, 140),
      status: ['done', 'in_progress', 'pending'].includes(s?.status) ? s.status : 'pending',
    }));
    const done = clean.filter(s => s.status === 'done').length;
    // one plan item per conversation, upserted in place
    if (ctx.feedUpsertPlan) await ctx.feedUpsertPlan({ id: 'plan-' + ctx.convId, t: 'plan', steps: clean, done, total: clean.length });
    return { planned: clean.length, done, note: 'plan is visible to the user; keep it updated as steps complete' };
  });

/* ==================== misc ==================== */

T('get_datetime', 'Get the current date, time, timezone and weekday. Always use this instead of guessing "today".',
  { type: 'object', properties: {} },
  { group: 'system', risk: 'low' }, async () => {
    const now = new Date();
    return {
      iso: now.toISOString(),
      local: now.toLocaleString('vi-VN', { hour12: false }),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      weekday: now.toLocaleDateString('vi-VN', { weekday: 'long' }),
      unixMs: now.getTime(),
    };
  });

/* ==================== agent control ==================== */

T('task_complete', 'Mark the task complete. Call ONLY when the goal is verifiably done. Include what was done + evidence.',
  {
    type: 'object',
    properties: {
      summary: { type: 'string', description: 'concise final summary for the user (Vietnamese unless user language differs)' },
      verifiedBy: { type: 'string', description: 'how completion was verified (observation/screenshot/URL/file)' },
    },
    required: ['summary'],
  },
  { group: 'system', risk: 'low' }, async ({ summary, verifiedBy }, ctx) => {
    ctx.complete?.(summary, verifiedBy);
    return { completed: true };
  });

T('ask_user', 'Pause and ask the user a question (missing info, decision, human verification like CAPTCHA). The task resumes with their answer.',
  { type: 'object', properties: { question: { type: 'string' }, options: { type: 'array', description: 'optional quick-reply options' } }, required: ['question'] },
  { group: 'system', risk: 'low' }, async ({ question, options }, ctx) => {
    if (!ctx.askUser) throw new Error('ask_user unavailable in this context');
    const answer = await ctx.askUser(question, options);
    return { answer };
  });

T('search_tools', 'Discover available tools by keyword (the registry is large; search instead of guessing).',
  { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
  { group: 'system', risk: 'low' }, async ({ query }) => {
    const q = String(query).toLowerCase();
    const hits = listTools()
      .filter(t => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q) || t.group.includes(q))
      .slice(0, 12)
      .map(t => ({ name: t.name, group: t.group, risk: t.risk, description: t.description.slice(0, 140) }));
    return { query, hits, total: listTools().length };
  });

export const SYSTEM_TOOLS = tools;
