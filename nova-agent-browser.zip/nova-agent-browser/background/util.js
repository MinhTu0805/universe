/* Nova Agent Browser — shared tiny utils (background). */

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

export const fmtN = n => n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1000 ? (n / 1000).toFixed(n >= 1e4 ? 0 : 1) + 'k' : String(n || 0);

/** Redact secrets from any string before it reaches logs / the model. */
const SECRET_PATTERNS = [
  /\b(sk|pk|api|key|token|secret|password|passwd|authorization|bearer)[-_ ]?[:=]\s*["']?[\w\-./+=]{8,}/gi,
  /\bsk-[A-Za-z0-9_\-]{16,}\b/g,
  /\bAIza[A-Za-z0-9_\-]{20,}\b/g,
  /\bghp_[A-Za-z0-9]{20,}\b/g,
  /\bxox[baprs]-[A-Za-z0-9\-]{10,}\b/g,
  /\btvly-[A-Za-z0-9_\-]{16,}\b/g,
  /\b-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
];
export function redact(str) {
  if (typeof str !== 'string') return str;
  let out = str;
  for (const re of SECRET_PATTERNS) out = out.replace(re, m => m.slice(0, Math.min(8, m.length)) + '…[REDACTED]');
  return out;
}
export function redactDeep(value) {
  if (typeof value === 'string') return redact(value);
  if (Array.isArray(value)) return value.map(redactDeep);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = /key|token|secret|password|cookie|authorization/i.test(k) ? '[REDACTED]' : redactDeep(v);
    }
    return out;
  }
  return value;
}

export const log = {
  debug: (...a) => { if (globalThis.__NOVA_DEBUG) console.debug('[nova]', ...a); },
  info: (...a) => console.info('[nova]', ...a),
  warn: (...a) => console.warn('[nova]', ...a),
  error: (...a) => console.error('[nova]', ...a.map(x => typeof x === 'string' ? redact(x) : x)),
};

export function errInfo(e) {
  return {
    code: e?.code || 'ERROR',
    message: String(e?.message || e || 'unknown error'),
    retryable: !!(e && e.retryable),
  };
}
