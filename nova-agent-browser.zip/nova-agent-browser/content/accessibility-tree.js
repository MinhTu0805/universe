/* Nova Agent Browser — simplified accessibility tree.
 * Exposes NC.a11y. Semantic perception layer: role + name + state per node. */
'use strict';

NC.a11y = (() => {
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'META', 'LINK', 'HEAD', 'BR', 'HR']);
  const LANDMARK = new Set(['navigation', 'main', 'banner', 'contentinfo', 'complementary', 'form', 'dialog', 'search', 'region']);
  const INTERACTIVE = new Set(['link', 'button', 'textbox', 'searchbox', 'combobox', 'checkbox', 'radio', 'switch', 'slider', 'tab', 'menuitem', 'option', 'spinbutton', 'treeitem']);
  const CONTENT = new Set(['heading', 'img', 'canvas', 'video', 'audio', 'table', 'list', 'listitem', 'graphics-document', 'code', 'blockquote']);

  function stateOf(el) {
    const s = [];
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') s.push('disabled');
    const exp = el.getAttribute('aria-expanded');
    if (exp !== null) s.push(exp === 'true' ? 'expanded' : 'collapsed');
    const chk = el.getAttribute('aria-checked');
    if (chk !== null) s.push(chk === 'true' ? 'checked' : 'unchecked');
    if (el.tagName === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio')) s.push(el.checked ? 'checked' : 'unchecked');
    const pressed = el.getAttribute('aria-pressed');
    if (pressed !== null) s.push(pressed === 'true' ? 'pressed' : 'not pressed');
    if (el.getAttribute('aria-current')) s.push('current');
    if (el.required || el.getAttribute('aria-required') === 'true') s.push('required');
    if (NC.dom.isSensitive(el)) s.push('SENSITIVE');
    return s;
  }

  function valueOf(el, role) {
    if (role === 'textbox' || role === 'searchbox' || role === 'combobox') {
      const v = NC.dom.isSensitive(el) ? '[REDACTED]' : String(el.value ?? el.getAttribute('aria-valuetext') ?? '').slice(0, 100);
      return v || undefined;
    }
    if (role === 'slider' || role === 'spinbutton') return String(el.getAttribute('aria-valuenow') ?? el.value ?? '') || undefined;
    return undefined;
  }

  /**
   * Build simplified accessibility tree.
   * Returns { text: indentedLines, nodes, total }
   * Line format:  <indent>role "name" [state] value=… [ref]
   */
  function getTree({ maxNodes = 350, viewportOnly = false } = {}) {
    const nodes = [];
    const lines = [];

    function visit(el, depth) {
      if (nodes.length >= maxNodes) return;
      if (el.nodeType !== 1 || SKIP_TAGS.has(el.tagName)) return;
      if (el.getAttribute('aria-hidden') === 'true') return;
      if (!NC.dom.isVisible(el)) return;
      if (el.id === 'nova-agent-overlay-root') return;

      const role = NC.dom.roleOf(el);
      const keep = LANDMARK.has(role) || INTERACTIVE.has(role) || CONTENT.has(role);
      let myDepth = depth;

      if (keep && (!viewportOnly || NC.dom.inViewport(el, 100))) {
        const name = NC.dom.nameOf(el);
        const st = stateOf(el);
        const val = valueOf(el, role);
        const ref = NC.dom.refOf(el);
        const node = { ref, role, name: name || undefined, state: st.length ? st : undefined, value: val, depth: myDepth, bounds: NC.dom.rectOf(el) };
        nodes.push(node);

        let line = '  '.repeat(Math.min(myDepth, 12)) + role;
        if (el.tagName.match(/^H[1-6]$/)) line += ` level=${el.tagName[1]}`;
        if (name) line += ` "${name}"`;
        if (val) line += ` value="${val}"`;
        if (st.length) line += ` [${st.join(', ')}]`;
        line += ` [${ref}]`;
        lines.push(line);
        myDepth++;
      }

      // recurse (open shadow roots included)
      const kids = el.shadowRoot ? el.shadowRoot.children : el.children;
      for (const kid of kids) visit(kid, myDepth);
    }

    visit(document.body || document.documentElement, 0);
    return { text: lines.join('\n'), nodes, total: nodes.length, truncated: nodes.length >= maxNodes };
  }

  return { getTree };
})();
