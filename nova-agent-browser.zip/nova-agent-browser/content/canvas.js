/* Nova Agent Browser — canvas computer-use.
 * Canvases have no DOM children, so the agent works in canvas coordinates:
 * inspect → bounds → mouse events → verification screenshot (upstream). */
'use strict';

NC.canvas = (() => {
  const ID_ATTR = 'data-nova-canvas';

  function canvases() {
    return [...document.querySelectorAll('canvas')];
  }

  function idOf(c) {
    let id = c.getAttribute(ID_ATTR);
    if (!id) { id = 'c' + Math.random().toString(36).slice(2, 8); c.setAttribute(ID_ATTR, id); }
    return id;
  }

  function resolve(id) {
    let c = id ? document.querySelector(`canvas[${ID_ATTR}="${CSS.escape(id)}"]`) : canvases().find(NC.dom.isVisible);
    if (!c) throw new Error(id ? `canvas not found: ${id}` : 'no visible canvas on page');
    return c;
  }

  function list() {
    return canvases().map((c, i) => {
      const r = c.getBoundingClientRect();
      return {
        id: idOf(c),
        index: i,
        bounds: NC.dom.rectOf(c),
        cssSize: { w: Math.round(r.width), h: Math.round(r.height) },
        pixelSize: { w: c.width, h: c.height },
        scale: r.width ? +(c.width / r.width).toFixed(3) : 1,
        visible: NC.dom.isVisible(c),
      };
    });
  }

  function inspect(id) {
    const c = resolve(id);
    const r = c.getBoundingClientRect();
    let ctxType = 'unknown';
    try {
      if (c.getContext('webgl2')) ctxType = 'webgl2';
      else if (c.getContext('webgl')) ctxType = 'webgl';
      else if (c.getContext('2d')) ctxType = '2d';
    } catch (e) { }
    return {
      id: idOf(c),
      bounds: NC.dom.rectOf(c),
      cssSize: { w: Math.round(r.width), h: Math.round(r.height) },
      pixelSize: { w: c.width, h: c.height },
      scale: r.width ? +(c.width / r.width).toFixed(3) : 1,
      contextType: ctxType,
      dpr: devicePixelRatio || 1,
      note: 'Coordinates for canvas_* tools are CSS pixels relative to the canvas top-left corner.',
    };
  }

  /* canvas point (css-px relative) → client point */
  function toClient(c, x, y) {
    const r = c.getBoundingClientRect();
    return { x: Math.round(r.left + x), y: Math.round(r.top + y) };
  }

  async function withPoint(id, x, y, fn) {
    const c = resolve(id);
    await NC.act.ensureVisible(c);
    const p = toClient(c, x, y);
    return { result: await fn(c, p), at: p };
  }

  const click = (id, x, y) => withPoint(id, x, y, (c, p) => NC.act.click({ ref: NC.dom.refOf(c), offsetX: x, offsetY: y }));
  const dblclick = (id, x, y) => withPoint(id, x, y, (c) => NC.act.click({ ref: NC.dom.refOf(c), offsetX: x, offsetY: y }, { dblclick: true }));
  const move = (id, x, y) => withPoint(id, x, y, (c, p) => {
    const common = { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, buttons: 0 };
    c.dispatchEvent(new PointerEvent('pointermove', common));
    c.dispatchEvent(new MouseEvent('mousemove', common));
    NC.overlay?.cursorTo?.(p.x, p.y);
    return { moved: true };
  });
  const down = (id, x, y, button = 0) => withPoint(id, x, y, (c, p) => {
    const common = { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, button, buttons: button === 2 ? 2 : 1 };
    c.dispatchEvent(new PointerEvent('pointerdown', common));
    c.dispatchEvent(new MouseEvent('mousedown', common));
    return { down: true };
  });
  const up = (id, x, y, button = 0) => withPoint(id, x, y, (c, p) => {
    const common = { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, button, buttons: 0 };
    c.dispatchEvent(new PointerEvent('pointerup', common));
    c.dispatchEvent(new MouseEvent('mouseup', common));
    return { up: true };
  });

  async function drag(id, x1, y1, x2, y2, { steps = 14 } = {}) {
    const c = resolve(id);
    await NC.act.ensureVisible(c);
    const p1 = toClient(c, x1, y1), p2 = toClient(c, x2, y2);
    return NC.act.drag({ x: p1.x, y: p1.y }, { x: p2.x, y: p2.y }, { steps });
  }

  /** Draw a polyline path: [{x,y}, ...] in canvas css-px coordinates. */
  async function draw(id, points = [], { close = false } = {}) {
    if (!Array.isArray(points) || points.length < 2) throw new Error('draw needs >= 2 points');
    const c = resolve(id);
    await NC.act.ensureVisible(c);
    const first = toClient(c, points[0].x, points[0].y);
    await NC.act.drag({ x: first.x, y: first.y }, { x: first.x, y: first.y }, { steps: 1 }); // press in place
    // explicit down → moves → up on the canvas element itself
    const mk = (p, type, buttons) => c.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, buttons }));
    const mkP = (p, type, buttons) => c.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, buttons }));
    let p = toClient(c, points[0].x, points[0].y);
    mkP(p, 'pointerdown', 1); mk(p, 'mousedown', 1);
    const all = close ? [...points, points[0]] : points;
    for (let i = 1; i < all.length; i++) {
      const a = all[i - 1], b = all[i];
      const segSteps = Math.max(2, Math.round(Math.hypot(b.x - a.x, b.y - a.y) / 8));
      for (let s = 1; s <= segSteps; s++) {
        p = toClient(c, a.x + (b.x - a.x) * s / segSteps, a.y + (b.y - a.y) * s / segSteps);
        mkP(p, 'pointermove', 1); mk(p, 'mousemove', 1);
        await new Promise(r => setTimeout(r, 8));
      }
    }
    mkP(p, 'pointerup', 0); mk(p, 'mouseup', 0);
    return { drawn: true, points: all.length };
  }

  /** Rectangular region selection (drag box). */
  const selectRegion = (id, x, y, w, h) => drag(id, x, y, x + w, y + h, { steps: 10 });

  async function scroll(id, x, y, deltaY) {
    const c = resolve(id);
    const p = toClient(c, x, y);
    c.dispatchEvent(new WheelEvent('wheel', { bubbles: true, cancelable: true, composed: true, view: window, clientX: p.x, clientY: p.y, deltaY, deltaMode: 0 }));
    return { scrolled: true };
  }

  const keypress = (id, key) => NC.act.pressKey(key, { selector: `canvas[${ID_ATTR}="${CSS.escape(resolve(id).getAttribute(ID_ATTR))}"]` });

  return { list, inspect, click, dblclick, move, down, up, drag, draw, selectRegion, scroll, keypress, resolve };
})();
