/* Nova Agent Browser — content script entry / message router.
 * Must be concatenated LAST by scripts/build.js. */
'use strict';

(() => {
  if (self.__novaContentLoaded) return;
  self.__novaContentLoaded = true;

  let agentActive = false;
  let lastInterferenceSent = 0;

  function sendToBackground(msg) {
    try { chrome.runtime.sendMessage(msg, () => void chrome.runtime.lastError); } catch (e) { }
  }

  /* ---- human interference detection (while agent controls this tab) ---- */
  function onHumanInput() {
    if (!agentActive) return;
    const now = Date.now();
    if (now - lastInterferenceSent < 1500) return;
    lastInterferenceSent = now;
    sendToBackground({ type: 'nova-human-interference', url: location.href });
  }
  addEventListener('mousedown', onHumanInput, { capture: true, passive: true });
  addEventListener('keydown', onHumanInput, { capture: true, passive: true });

  /* ---- message router ---- */
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg !== 'object') return;

    if (msg.cmd === 'ping') {
      sendResponse({ ok: true, url: location.href, title: document.title, top: self === top });
      return;
    }

    if (msg.cmd === 'set-agent-state') {
      agentActive = !!msg.active;
      if (msg.overlay !== undefined) {
        try { NC.overlay.setState(msg.overlay); } catch (e) { }
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg.cmd === 'overlay') { // direct overlay control
      try {
        if (msg.action === 'state') NC.overlay.setState(msg.value, msg.opts || {});
        else if (msg.action === 'highlight' && msg.ref) { const el = NC.dom.byRef(msg.ref); if (el) NC.overlay.highlight(el, msg.opts || {}); }
        else if (msg.action === 'clear') NC.overlay.clear();
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, error: String(e.message || e) }); }
      return;
    }

    if (msg.cmd === 'call') {
      const mod = NC[msg.module];
      const fn = mod && mod[msg.fn];
      if (typeof fn !== 'function') {
        sendResponse({ ok: false, error: `unknown content fn: ${msg.module}.${msg.fn}` });
        return;
      }
      Promise.resolve()
        .then(() => fn.apply(mod, msg.args || []))
        .then(data => sendResponse({ ok: true, data }))
        .catch(err => sendResponse({ ok: false, error: String(err && err.message || err), code: err && err.code }));
      return true; // async
    }
  });

  /* ---- boot ---- */
  NC.sel.init();
  if (self === top) sendToBackground({ type: 'nova-content-ready', url: location.href, title: document.title });
})();
