/* Nova Agent Browser — page diagnostics: console errors + performance.
 * Exposes NC.diag. Classic script (bundled). Shares the NC namespace.
 * Captures console.error/warn, uncaught exceptions and failed resources so the
 * agent can self-diagnose broken pages (debugging tasks, failed submissions). */
'use strict';

NC.diag = (() => {
  const MAX = 80;
  const errors = [];   // ring buffer {level, source, text, url?, line?, ts}
  let installed = false;

  function push(entry) {
    errors.push({ ts: Date.now(), ...entry });
    if (errors.length > MAX) errors.shift();
  }

  function fmtArgs(args) {
    return [...args].map(a => {
      if (a instanceof Error) return a.message;
      if (typeof a === 'object') { try { return JSON.stringify(a).slice(0, 200); } catch (e) { return '[object]'; } }
      return String(a);
    }).join(' ').slice(0, 500);
  }

  function install() {
    if (installed) return;
    installed = true;

    for (const level of ['error', 'warn']) {
      const orig = console[level].bind(console);
      console[level] = (...args) => {
        try { push({ level, source: 'console', text: fmtArgs(args) }); } catch (e) { }
        orig(...args);
      };
    }

    addEventListener('error', (e) => {
      if (e.target && e.target !== window) {
        // resource load failure (img/script/link)
        const t = e.target;
        push({ level: 'error', source: 'resource', text: `failed to load <${t.tagName?.toLowerCase()}> ${t.src || t.href || ''}`.slice(0, 400) });
      } else {
        push({ level: 'error', source: 'exception', text: String(e.message || 'uncaught error'), url: e.filename, line: e.lineno });
      }
    }, true);

    addEventListener('unhandledrejection', (e) => {
      push({ level: 'error', source: 'promise', text: 'unhandled rejection: ' + String(e.reason?.message || e.reason).slice(0, 300) });
    });
  }

  function getErrors({ level, limit = 30, since } = {}) {
    install();
    let list = errors;
    if (level) list = list.filter(e => e.level === level);
    if (since) list = list.filter(e => e.ts >= since);
    return {
      errors: list.slice(-limit).map(e => ({ ...e, ago: Math.round((Date.now() - e.ts) / 1000) + 's' })),
      total: errors.length,
      note: errors.length ? undefined : 'no console errors captured on this page',
    };
  }

  function getPerf() {
    install();
    const nav = performance.getEntriesByType('navigation')[0] || {};
    const paints = {};
    for (const p of performance.getEntriesByType('paint')) paints[p.name] = Math.round(p.startTime);
    const res = performance.getEntriesByType('resource');
    const slow = res.filter(r => r.duration > 1500)
      .sort((a, b) => b.duration - a.duration).slice(0, 8)
      .map(r => ({ name: r.name.split('?')[0].slice(-90), type: r.initiatorType, ms: Math.round(r.duration) }));
    return {
      url: location.href,
      timingMs: {
        domContentLoaded: Math.round(nav.domContentLoadedEventEnd || 0),
        load: Math.round(nav.loadEventEnd || 0),
        firstPaint: paints['first-paint'],
        firstContentfulPaint: paints['first-contentful-paint'],
      },
      resources: { total: res.length, slow },
      memory: performance.memory ? { usedMB: Math.round(performance.memory.usedJSHeapSize / 1048576), limitMB: Math.round(performance.memory.jsHeapSizeLimit / 1048576) } : undefined,
    };
  }

  install();
  return { getErrors, getPerf };
})();
