/* Nova Agent Browser — DOM inspector.
 * Exposes NC.dom. Classic script (bundled). Shares the NC namespace. */
'use strict';

NC.dom = (() => {
  const REF_ATTR = 'data-nova-ref';
  let refSeq = 0;
  let refMap = new Map(); // ref -> element (weak-ish: rebuilt every scan)

  const SENSITIVE_TYPES = new Set(['password']);
  const SENSITIVE_HINT = /(password|passwd|otp|2fa|totp|cvv|cvc|card[-_ ]?number|secret|token)/i;

  /* ---------- visibility ---------- */
  function isVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || st.visibility === 'collapse') return false;
    if (parseFloat(st.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 0.5 || r.height < 0.5) return false;
    return true;
  }
  function inViewport(el, margin = 0) {
    const r = el.getBoundingClientRect();
    return r.bottom >= -margin && r.right >= -margin &&
      r.top <= innerHeight + margin && r.left <= innerWidth + margin;
  }

  /* ---------- refs ---------- */
  function resetRefs() { refMap = new Map(); }
  function refOf(el) {
    let r = el.getAttribute(REF_ATTR);
    if (!r) { r = 'e' + (++refSeq); el.setAttribute(REF_ATTR, r); }
    refMap.set(r, el);
    return r;
  }
  function byRef(ref) {
    const el = refMap.get(ref) || document.querySelector(`[${REF_ATTR}="${CSS.escape(ref)}"]`);
    return (el && el.isConnected) ? el : null;
  }

  /* ---------- roles & names ---------- */
  const TAG_ROLE = {
    A: 'link', BUTTON: 'button', SELECT: 'combobox', TEXTAREA: 'textbox',
    SUMMARY: 'button', OPTION: 'option', H1: 'heading', H2: 'heading', H3: 'heading',
    H4: 'heading', H5: 'heading', H6: 'heading', IMG: 'img', NAV: 'navigation',
    MAIN: 'main', ASIDE: 'complementary', HEADER: 'banner', FOOTER: 'contentinfo',
    FORM: 'form', TABLE: 'table', UL: 'list', OL: 'list', LI: 'listitem',
    DIALOG: 'dialog', DETAILS: 'group', IFRAME: 'iframe', VIDEO: 'video', AUDIO: 'audio',
    CANVAS: 'canvas', SVG: 'graphics-document', METER: 'meter', PROGRESS: 'progressbar',
  };
  function roleOf(el) {
    const r = el.getAttribute('role');
    if (r) return r.split(' ')[0];
    if (el.tagName === 'INPUT') {
      const t = (el.type || 'text').toLowerCase();
      return ({ button: 'button', submit: 'button', reset: 'button', checkbox: 'checkbox', radio: 'radio', range: 'slider', search: 'searchbox' })[t] || 'textbox';
    }
    return TAG_ROLE[el.tagName] || 'generic';
  }
  function labelOf(el) {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) return l.innerText.trim();
    }
    const wrap = el.closest('label');
    if (wrap) return wrap.innerText.trim().slice(0, 120);
    return '';
  }
  function nameOf(el) {
    const labelledby = el.getAttribute('aria-labelledby');
    if (labelledby) {
      const t = labelledby.split(/\s+/).map(id => document.getElementById(id)?.innerText?.trim()).filter(Boolean).join(' ');
      if (t) return t.slice(0, 120);
    }
    let name = el.getAttribute('aria-label') || el.getAttribute('alt') || '';
    const tag = el.tagName;
    if (!name && (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT')) {
      name = labelOf(el) || el.getAttribute('placeholder') || el.getAttribute('name') || '';
      if (!name && el.getAttribute('value') && (el.type === 'submit' || el.type === 'button')) name = el.value;
    }
    if (!name && tag === 'IMG') name = el.getAttribute('title') || '';
    if (!name) name = el.innerText || el.value || el.getAttribute('title') || '';
    return String(name).trim().replace(/\s+/g, ' ').slice(0, 120);
  }

  function isSensitive(el) {
    if (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA') return false;
    if (SENSITIVE_TYPES.has((el.type || '').toLowerCase())) return true;
    return SENSITIVE_HINT.test([el.name, el.id, el.getAttribute('autocomplete'), el.getAttribute('aria-label'), el.placeholder].filter(Boolean).join(' '));
  }

  function rectOf(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height), cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2) };
  }

  function elInfo(el, { withText = true } = {}) {
    const role = roleOf(el);
    const info = {
      ref: refOf(el),
      tag: el.tagName.toLowerCase(),
      role,
      name: nameOf(el),
      bounds: rectOf(el),
      visible: isVisible(el),
      disabled: !!(el.disabled || el.getAttribute('aria-disabled') === 'true'),
    };
    if (el.tagName === 'A' && el.href) info.href = el.href;
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      info.type = (el.type || 'text').toLowerCase();
      info.placeholder = el.placeholder || undefined;
      info.sensitive = isSensitive(el);
      info.value = info.sensitive ? '[REDACTED]' : String(el.value || '').slice(0, 120);
      if (el.type === 'checkbox' || el.type === 'radio') info.checked = el.checked;
    }
    if (el.tagName === 'SELECT') {
      info.value = el.value;
      info.options = [...el.options].slice(0, 50).map(o => ({ value: o.value, label: o.text.trim(), selected: o.selected }));
    }
    if (withText && !info.name && (role === 'generic' || role === 'listitem')) {
      const t = (el.innerText || '').trim().replace(/\s+/g, ' ');
      if (t) info.text = t.slice(0, 80);
    }
    return info;
  }

  /* ---------- selectors for interactive elements ---------- */
  const INTERACTIVE_SEL = [
    'a[href]', 'button', 'input:not([type=hidden])', 'textarea', 'select',
    '[role="button"]', '[role="link"]', '[role="checkbox"]', '[role="radio"]',
    '[role="tab"]', '[role="menuitem"]', '[role="option"]', '[role="switch"]',
    '[role="combobox"]', '[role="textbox"]', '[role="slider"]', '[role="searchbox"]',
    'summary', '[onclick]', '[contenteditable="true"]', '[tabindex]:not([tabindex="-1"])',
    'video', 'audio', 'canvas', 'details', '[draggable="true"]',
  ].join(',');

  function scanInteractive({ viewportOnly = true, max = 250 } = {}) {
    resetRefs();
    const out = [];
    const seen = new Set();
    const walk = (root) => {
      for (const el of root.querySelectorAll(INTERACTIVE_SEL)) {
        if (out.length >= max) break;
        if (seen.has(el)) continue;
        seen.add(el);
        if (!isVisible(el)) continue;
        if (viewportOnly && !inViewport(el, 80)) continue;
        out.push(elInfo(el));
      }
      // shadow DOM
      for (const host of root.querySelectorAll('*')) {
        if (host.shadowRoot && out.length < max) walk(host.shadowRoot);
      }
    };
    walk(document);
    return out;
  }

  function getPageInfo() {
    const de = document.documentElement;
    let selText = '';
    try { selText = String(getSelection()?.toString() || '').slice(0, 500); } catch (e) { }
    return {
      url: location.href,
      title: document.title,
      domain: location.hostname,
      readyState: document.readyState,
      viewport: { w: innerWidth, h: innerHeight },
      scroll: { x: Math.round(scrollX), y: Math.round(scrollY), maxY: Math.round(Math.max(0, de.scrollHeight - innerHeight)), maxX: Math.round(Math.max(0, de.scrollWidth - innerWidth)) },
      dpr: devicePixelRatio || 1,
      hasFocus: document.hasFocus(),
      selectedText: selText || undefined,
      lang: de.lang || undefined,
      counts: {
        links: document.links.length,
        images: document.images.length,
        iframes: document.querySelectorAll('iframe').length,
        canvas: document.querySelectorAll('canvas').length,
        svg: document.querySelectorAll('svg').length,
        forms: document.forms.length,
      },
      frame: self === top ? undefined : { framed: true },
    };
  }

  function getVisibleText({ maxChars = 6000 } = {}) {
    const root = document.querySelector('main') || document.querySelector('article') || document.body;
    let text = (root?.innerText || '').replace(/\n{3,}/g, '\n\n').trim();
    let truncated = false;
    if (text.length > maxChars) { text = text.slice(0, maxChars); truncated = true; }
    return { text, truncated, chars: text.length };
  }

  function getDOMSummary({ viewportOnly = true, max = 220 } = {}) {
    const els = scanInteractive({ viewportOnly, max });
    const lines = els.map(e => {
      const bits = [`[${e.ref}]`, `<${e.tag}>`, `role=${e.role}`];
      if (e.name) bits.push(`"${e.name}"`);
      if (e.type) bits.push(`type=${e.type}`);
      if (e.placeholder) bits.push(`ph="${e.placeholder}"`);
      if (e.value !== undefined && e.value !== '') bits.push(`value="${e.value}"`);
      if (e.checked !== undefined) bits.push(e.checked ? 'checked' : 'unchecked');
      if (e.href) bits.push(`→ ${e.href.slice(0, 80)}`);
      if (e.sensitive) bits.push('SENSITIVE');
      if (e.disabled) bits.push('disabled');
      bits.push(`@(${e.bounds.cx},${e.bounds.cy})`);
      return bits.join(' ');
    });
    return { elements: els, text: lines.join('\n'), count: els.length, truncated: els.length >= max };
  }

  /* ---------- targeted queries ---------- */
  function norm(s) { return String(s || '').trim().toLowerCase().replace(/\s+/g, ' '); }

  function findElements(q = {}, { max = 20, viewportOnly = false } = {}) {
    if (q.ref) {
      const el = byRef(q.ref);
      return { matches: el ? [elInfo(el)] : [], total: el ? 1 : 0 };
    }
    if (q.selector) {
      let list = [];
      try { list = [...document.querySelectorAll(q.selector)]; } catch (e) { return { matches: [], total: 0, error: 'invalid selector: ' + e.message }; }
      const vis = list.filter(el => isVisible(el) && (!viewportOnly || inViewport(el, 80)));
      return { matches: vis.slice(0, max).map(el => elInfo(el)), total: vis.length };
    }
    const roleW = norm(q.role), nameW = norm(q.name), textW = norm(q.text), tagW = norm(q.tag);
    const all = scanInteractive({ viewportOnly, max: 400 });
    let matches = all.filter(e => {
      if (roleW && e.role !== roleW) return false;
      if (tagW && e.tag !== tagW) return false;
      if (nameW) { const n = norm(e.name); if (!(n === nameW || n.includes(nameW))) return false; }
      if (textW) { const n = norm(e.name || e.text); if (!(n === textW || n.includes(textW))) return false; }
      return true;
    });
    // exact name match first
    matches.sort((a, b) => (norm(b.name) === nameW ? 1 : 0) - (norm(a.name) === nameW ? 1 : 0));
    if (typeof q.index === 'number' && matches[q.index]) matches = [matches[q.index]];
    return { matches: matches.slice(0, max), total: matches.length };
  }

  function findText(text, { max = 20 } = {}) {
    const needle = norm(text);
    if (!needle) return { matches: [], total: 0 };
    const out = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!n.nodeValue || !norm(n.nodeValue).includes(needle)) return NodeFilter.FILTER_REJECT;
        const p = n.parentElement;
        if (!p || !isVisible(p)) return NodeFilter.FILTER_REJECT;
        if (['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(p.tagName)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let node;
    while ((node = walker.nextNode()) && out.length < max) {
      const p = node.parentElement;
      const i = norm(node.nodeValue).indexOf(needle);
      out.push({
        ref: refOf(p),
        tag: p.tagName.toLowerCase(),
        context: (node.nodeValue || '').trim().slice(Math.max(0, i - 60), i + needle.length + 60).replace(/\s+/g, ' '),
        bounds: rectOf(p),
      });
    }
    return { matches: out, total: out.length };
  }

  function getLinks({ max = 80, viewportOnly = false } = {}) {
    const out = [];
    for (const a of document.querySelectorAll('a[href]')) {
      if (out.length >= max) break;
      if (!isVisible(a)) continue;
      if (viewportOnly && !inViewport(a)) continue;
      const text = norm(a.innerText) || a.getAttribute('aria-label') || '';
      out.push({ text: text.slice(0, 100), href: a.href });
    }
    return { links: out, total: document.links.length };
  }

  function getImages({ max = 60 } = {}) {
    const out = [];
    for (const img of document.images) {
      if (out.length >= max) break;
      if (!isVisible(img)) continue;
      const r = img.getBoundingClientRect();
      if (r.width < 24 || r.height < 24) continue;
      out.push({ src: img.currentSrc || img.src, alt: (img.alt || '').slice(0, 140), w: Math.round(r.width), h: Math.round(r.height), natural: { w: img.naturalWidth, h: img.naturalHeight } });
    }
    return { images: out, total: document.images.length };
  }

  function getForms({ max = 10 } = {}) {
    return [...document.forms].slice(0, max).map(f => ({
      ref: refOf(f),
      name: f.name || f.id || undefined,
      action: f.action || undefined,
      method: (f.method || 'get').toUpperCase(),
      fields: [...f.elements].filter(e => e.name || e.id).slice(0, 60).map(e => {
        const i = elInfo(e);
        return { ref: i.ref, tag: i.tag, type: i.type, name: e.name || undefined, label: i.name, required: !!e.required, sensitive: i.sensitive, value: i.sensitive ? '[REDACTED]' : i.value };
      }),
    }));
  }

  function tableToJson(t) {
    const rows = [];
    for (const tr of t.querySelectorAll('tr')) {
      const cells = [...tr.querySelectorAll('th,td')].map(c => (c.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 200));
      if (cells.length) rows.push(cells);
    }
    const head = rows.find(r => r.length && t.querySelector('th'));
    return {
      ref: refOf(t),
      caption: t.caption?.innerText?.trim() || undefined,
      columns: head || (rows[0] ? rows[0].map((_, i) => `col_${i + 1}`) : []),
      rows: rows.slice(head ? 1 : 0, 500),
      rowCount: Math.max(0, rows.length - (head ? 1 : 0)),
    };
  }
  function getTables({ max = 10 } = {}) {
    const tables = [...document.querySelectorAll('table')].filter(isVisible).slice(0, max);
    return { tables: tables.map(t => tableToJson(t)), total: document.querySelectorAll('table').length };
  }
  function extractTable({ ref, selector, index = 0 } = {}) {
    let t = null;
    if (ref) { const el = byRef(ref); t = el?.tagName === 'TABLE' ? el : el?.querySelector?.('table'); }
    else if (selector) { try { t = document.querySelector(selector); } catch (e) { } }
    else t = [...document.querySelectorAll('table')].filter(isVisible)[index];
    if (!t) throw new Error('table not found');
    return tableToJson(t);
  }

  function getSelectionContext() {
    const sel = getSelection();
    const text = String(sel || '').trim();
    if (!text) return { text: '' };
    let surrounding = '', tag = '';
    try {
      const node = sel.anchorNode?.parentElement;
      if (node) { tag = node.tagName.toLowerCase(); surrounding = (node.innerText || '').trim().slice(0, 600); }
    } catch (e) { }
    return { text: text.slice(0, 4000), surrounding, tag, url: location.href, title: document.title };
  }

  function getDialogs() {
    const sels = ['[role="dialog"]', '[role="alertdialog"]', 'dialog[open]', '.modal', '[aria-modal="true"]'];
    const out = [];
    for (const sel of sels) {
      for (const el of document.querySelectorAll(sel)) {
        if (isVisible(el)) out.push({ ref: refOf(el), text: (el.innerText || '').trim().slice(0, 300), bounds: rectOf(el) });
      }
    }
    return out;
  }

  /* ---------- reader mode: extract main article content ---------- */
  function getReaderText({ maxChars = 12000 } = {}) {
    const clean = s => (s || '').replace(/\s+/g, ' ').trim();
    const textOf = el => clean(el.innerText);
    // 1) semantic containers first
    let root = document.querySelector('article')
      || document.querySelector('main')
      || document.querySelector('[role="main"]');
    // 2) heuristic: score blocks by text density, penalize link-heavy blocks
    if (!root || textOf(root).length < 400) {
      let best = null, bestScore = 0;
      for (const el of document.querySelectorAll('article, main, section, div, td')) {
        if (!isVisible(el)) continue;
        const text = textOf(el);
        if (text.length < 300) continue;
        const linkText = [...el.querySelectorAll('a')].reduce((n, a) => n + clean(a.innerText).length, 0);
        const density = (text.length - linkText) / Math.max(1, text.length);
        const paraBonus = Math.min(6, el.querySelectorAll('p').length) * 0.12;
        const score = text.length * density * (0.4 + paraBonus);
        if (score > bestScore) { bestScore = score; best = el; }
      }
      if (best) root = best;
    }
    if (!root) return { found: false, text: '', note: 'no main content detected — try browser_get_visible_text' };
    const title = clean(document.querySelector('h1')?.innerText) || document.title;
    // collect readable blocks in order, skipping boilerplate
    const skip = /^(nav|header|footer|aside|script|style|form|button|select)$/i;
    const blocks = [];
    (function walk(node) {
      if (blocks.join('\n').length > maxChars * 2) return;
      for (const el of node.children) {
        if (skip.test(el.tagName)) continue;
        const t = textOf(el);
        if (/^(P|H[1-6]|LI|BLOCKQUOTE|PRE|FIGCAPTION)$/.test(el.tagName) && t.length > 1) {
          blocks.push(/^H[1-6]$/.test(el.tagName) ? '\n## ' + t : t);
        } else if (el.children.length && t.length > 1) walk(el);
      }
    })(root);
    let text = blocks.join('\n');
    if (text.length < 200) text = textOf(root); // fallback: whole container
    return {
      found: true,
      title,
      byline: clean(document.querySelector('[rel="author"], .byline, [class*="author"]')?.innerText) || undefined,
      excerpt: text.slice(0, 240),
      chars: text.length,
      truncated: text.length > maxChars,
      text: text.slice(0, maxChars),
    };
  }

  return {
    isVisible, inViewport, refOf, byRef, resetRefs, roleOf, nameOf, isSensitive, rectOf, elInfo,
    scanInteractive, getPageInfo, getVisibleText, getDOMSummary, findElements, findText,
    getLinks, getImages, getForms, getTables, extractTable, getSelectionContext, getDialogs,
    getReaderText,
    REF_ATTR,
  };
})();
