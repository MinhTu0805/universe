/* Nova Agent Browser — interaction engine (computer use).
 * Exposes NC.act: real synthetic input events dispatched into the page.
 * Strategy order for targeting: ref → css selector → role+name → text → coordinates. */
'use strict';

NC.act = (() => {
  const D = () => NC.dom;

  /* ================= target resolution ================= */
  function resolve(q = {}) {
    if (q.x !== undefined && q.y !== undefined) {
      const el = document.elementFromPoint(q.x, q.y);
      if (!el) throw new Error(`no element at (${q.x}, ${q.y})`);
      return el;
    }
    if (q.ref) {
      const el = D().byRef(q.ref);
      if (!el) throw Object.assign(new Error('stale ref — page changed, re-observe'), { code: 'STALE_REF' });
      return el;
    }
    if (q.selector) {
      const els = [...document.querySelectorAll(q.selector)].filter(D().isVisible);
      if (!els.length) throw new Error(`selector not found (visible): ${q.selector}`);
      return els[Math.min(q.index || 0, els.length - 1)];
    }
    if (q.role || q.name || q.text || q.tag) {
      const { matches } = D().findElements(q, { max: 5 });
      if (!matches.length) throw new Error(`element not found: ${JSON.stringify({ role: q.role, name: q.name, text: q.text })}`);
      const el = D().byRef(matches[0].ref);
      if (!el) throw Object.assign(new Error('stale ref — re-observe'), { code: 'STALE_REF' });
      return el;
    }
    throw new Error('no target given (need ref | selector | role+name | text | x,y)');
  }

  function pointOf(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }

  function ensureVisible(el) {
    if (!D().inViewport(el, 4)) {
      el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
    }
    // tiny settle for sticky headers / shifts
    return new Promise(r => setTimeout(r, 60));
  }

  /* ================= event dispatch ================= */
  const MOUSE_INIT = (x, y, extra = {}) => Object.assign({
    bubbles: true, cancelable: true, composed: true, view: window,
    clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: 1,
  }, extra);

  function mouseSeq(el, x, y, { button = 0, clicks = 1 } = {}) {
    const common = MOUSE_INIT(x, y, { button, buttons: button === 2 ? 2 : 1 });
    el.dispatchEvent(new PointerEvent('pointerover', common));
    el.dispatchEvent(new MouseEvent('mouseover', common));
    el.dispatchEvent(new PointerEvent('pointermove', common));
    el.dispatchEvent(new MouseEvent('mousemove', common));
    el.dispatchEvent(new PointerEvent('pointerdown', common));
    el.dispatchEvent(new MouseEvent('mousedown', common));
    try { el.focus({ preventScroll: true }); } catch (e) { }
    el.dispatchEvent(new PointerEvent('pointerup', Object.assign({}, common, { buttons: 0 })));
    el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, common, { buttons: 0 })));
    for (let i = 0; i < clicks; i++) {
      el.dispatchEvent(new PointerEvent('click', common));
      el.dispatchEvent(new MouseEvent('click', Object.assign({}, common, { detail: i + 1 })));
      if (clicks > 1 && i === clicks - 1) {
        el.dispatchEvent(new MouseEvent('dblclick', Object.assign({}, common, { detail: 2 })));
      }
    }
  }

  async function click(q = {}, opts = {}) {
    const el = resolve(q);
    await ensureVisible(el);
    let p;
    if (q.offsetX !== undefined && q.offsetY !== undefined) {
      const r = el.getBoundingClientRect();
      p = { x: Math.round(r.left + q.offsetX), y: Math.round(r.top + q.offsetY) };
    } else if (q.x !== undefined && q.y !== undefined) {
      p = { x: q.x, y: q.y };
    } else p = pointOf(el);
    NC.overlay?.clickMarker?.(p.x, p.y);
    if (opts.dblclick) mouseSeq(el, p.x, p.y, { clicks: 2 });
    else mouseSeq(el, p.x, p.y, { button: opts.button || 0 });
    if (opts.button === 2) {
      el.dispatchEvent(new PointerEvent('contextmenu', MOUSE_INIT(p.x, p.y, { button: 2 })));
      el.dispatchEvent(new MouseEvent('contextmenu', MOUSE_INIT(p.x, p.y, { button: 2 })));
    }
    return { clicked: true, at: p, target: D().elInfo(el, { withText: false }) };
  }

  async function hover(q = {}) {
    const el = resolve(q);
    await ensureVisible(el);
    const p = q.x !== undefined ? { x: q.x, y: q.y } : pointOf(el);
    const common = MOUSE_INIT(p.x, p.y, { buttons: 0 });
    el.dispatchEvent(new PointerEvent('pointerover', common));
    el.dispatchEvent(new MouseEvent('mouseover', common));
    el.dispatchEvent(new PointerEvent('pointermove', common));
    el.dispatchEvent(new MouseEvent('mousemove', common));
    return { hovered: true, at: p };
  }

  async function focus(q = {}) {
    const el = resolve(q);
    await ensureVisible(el);
    el.focus({ preventScroll: true });
    return { focused: document.activeElement === el, target: D().elInfo(el, { withText: false }) };
  }

  /* ================= typing (React/Vue/Angular safe) ================= */
  function nativeSet(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
  }

  function fireInput(el, inputType, data) {
    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, composed: true, inputType, data: data ?? null }));
    el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType, data: data ?? null }));
  }

  const KEYDEFS = {
    Enter: { key: 'Enter', code: 'Enter', keyCode: 13 }, Escape: { key: 'Escape', code: 'Escape', keyCode: 27 },
    Tab: { key: 'Tab', code: 'Tab', keyCode: 9 }, Backspace: { key: 'Backspace', code: 'Backspace', keyCode: 8 },
    Delete: { key: 'Delete', code: 'Delete', keyCode: 46 }, Space: { key: ' ', code: 'Space', keyCode: 32 },
    ArrowUp: { key: 'ArrowUp', code: 'ArrowUp', keyCode: 38 }, ArrowDown: { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40 },
    ArrowLeft: { key: 'ArrowLeft', code: 'ArrowLeft', keyCode: 37 }, ArrowRight: { key: 'ArrowRight', code: 'ArrowRight', keyCode: 39 },
    Home: { key: 'Home', code: 'Home', keyCode: 36 }, End: { key: 'End', code: 'End', keyCode: 35 },
    PageUp: { key: 'PageUp', code: 'PageUp', keyCode: 33 }, PageDown: { key: 'PageDown', code: 'PageDown', keyCode: 34 },
  };

  function keyEvent(el, type, def, mods = {}) {
    el.dispatchEvent(new KeyboardEvent(type, Object.assign({
      bubbles: true, cancelable: true, composed: true, view: window,
      key: def.key, code: def.code, keyCode: def.keyCode, which: def.keyCode,
    }, mods)));
  }

  async function type(q = {}, text = '', opts = {}) {
    const el = resolve(q);
    await ensureVisible(el);
    const editable = el.isContentEditable || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.getAttribute('role') === 'textbox' || el.getAttribute('role') === 'searchbox';
    el.focus({ preventScroll: true });
    el.dispatchEvent(new MouseEvent('click', MOUSE_INIT(...Object.values(pointOf(el)))));

    if (opts.clear) {
      if (editable && !el.isContentEditable) { nativeSet(el, ''); fireInput(el, 'deleteContentBackward', null); }
      else if (el.isContentEditable) { el.textContent = ''; fireInput(el, 'deleteContentBackward', null); }
    }

    if (el.isContentEditable) {
      // document.execCommand is deprecated but still the only way to emit trusted-ish text input into CE in many editors
      let done = false;
      try { done = document.execCommand('insertText', false, text); } catch (e) { }
      if (!done) { el.textContent = (el.textContent || '') + text; fireInput(el, 'insertText', text); }
    } else if (editable) {
      if (opts.perChar) {
        for (const ch of String(text)) {
          const def = { key: ch, code: 'Key' + ch.toUpperCase(), keyCode: ch.charCodeAt(0) };
          keyEvent(el, 'keydown', def); keyEvent(el, 'keypress', def);
          nativeSet(el, el.value + ch); fireInput(el, 'insertText', ch);
          keyEvent(el, 'keyup', def);
          if (opts.delay) await new Promise(r => setTimeout(r, opts.delay));
        }
      } else {
        keyEvent(el, 'keydown', { key: text[0] || 'a', code: 'KeyA', keyCode: 65 });
        nativeSet(el, (opts.append ? el.value : '') + text);
        fireInput(el, 'insertText', text);
        keyEvent(el, 'keyup', { key: text[text.length - 1] || 'a', code: 'KeyA', keyCode: 65 });
      }
    } else {
      // fallback: type into active element char by char
      for (const ch of String(text)) {
        const def = { key: ch, code: 'Key' + ch.toUpperCase(), keyCode: ch.charCodeAt(0) };
        keyEvent(document.activeElement || el, 'keydown', def);
        keyEvent(document.activeElement || el, 'keypress', def);
        keyEvent(document.activeElement || el, 'keyup', def);
      }
    }
    NC.overlay?.typeIndicator?.(el);
    return { typed: text.length, into: D().elInfo(el, { withText: false }) };
  }

  async function clearInput(q = {}) {
    const el = resolve(q);
    el.focus({ preventScroll: true });
    if (el.isContentEditable) el.textContent = '';
    else nativeSet(el, '');
    fireInput(el, 'deleteContentBackward', null);
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return { cleared: true };
  }

  async function pressKey(key, q = {}) {
    const def = KEYDEFS[key] || { key, code: key, keyCode: key.length === 1 ? key.toUpperCase().charCodeAt(0) : 0 };
    const el = q && Object.keys(q).length ? resolve(q) : (document.activeElement || document.body);
    keyEvent(el, 'keydown', def);
    if (def.key.length === 1 || key === 'Enter' || key === 'Space') keyEvent(el, 'keypress', def);
    keyEvent(el, 'keyup', def);
    return { pressed: key };
  }

  async function keyCombo(keys = [], q = {}) {
    const el = q && Object.keys(q).length ? resolve(q) : (document.activeElement || document.body);
    const mods = { ctrlKey: false, shiftKey: false, altKey: false, metaKey: false };
    const held = [];
    for (const k of keys) {
      const kn = String(k).toLowerCase();
      if (kn === 'ctrl' || kn === 'control') { mods.ctrlKey = true; held.push({ key: 'Control', code: 'ControlLeft', keyCode: 17 }); }
      else if (kn === 'shift') { mods.shiftKey = true; held.push({ key: 'Shift', code: 'ShiftLeft', keyCode: 16 }); }
      else if (kn === 'alt' || kn === 'option') { mods.altKey = true; held.push({ key: 'Alt', code: 'AltLeft', keyCode: 18 }); }
      else if (kn === 'meta' || kn === 'cmd' || kn === 'command') { mods.metaKey = true; held.push({ key: 'Meta', code: 'MetaLeft', keyCode: 91 }); }
      else held.push(KEYDEFS[k] || KEYDEFS[kn] || { key: k, code: 'Key' + String(k).toUpperCase(), keyCode: String(k).toUpperCase().charCodeAt(0) });
    }
    for (const h of held) keyEvent(el, 'keydown', h, mods);
    const main = held[held.length - 1];
    if (main && main.key && main.key.length === 1) keyEvent(el, 'keypress', main, mods);
    for (const h of [...held].reverse()) keyEvent(el, 'keyup', h, mods);
    return { combo: keys.join('+') };
  }

  /* ================= scroll ================= */
  function scrollInfo() {
    const de = document.documentElement;
    return { x: Math.round(scrollX), y: Math.round(scrollY), maxY: Math.round(Math.max(0, de.scrollHeight - innerHeight)), viewportH: innerHeight };
  }

  async function scroll(opts = {}) {
    let el = null;
    if (opts.ref || opts.selector) { el = resolve(opts); }
    const target = el || document.scrollingElement || document.documentElement;
    NC.overlay?.scrollGlow?.();
    if (opts.to === 'top') (el || window).scrollTo({ top: 0, behavior: 'instant' });
    else if (opts.to === 'bottom') (el || window).scrollTo({ top: target.scrollHeight, behavior: 'instant' });
    else if (opts.text) {
      const { matches } = D().findText(opts.text, { max: 1 });
      if (!matches.length) throw new Error('text not found on page: ' + opts.text);
      const node = D().byRef(matches[0].ref);
      node.scrollIntoView({ block: 'center', behavior: 'instant' });
    } else {
      const dx = opts.deltaX ?? 0;
      const dy = opts.deltaY ?? (opts.direction === 'up' ? -Math.round(innerHeight * 0.8) : Math.round(innerHeight * 0.8));
      if (el) { el.scrollTop += dy; el.scrollLeft += dx; }
      else window.scrollBy({ left: dx, top: dy, behavior: 'instant' });
    }
    await new Promise(r => setTimeout(r, 80));
    const info = scrollInfo();
    info.newContentHint = document.documentElement.scrollHeight;
    return info;
  }

  /* ================= drag ================= */
  /* Quỹ đạo "giống người": lao nhanh lúc đầu, chậm dần khi gần đích, rung nhẹ
   * giảm dần về 0. Slider/puzzle chống bot thường loại đường kéo thẳng tuyến
   * tính với nhịp cố định — đường này vượt qua được phần lớn heuristic đó. */
  function humanPath(p1, p2, steps = 24) {
    const n = Math.max(10, Math.min(80, steps | 0));
    const pts = [];
    for (let i = 1; i <= n; i++) {
      const t = i / n;
      const e = 1 - Math.pow(1 - t, 3); // ease-out cubic
      const decay = 1 - t;
      pts.push({
        x: p1.x + (p2.x - p1.x) * e + (Math.random() - 0.5) * 2.2 * decay,
        y: p1.y + (p2.y - p1.y) * e + (Math.random() - 0.5) * 3.4 * decay,
        dt: 8 + Math.random() * 18 + (t > 0.82 ? 14 + Math.random() * 26 : 0),
      });
    }
    return pts;
  }

  function fireTouch(type, target, x, y) {
    try {
      const t = new Touch({ identifier: 7, target, clientX: x, clientY: y, radiusX: 2, radiusY: 2, force: type === 'touchend' ? 0 : 0.5 });
      const touches = type === 'touchend' ? [] : [t];
      target.dispatchEvent(new TouchEvent(type, { bubbles: true, cancelable: true, composed: true, touches, targetTouches: touches, changedTouches: [t] }));
    } catch (e) { }
  }

  async function pointerPath(over, p1, p2, { steps = 12, humanize = false, touch = false } = {}) {
    const pts = humanize ? humanPath(p1, p2, steps)
      : Array.from({ length: Math.max(2, steps | 0) }, (_, i) => ({
        x: p1.x + (p2.x - p1.x) * (i + 1) / Math.max(2, steps | 0),
        y: p1.y + (p2.y - p1.y) * (i + 1) / Math.max(2, steps | 0), dt: 16,
      }));
    const sx = Math.round(p1.x), sy = Math.round(p1.y);
    over.dispatchEvent(new PointerEvent('pointerdown', MOUSE_INIT(sx, sy)));
    over.dispatchEvent(new MouseEvent('mousedown', MOUSE_INIT(sx, sy)));
    if (touch) fireTouch('touchstart', over, sx, sy);
    for (const p of pts) {
      const x = Math.round(p.x), y = Math.round(p.y);
      const under = document.elementFromPoint(x, y) || over;
      under.dispatchEvent(new PointerEvent('pointermove', MOUSE_INIT(x, y)));
      under.dispatchEvent(new MouseEvent('mousemove', MOUSE_INIT(x, y)));
      if (touch) fireTouch('touchmove', over, x, y); // touch events spec-wise luôn đi về target của touchstart
      await new Promise(r => setTimeout(r, p.dt));
    }
    // settle CHÍNH XÁC tại đích rồi mới nhả — jitter chỉ làm đường đi tự nhiên, không lệch đích
    const ex = Math.round(p2.x), ey = Math.round(p2.y);
    const endEl = document.elementFromPoint(ex, ey) || over;
    endEl.dispatchEvent(new PointerEvent('pointermove', MOUSE_INIT(ex, ey)));
    endEl.dispatchEvent(new MouseEvent('mousemove', MOUSE_INIT(ex, ey)));
    if (touch) fireTouch('touchmove', over, ex, ey);
    await new Promise(r => setTimeout(r, 50 + Math.random() * 70));
    endEl.dispatchEvent(new PointerEvent('pointerup', MOUSE_INIT(ex, ey, { buttons: 0 })));
    endEl.dispatchEvent(new MouseEvent('mouseup', MOUSE_INIT(ex, ey, { buttons: 0 })));
    if (touch) fireTouch('touchend', over, ex, ey);
    return endEl;
  }

  async function drag(from, to, { steps = 12 } = {}) {
    const startEl = resolve(from);
    await ensureVisible(startEl);
    const p1 = from.x !== undefined ? { x: from.x, y: from.y } : (from.offsetX !== undefined ? (() => { const r = startEl.getBoundingClientRect(); return { x: r.left + from.offsetX, y: r.top + from.offsetY }; })() : pointOf(startEl));
    const p2 = to.x !== undefined ? { x: to.x, y: to.y } : pointOf(resolve(to));
    const over = document.elementFromPoint(Math.round(p1.x), Math.round(p1.y)) || startEl;

    // pointer/mouse drag (works for canvas, maps, most custom UIs) — humanized
    const endEl = await pointerPath(over, p1, p2, { steps: Math.max(12, steps), humanize: true });

    // HTML5 DnD (best-effort, for sortable lists)
    try {
      const dt = new DataTransfer();
      startEl.dispatchEvent(new DragEvent('dragstart', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: p1.x, clientY: p1.y }));
      endEl.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: p2.x, clientY: p2.y }));
      endEl.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt, clientX: p2.x, clientY: p2.y }));
      startEl.dispatchEvent(new DragEvent('dragend', { bubbles: true, dataTransfer: dt, clientX: p2.x, clientY: p2.y }));
    } catch (e) { }
    return { dragged: true, from: p1, to: p2 };
  }

  /* ================= slider / mảnh ghép puzzle =================
   * Kéo núm trượt hoặc mảnh ghép tới đích: `to` (element/point), hoặc dx/dy,
   * hoặc auto = kéo hết hành trình rãnh trượt. Trả về độ dịch chuyển thực tế
   * để agent biết trang có chấp nhận cú kéo không (và tự kéo bù nếu cần). */
  async function slide({ handle, to, dx = 0, dy = 0, axis = 'auto', steps = 28 } = {}) {
    const h = resolve(handle || {});
    await ensureVisible(h);
    const hr = h.getBoundingClientRect();
    const p1 = { x: hr.left + hr.width / 2, y: hr.top + hr.height / 2 };

    const isAriaSlider = (h.getAttribute('role') || '').toLowerCase() === 'slider';
    let ax = axis;
    if (ax === 'auto') ax = h.getAttribute('aria-orientation') === 'vertical' ? 'y' : 'x';

    let p2;
    const hasTo = to && (to.x !== undefined || to.ref || to.selector || to.role || to.name || to.text);
    if (hasTo) {
      const tp = to.x !== undefined ? { x: to.x, y: to.y } : pointOf(resolve(to));
      // đích là 1 phần tử/điểm cụ thể → tôn trọng cả 2 trục (mảnh ghép 2 chiều);
      // nếu user khoá trục thì chỉ trượt theo trục đó
      p2 = axis === 'auto' ? tp : { x: ax === 'y' ? p1.x : tp.x, y: ax === 'x' ? p1.y : tp.y };
    } else if (dx || dy) {
      p2 = { x: p1.x + (ax === 'y' ? 0 : dx), y: p1.y + (ax === 'x' ? 0 : dy) };
    } else {
      // auto: kéo hết hành trình — track = tổ tiên gần nhất đủ lớn hơn handle
      let track = h.parentElement;
      for (let i = 0; i < 4 && track; i++, track = track.parentElement) {
        const tr = track.getBoundingClientRect();
        if (ax === 'y' ? tr.height > hr.height * 1.6 : tr.width > hr.width * 1.6) break;
      }
      const tr = (track || h.parentElement || h).getBoundingClientRect();
      p2 = ax === 'y'
        ? { x: p1.x, y: tr.bottom - hr.height / 2 - 2 }
        : { x: tr.right - hr.width / 2 - 2, y: p1.y };
    }
    p2 = { x: Math.round(Math.max(0, Math.min(innerWidth - 1, p2.x))), y: Math.round(Math.max(0, Math.min(innerHeight - 1, p2.y))) };

    const over = document.elementFromPoint(Math.round(p1.x), Math.round(p1.y)) || h;
    NC.overlay?.clickMarker?.(Math.round(p1.x), Math.round(p1.y));
    await pointerPath(over, p1, p2, { steps, humanize: true, touch: true });

    await new Promise(r => setTimeout(r, 250)); // chờ trang xử lý sau khi nhả
    const hr2 = h.getBoundingClientRect();
    const movedBy = { x: Math.round(hr2.left - hr.left), y: Math.round(hr2.top - hr.top) };
    const moved = Math.abs(movedBy.x) + Math.abs(movedBy.y);
    return {
      moved, movedBy,
      ariaValueNow: isAriaSlider ? (h.getAttribute('aria-valuenow') ?? undefined) : undefined,
      from: { x: Math.round(p1.x), y: Math.round(p1.y) }, to: p2, synthetic: true,
      note: moved > 2
        ? 'Handle đã di chuyển. HÃY chụp màn hình (browser_screenshot) kiểm chứng mảnh ghép/đáp án đã khớp chưa — chưa khớp thì gọi browser_slide bù thêm một đoạn nhỏ (dx/dy).'
        : 'Handle GẦN NHƯ KHÔNG NHÚC NHÍCH — trang có thể chặn sự kiện tổng hợp. Hãy bật Settings → Browser → "Chế độ debug (CDP)" rồi dùng browser_debug_drag (sự kiện chuột tin cậy). Tuyệt đối không dùng cho CAPTCHA.',
    };
  }

  /* ================= form widgets ================= */
  async function selectOption(q = {}, { value, label, index } = {}) {
    const el = resolve(q);
    if (el.tagName !== 'SELECT') throw new Error('target is not a <select>');
    el.focus({ preventScroll: true });
    let opt = null;
    if (value !== undefined) opt = [...el.options].find(o => o.value === value);
    if (!opt && label !== undefined) { const l = String(label).toLowerCase(); opt = [...el.options].find(o => o.text.trim().toLowerCase() === l) || [...el.options].find(o => o.text.trim().toLowerCase().includes(l)); }
    if (!opt && index !== undefined) opt = el.options[index];
    if (!opt) throw new Error('option not found');
    el.value = opt.value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return { selected: { value: opt.value, label: opt.text.trim() } };
  }

  async function setChecked(q = {}, checked = true) {
    const el = resolve(q);
    if (el.tagName === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio')) {
      if (el.checked !== checked) { await ensureVisible(el); mouseSeq(el, ...Object.values(pointOf(el))); }
      return { checked: el.checked };
    }
    // aria checkbox / switch
    const cur = el.getAttribute('aria-checked') === 'true';
    if (cur !== checked) await click({ ref: D().refOf(el) });
    return { checked: el.getAttribute('aria-checked') === 'true' };
  }

  async function submit(q = {}) {
    let form = null;
    if (q && Object.keys(q).length) {
      const el = resolve(q);
      form = el.tagName === 'FORM' ? el : el.closest('form');
    } else form = document.forms[0];
    if (!form) throw new Error('no form found');
    if (form.requestSubmit) form.requestSubmit();
    else form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    return { submitted: true };
  }

  /* ================= upload ================= */
  async function uploadFiles(q = {}, files = []) {
    const el = resolve(q);
    if (el.tagName !== 'INPUT' || el.type !== 'file') throw new Error('target is not <input type=file>');
    const dt = new DataTransfer();
    for (const f of files) {
      const bin = atob(f.base64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      dt.items.add(new File([bytes], f.name, { type: f.type || 'application/octet-stream' }));
    }
    el.files = dt.files;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return { uploaded: [...el.files].map(f => ({ name: f.name, size: f.size, type: f.type })) };
  }

  /* ================= waits ================= */
  async function waitFor({ selector, text, timeout = 8000, visible = true } = {}) {
    const t0 = Date.now();
    return new Promise((res, rej) => {
      const check = () => {
        let found = false;
        if (selector) {
          try { found = [...document.querySelectorAll(selector)].some(e => !visible || D().isVisible(e)); } catch (e) { }
        }
        if (!found && text) found = (document.body?.innerText || '').includes(text);
        if (found) { res({ found: true, waitedMs: Date.now() - t0 }); return true; }
        if (Date.now() - t0 > timeout) { rej(Object.assign(new Error(`timeout waiting for ${selector || text}`), { code: 'TIMEOUT' })); return true; }
        return false;
      };
      if (check()) return;
      const mo = new MutationObserver(() => { if (check()) mo.disconnect(); });
      mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true });
      setTimeout(() => { mo.disconnect(); if (!check()) rej(Object.assign(new Error('wait timeout'), { code: 'TIMEOUT' })); }, timeout + 100);
    });
  }

  /* ================= execute script (policy-gated upstream) ================= */
  async function executeScript(code) {
    // Runs inside the isolated content-script world. No eval: constructed via
    // the page's own event loop is impossible without eval — so we restrict to
    // JSON-serialisable micro-ops performed via a whitelisted mini-DSL.
    // Supported op: {op:'query', selector} | {op:'attr', selector, name} | {op:'setAttr', selector, name, value} | {op:'remove', selector} | {op:'clickAll', selector} | {op:'text', selector}
    const op = typeof code === 'string' ? JSON.parse(code) : code;
    const els = op.selector ? [...document.querySelectorAll(op.selector)] : [];
    switch (op.op) {
      case 'query': return els.slice(0, 100).map(e => D().elInfo(e, { withText: true }));
      case 'text': return els.slice(0, 20).map(e => (e.innerText || '').slice(0, 500));
      case 'attr': return els.slice(0, 20).map(e => e.getAttribute(op.name));
      case 'setAttr': els.slice(0, 50).forEach(e => e.setAttribute(op.name, op.value)); return { set: els.length };
      case 'remove': els.slice(0, 50).forEach(e => e.remove()); return { removed: els.length };
      case 'clickAll': els.slice(0, 20).forEach(e => e.click()); return { clicked: els.length };
      case 'count': return { count: els.length };
      default: throw new Error('unsupported op: ' + op.op);
    }
  }

  return { resolve, pointOf, ensureVisible, click, hover, focus, type, clearInput, pressKey, keyCombo, scroll, scrollInfo, drag, slide, selectOption, setChecked, submit, uploadFiles, waitFor, executeScript };
})();
