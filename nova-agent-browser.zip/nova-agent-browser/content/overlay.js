/* Nova Agent Browser — on-page overlay.
 * Edge lightning (agent lifecycle states) + action overlay
 * (element highlight, click ripple, typing indicator, status badge).
 * Rendered inside a closed-ish shadow root so page CSS cannot break it. */
'use strict';

NC.overlay = (() => {
  const ROOT_ID = 'nova-agent-overlay-root';
  let host = null, shadow = null;
  let state = 'idle';
  let fadeTimer = null;

  const CSS = `
    @property --na { syntax:'<angle>'; initial-value:0deg; inherits:false; }
    * { box-sizing:border-box; margin:0; padding:0; }
    .edge { position:fixed; inset:0; z-index:2147483646; pointer-events:none; opacity:0;
            transition:opacity .45s ease; }
    .edge::before { content:''; position:absolute; inset:0; padding:2.5px; border-radius:3px;
            -webkit-mask:linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
            -webkit-mask-composite:xor; mask-composite:exclude;
            background:conic-gradient(from var(--na),
              transparent 0%, var(--c1) 6%, transparent 14%,
              transparent 38%, var(--c2) 46%, transparent 54%,
              transparent 76%, var(--c1) 84%, transparent 94%);
            animation:na-rotate var(--spd,3.2s) linear infinite; }
    .edge::after { content:''; position:absolute; inset:0; pointer-events:none;
            box-shadow:inset 0 0 22px -8px var(--glow); opacity:var(--glowop,.5); transition:opacity .5s; }
    @keyframes na-rotate { to { --na:360deg; } }

    .edge.thinking { opacity:.75; --c1:rgba(255,255,255,.28); --c2:rgba(255,255,255,.12); --glow:rgba(255,255,255,.14); --spd:5.5s; }
    .edge.observing { opacity:.85; --c1:rgba(255,255,255,.38); --c2:rgba(255,255,255,.16); --glow:rgba(255,255,255,.16); --spd:4.2s; }
    .edge.acting { opacity:1; --c1:rgba(255,255,255,.85); --c2:rgba(255,255,255,.35); --glow:rgba(255,255,255,.28); --glowop:.8; --spd:1.9s; }
    .edge.waiting { opacity:.8; --c1:rgba(255,255,255,.30); --c2:rgba(255,255,255,.10); --glow:rgba(255,255,255,.12); --spd:3.4s; animation:na-pulse 2.4s ease-in-out infinite; }
    .edge.waiting::before { animation:na-rotate 3.4s linear infinite; }
    @keyframes na-pulse { 0%,100% { opacity:.45; } 50% { opacity:.95; } }
    .edge.approval { opacity:.9; --c1:rgba(232,184,75,.75); --c2:rgba(232,184,75,.28); --glow:rgba(232,184,75,.3); --spd:2.6s; }
    .edge.done { opacity:1; --c1:rgba(89,203,141,.9); --c2:rgba(89,203,141,.35); --glow:rgba(89,203,141,.35); --spd:1.2s; }
    .edge.error { opacity:1; --c1:rgba(229,106,90,.85); --c2:rgba(229,106,90,.3); --glow:rgba(229,106,90,.3); --spd:2.2s; animation:na-pulse 1.6s ease-in-out infinite; }
    .edge.error::before { animation:na-rotate 2.2s linear infinite; }

    .badge { position:fixed; right:10px; bottom:10px; z-index:2147483647; pointer-events:none;
             display:none; align-items:center; gap:7px; padding:5px 11px 5px 9px; border-radius:20px;
             background:rgba(16,16,16,.78); border:1px solid rgba(255,255,255,.14);
             backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);
             color:rgba(255,255,255,.85); font:600 10.5px/1 -apple-system,'Inter',system-ui,sans-serif;
             letter-spacing:.08em; text-transform:uppercase; }
    .badge.show { display:flex; }
    .badge i { width:6px; height:6px; border-radius:50%; background:#fff; display:block; animation:na-blink 1.2s ease-in-out infinite; }
    .badge.error i { background:#e56a5a; } .badge.done i { background:#59cb8d; } .badge.approval i { background:#e8b84b; }
    @keyframes na-blink { 0%,100% { opacity:.35; } 50% { opacity:1; } }

    .hl { position:fixed; z-index:2147483645; pointer-events:none; border:1.5px solid rgba(255,255,255,.9);
          border-radius:6px; box-shadow:0 0 0 3px rgba(255,255,255,.12), 0 0 18px rgba(255,255,255,.18);
          opacity:0; transition:opacity .12s ease; }
    .hl.show { opacity:1; }
    .hl .tag { position:absolute; left:-1.5px; top:-22px; padding:2px 8px; border-radius:5px 5px 5px 0;
          background:rgba(255,255,255,.92); color:#111; font:600 10px/1.5 -apple-system,'Inter',sans-serif;
          letter-spacing:.02em; white-space:nowrap; max-width:280px; overflow:hidden; text-overflow:ellipsis; }

    .ripple { position:fixed; z-index:2147483647; pointer-events:none; width:10px; height:10px; margin:-5px 0 0 -5px;
          border-radius:50%; border:2px solid rgba(255,255,255,.95); animation:na-ripple .55s ease-out forwards; }
    @keyframes na-ripple { from { transform:scale(.6); opacity:1; } to { transform:scale(4.2); opacity:0; } }

    .cursor { position:fixed; z-index:2147483647; pointer-events:none; width:18px; height:18px; margin:-9px 0 0 -9px;
          border-radius:50%; border:1.5px solid rgba(255,255,255,.9); box-shadow:0 0 10px rgba(255,255,255,.35);
          opacity:0; transition:opacity .15s; }
    .cursor.show { opacity:1; }

    .caret { position:fixed; z-index:2147483647; pointer-events:none; padding:2px 7px; border-radius:4px;
          background:rgba(16,16,16,.85); border:1px solid rgba(255,255,255,.2); color:rgba(255,255,255,.85);
          font:500 9.5px/1.4 'JetBrains Mono',ui-monospace,monospace; letter-spacing:.04em;
          opacity:0; transition:opacity .15s; }
    .caret.show { opacity:1; animation:na-blink 1s ease-in-out infinite; }
  `;

  function mount() {
    if (host && document.documentElement.contains(host)) return;
    host = document.createElement('div');
    host.id = ROOT_ID;
    shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = CSS;
    shadow.appendChild(style);
    shadow.innerHTML += `
      <div class="edge"></div>
      <div class="badge"><i></i><span class="txt">NOVA · ACTING</span></div>
      <div class="hl"><div class="tag"></div></div>
      <div class="cursor"></div>
      <div class="caret">typing…</div>`;
    document.documentElement.appendChild(host);
  }

  const $ = s => shadow?.querySelector(s);

  function setState(next, { badgeText } = {}) {
    state = next;
    mount();
    const edge = $('.edge'), badge = $('.badge');
    clearTimeout(fadeTimer);
    edge.className = 'edge';
    if (next === 'idle' || next === 'stopped') {
      badge.className = 'badge';
      return; // no edge
    }
    if (next === 'completed') {
      edge.classList.add('done');
      badge.className = 'badge done show';
      badge.querySelector('.txt').textContent = badgeText || 'NOVA · DONE';
      fadeTimer = setTimeout(() => setState('idle'), 2200);
      return;
    }
    const EDGE_STATES = { thinking: 1, observing: 1, acting: 1, waiting: 1, approval: 1, done: 1, error: 1 };
    const edgeCls = next === 'awaiting_approval' ? 'approval' : EDGE_STATES[next] ? next : 'thinking';
    edge.classList.add(edgeCls);
    badge.className = 'badge show' + (next === 'error' ? ' error' : next === 'awaiting_approval' ? ' approval' : '');
    const label = badgeText || ({
      thinking: 'NOVA · THINKING', observing: 'NOVA · OBSERVING', acting: 'NOVA · ACTING',
      waiting: 'NOVA · WAITING', awaiting_approval: 'NOVA · NEEDS YOU', error: 'NOVA · ERROR',
      paused: 'NOVA · PAUSED', planning: 'NOVA · PLANNING', verifying: 'NOVA · VERIFYING', recovering: 'NOVA · RECOVERING',
    })[next] || ('NOVA · ' + String(next).toUpperCase());
    badge.querySelector('.txt').textContent = label;
  }

  let hlTimer = null;
  function highlight(el, { label, ms = 900 } = {}) {
    if (!el) return;
    mount();
    const r = el.getBoundingClientRect();
    const box = $('.hl');
    box.style.left = (r.left - 3) + 'px';
    box.style.top = (r.top - 3) + 'px';
    box.style.width = (r.width + 6) + 'px';
    box.style.height = (r.height + 6) + 'px';
    const tag = box.querySelector('.tag');
    tag.textContent = label || '';
    tag.style.display = label ? 'block' : 'none';
    if (label && r.top < 26) tag.style.top = (r.height + 5) + 'px'; else tag.style.top = '-22px';
    box.classList.add('show');
    clearTimeout(hlTimer);
    hlTimer = setTimeout(() => box.classList.remove('show'), ms);
  }

  function clickMarker(x, y) {
    mount();
    const rip = document.createElement('div');
    rip.className = 'ripple';
    rip.style.left = x + 'px';
    rip.style.top = y + 'px';
    shadow.appendChild(rip);
    setTimeout(() => rip.remove(), 650);
  }

  let caretTimer = null;
  function typeIndicator(el) {
    mount();
    const r = el.getBoundingClientRect();
    const c = $('.caret');
    c.style.left = Math.min(innerWidth - 90, Math.max(4, r.left)) + 'px';
    c.style.top = Math.max(4, r.top - 26) + 'px';
    c.classList.add('show');
    clearTimeout(caretTimer);
    caretTimer = setTimeout(() => c.classList.remove('show'), 1200);
  }

  function cursorTo(x, y) {
    mount();
    const c = $('.cursor');
    c.classList.add('show');
    c.style.transition = 'left .18s ease, top .18s ease, opacity .15s';
    c.style.left = x + 'px';
    c.style.top = y + 'px';
  }
  function cursorHide() { $('.cursor')?.classList.remove('show'); }

  function clear() { setState('idle'); if (host) { host.remove(); host = null; shadow = null; } }

  return { setState, highlight, clickMarker, typeIndicator, cursorTo, cursorHide, clear, get state() { return state; } };
})();
