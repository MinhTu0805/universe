/* Nova Agent Browser — selection tracking.
 * Reports text selections to the background (top frame only, debounced,
 * lightweight). Powers "Ask about selection" flows. */
'use strict';

NC.sel = (() => {
  let last = '';
  let timer = null;

  function current() {
    try { return NC.dom.getSelectionContext(); } catch (e) { return { text: '' }; }
  }

  function push() {
    if (self !== top) return; // top frame only
    const ctx = current();
    const text = ctx.text || '';
    if (text === last) return;
    last = text;
    try {
      chrome.runtime.sendMessage({ type: 'nova-selection', payload: text ? ctx : { text: '' } }, () => void chrome.runtime.lastError);
    } catch (e) { }
  }

  function init() {
    document.addEventListener('selectionchange', () => {
      clearTimeout(timer);
      timer = setTimeout(push, 350);
    }, { passive: true });
  }

  return { init, current, push };
})();
