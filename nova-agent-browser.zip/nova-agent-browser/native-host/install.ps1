# ============================================================
# Nova Agent Browser — terminal bridge installer (Windows)
#
# Cách dùng (PowerShell):
#   powershell -ExecutionPolicy Bypass -File install.ps1 -ExtensionId <chrome-extension-id>
#
# Lấy <chrome-extension-id>: mở chrome://extensions → bật "Developer mode"
# → copy ID của Nova Agent Browser (32 ký tự a-p).
# ============================================================
param(
    [Parameter(Mandatory = $true)][string]$ExtensionId
)

$ErrorActionPreference = 'Stop'
$HostName = 'com.nova.agent.host'

function Ok   { param($m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Die  { param($m) Write-Host "  [X]  $m" -ForegroundColor Red; exit 1 }

# ---------- 1. validate extension id ----------
if ($ExtensionId -notmatch '^[a-p]{32}$') {
    Die "Extension ID khong hop le: '$ExtensionId'`n  ID phai gom dung 32 ky tu chu thuong a-p (copy tai chrome://extensions)."
}

# ---------- 2. locate python (python, py -3) ----------
$Python = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $Python) { $Python = (Get-Command py -ErrorAction SilentlyContinue).Source }
if (-not $Python) {
    Die 'Khong tim thay Python trong PATH. Cai Python 3 tu https://www.python.org (tick "Add python.exe to PATH") roi chay lai.'
}
$PyBase = Get-Command python -ErrorAction SilentlyContinue
$PyCmd = if ($PyBase) { 'python' } else { 'py' }

# python >= 3.8
$PyVer = & $PyCmd -c 'import sys;print("%d.%d" % sys.version_info[:2])'
& $PyCmd -c 'import sys;sys.exit(0 if sys.version_info >= (3, 8) else 1)'
if ($LASTEXITCODE -ne 0) { Die "Python $PyVer qua cu — can Python >= 3.8." }
Ok "python $PyVer -> $PyCmd"

# ---------- 3. install location ----------
$InstallDir = Join-Path $env:LOCALAPPDATA 'NovaAgent'
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'nova_host.py') (Join-Path $InstallDir 'nova_host.py') -Force
Ok "host -> $InstallDir\nova_host.py"

# Chrome on Windows needs an executable target — use a .bat wrapper
$Bat = Join-Path $InstallDir 'nova_host.bat'
Set-Content -Path $Bat -Value "@echo off`r`n$PyCmd `"$InstallDir\nova_host.py`" %*" -Encoding ASCII

# ---------- 4. selftest ----------
$SelfOut = & $PyCmd "$InstallDir\nova_host.py" --selftest 2>$null
if ($LASTEXITCODE -ne 0 -or $SelfOut -notmatch 'NOVA_HOST_SELFTEST_OK') {
    Die "Self-test that bai. Chay thu cong de xem loi:`n  $PyCmd `"$InstallDir\nova_host.py`" --selftest"
}
Ok "self-test OK"

# ---------- 5. native messaging manifest ----------
$Manifest = Join-Path $InstallDir "$HostName.json"
$ManifestObj = @{
    name            = $HostName
    description     = 'Nova Agent Browser - local terminal bridge'
    path            = $Bat
    type            = 'stdio'
    allowed_origins = @("chrome-extension://$ExtensionId/")
}
$ManifestObj | ConvertTo-Json -Depth 4 | Set-Content -Path $Manifest -Encoding UTF8
Ok "manifest -> $Manifest"

# ---------- 6. registry keys (HKCU — khong can quyen admin) ----------
$RegPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName"
New-Item -Path $RegPath -Force | Out-Null
Set-ItemProperty -Path $RegPath -Name '(Default)' -Value $Manifest
Ok "registry -> $RegPath"

$RegEdge = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName"
New-Item -Path $RegEdge -Force | Out-Null
Set-ItemProperty -Path $RegEdge -Name '(Default)' -Value $Manifest
Ok "registry -> $RegEdge"

Write-Host ''
Write-Host 'Hoan tat. Buoc tiep theo:' -ForegroundColor Green
Write-Host '  1. Mo Nova Agent -> Cai dat -> Terminal -> "Kiem tra ket noi".'
Write-Host '  2. Neu bao loi, xem Troubleshooting trong tab Terminal cua Cai dat.'
Write-Host ''
Write-Host 'Kiem tra registry (neu can):'
Write-Host "  reg query `"HKCU\Software\Google\Chrome\NativeMessagingHosts\$HostName`""
