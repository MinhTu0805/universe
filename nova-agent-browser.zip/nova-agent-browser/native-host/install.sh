#!/usr/bin/env bash
# ============================================================
# Nova Agent Browser — terminal bridge installer (macOS / Linux)
#
# Cách dùng:
#   chmod +x install.sh
#   ./install.sh <chrome-extension-id>
#
# Lấy <chrome-extension-id>: mở chrome://extensions → bật "Developer mode"
# → copy ID của Nova Agent Browser (32 ký tự a-p).
# ============================================================
set -euo pipefail

HOST_NAME="com.nova.agent.host"
EXT_ID="${1:-}"

say()  { printf '%s\n' "$*"; }
ok()   { printf '✓ %s\n' "$*"; }
warn() { printf '⚠ %s\n' "$*" >&2; }
die()  { printf '✗ %s\n' "$*" >&2; exit 1; }

# ---------- 1. validate extension id ----------
if [[ -z "$EXT_ID" ]]; then
  say "Usage: ./install.sh <chrome-extension-id>"
  say "  (chrome://extensions → bật Developer mode → copy ID của Nova Agent Browser)"
  exit 1
fi
if [[ ! "$EXT_ID" =~ ^[a-p]{32}$ ]]; then
  die "Extension ID không hợp lệ: '$EXT_ID'
  ID phải gồm đúng 32 ký tự chữ thường a-p (copy tại chrome://extensions)."
fi

# ---------- 2. python3 >= 3.8 ----------
PYTHON="$(command -v python3 || true)"
[[ -z "$PYTHON" ]] && die "Không tìm thấy python3 trong PATH.
  - macOS:  brew install python   (hoặc tải tại python.org)
  - Ubuntu/Debian:  sudo apt install python3
  - Fedora:  sudo dnf install python3"

PY_VER="$("$PYTHON" -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
"$PYTHON" -c 'import sys;sys.exit(0 if sys.version_info>=(3,8) else 1)' \
  || die "Python $PY_VER quá cũ — cần Python >= 3.8."
ok "python3 $PY_VER → $PYTHON"

# ---------- 3. copy host + launcher ----------
INSTALL_DIR="$HOME/.nova-agent"
mkdir -p "$INSTALL_DIR"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/nova_host.py" "$INSTALL_DIR/nova_host.py"
chmod +x "$INSTALL_DIR/nova_host.py"

LAUNCHER="$INSTALL_DIR/nova_host_launcher.sh"
cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
exec "$PYTHON" "$INSTALL_DIR/nova_host.py"
EOF
chmod +x "$LAUNCHER"
ok "host → $INSTALL_DIR/nova_host.py"

# ---------- 4. selftest ----------
if ! "$PYTHON" "$INSTALL_DIR/nova_host.py" --selftest >/dev/null 2>&1; then
  die "Self-test thất bại. Chạy thủ công để xem lỗi:
  $PYTHON $INSTALL_DIR/nova_host.py --selftest"
fi
ok "self-test OK"

# ---------- 5. native messaging manifest ----------
MANIFEST="$INSTALL_DIR/$HOST_NAME.json"
cat > "$MANIFEST" <<EOF
{
  "name": "$HOST_NAME",
  "description": "Nova Agent Browser — local terminal bridge",
  "path": "$LAUNCHER",
  "type": "stdio",
  "allowed_origins": ["chrome-extension://$EXT_ID/"]
}
EOF

# ---------- 6. register per-OS / per-browser ----------
OS="$(uname -s)"
declare -a DIRS=()
if [[ "$OS" == "Darwin" ]]; then
  DIRS+=(
    "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
    "$HOME/Library/Application Support/Chromium/NativeMessagingHosts"
    "$HOME/Library/Application Support/Microsoft Edge/NativeMessagingHosts"
    "$HOME/Library/Application Support/BraveSoftware/Brave-Browser/NativeMessagingHosts"
    "$HOME/Library/Application Support/Arc/User Data/NativeMessagingHosts"
  )
else
  DIRS+=(
    "$HOME/.config/google-chrome/NativeMessagingHosts"
    "$HOME/.config/chromium/NativeMessagingHosts"
    "$HOME/.config/microsoft-edge/NativeMessagingHosts"
    "$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts"
  )
fi

REGISTERED=0
for d in "${DIRS[@]}"; do
  parent="$(dirname "$d")"
  if [[ -d "$parent" ]]; then
    mkdir -p "$d"
    cp "$MANIFEST" "$d/$HOST_NAME.json"
    ok "registered → $d/$HOST_NAME.json"
    REGISTERED=1
  fi
done

if [[ "$REGISTERED" -eq 0 ]]; then
  # no browser profile detected — register for the Chrome path anyway
  d="${DIRS[0]}"
  mkdir -p "$d"
  cp "$MANIFEST" "$d/$HOST_NAME.json"
  ok "registered (default) → $d/$HOST_NAME.json"
fi

cat <<EOF

Hoàn tất. Bước tiếp theo:
  1. Mở Nova Agent → Cài đặt → Terminal → "Kiểm tra kết nối".
  2. Nếu báo lỗi, xem Troubleshooting trong tab Terminal của Cài đặt.

Gỡ cài đặt (nếu cần):
  rm -rf "$INSTALL_DIR"
  rm -f "${DIRS[0]}/$HOST_NAME.json"
EOF
