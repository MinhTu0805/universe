#!/usr/bin/env python3
"""Nova Agent Browser — native messaging terminal bridge.

Implements the Chrome native messaging protocol (4-byte LE length + JSON).

  ext → host: {"type":"ping"}
              {"id":..., "type":"exec", "command":..., "cwd":..., "timeoutSec":...}
              {"id":..., "type":"cancel"}
  host → ext: {"type":"pong", "version":..., "os":..., "shell":...}
              {"id":..., "type":"started", "pid":...}
              {"id":..., "type":"stdout"|"stderr", "data":...}      (streamed, chunked)
              {"id":..., "type":"exit", "code":..., "durationMs":..., "cancelled":...}
              {"id":..., "type":"error", "message":...}

Only ever writes protocol frames to stdout; logs go to stderr (Chrome ignores it).
"""

import json
import os
import platform
import queue
import shlex
import signal
import struct
import subprocess
import sys
import threading
import time

VERSION = "0.2.0"
MAX_CHUNK = 240 * 1024          # stay well under Chrome's 1 MB host→ext message cap
DEFAULT_TIMEOUT = 60
MAX_TIMEOUT = 30 * 60

_write_lock = threading.Lock()
_processes = {}                 # id -> subprocess.Popen
_procs_lock = threading.Lock()
_cancelled = set()              # ids killed via explicit cancel


def send(obj):
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    with _write_lock:
        sys.stdout.buffer.write(struct.pack("<I", len(data)))
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


def log(*args):
    print("[nova-host]", *args, file=sys.stderr, flush=True)


def recv():
    head = sys.stdin.buffer.read(4)
    if len(head) < 4:
        return None
    (n,) = struct.unpack("<I", head)
    if n <= 0 or n > 64 * 1024 * 1024:
        return None
    body = sys.stdin.buffer.read(n)
    if len(body) < n:
        return None
    try:
        return json.loads(body.decode("utf-8"))
    except Exception:
        return None


def _kill_tree(proc):
    """Best-effort kill of the whole process tree/group."""
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10,
            )
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _reader(stream, q, tag, jid):
    try:
        while True:
            chunk = stream.read1(8192) if hasattr(stream, "read1") else stream.read(8192)
            if not chunk:
                break
            q.put((jid, tag, chunk))
    except Exception:
        pass
    finally:
        q.put((jid, tag, None))  # EOF marker


def run_exec(msg):
    jid = str(msg.get("id"))
    command = str(msg.get("command") or "")
    cwd = os.path.expanduser(str(msg.get("cwd") or "~"))
    try:
        timeout = min(MAX_TIMEOUT, max(1, int(msg.get("timeoutSec") or DEFAULT_TIMEOUT)))
    except Exception:
        timeout = DEFAULT_TIMEOUT

    if not command.strip():
        send({"id": jid, "type": "error", "message": "empty command"})
        return
    try:
        os.makedirs(cwd, exist_ok=True)
    except Exception:
        cwd = os.path.expanduser("~")

    popen_kwargs = dict(
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=cwd,
        stdin=subprocess.DEVNULL,
    )
    if os.name == "nt":
        popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
        shell_cmd = command
    else:
        popen_kwargs["preexec_fn"] = os.setsid
        shell_cmd = command

    try:
        proc = subprocess.Popen(shell_cmd, shell=True, **popen_kwargs)
    except Exception as e:
        send({"id": jid, "type": "error", "message": f"failed to start: {e}"})
        return

    with _procs_lock:
        _processes[jid] = proc
    send({"id": jid, "type": "started", "pid": proc.pid})

    q = queue.Queue()
    t0 = time.monotonic()
    threads = [
        threading.Thread(target=_reader, args=(proc.stdout, q, "stdout", jid), daemon=True),
        threading.Thread(target=_reader, args=(proc.stderr, q, "stderr", jid), daemon=True),
    ]
    for t in threads:
        t.start()

    eof = {"stdout": False, "stderr": False}
    cancelled = False

    while not (eof["stdout"] and eof["stderr"]):
        if proc.poll() is not None and all(not t.is_alive() for t in threads):
            # drain remaining queue items then finish
            while True:
                try:
                    _, tag, chunk = q.get_nowait()
                except queue.Empty:
                    break
                if chunk is None:
                    eof[tag] = True
                else:
                    _send_chunked(jid, tag, chunk)
            break
        if time.monotonic() - t0 > timeout:
            cancelled = True
            _kill_tree(proc)
        try:
            _, tag, chunk = q.get(timeout=0.1)
        except queue.Empty:
            continue
        if chunk is None:
            eof[tag] = True
        else:
            _send_chunked(jid, tag, chunk)

    for t in threads:
        t.join(timeout=2)
    try:
        code = proc.wait(timeout=5)
    except Exception:
        code = proc.returncode if proc.returncode is not None else -1

    with _procs_lock:
        _processes.pop(jid, None)
    was_cancelled = cancelled or jid in _cancelled
    _cancelled.discard(jid)
    duration_ms = int((time.monotonic() - t0) * 1000)
    send({
        "id": jid, "type": "exit", "code": code,
        "durationMs": duration_ms, "cancelled": was_cancelled,
        **({"timedOut": True} if cancelled else {}),
    })


def _send_chunked(jid, tag, data: bytes):
    text = data.decode("utf-8", errors="replace")
    # chunk conservatively so one frame never nears Chrome's 1 MB host→ext cap
    while text:
        part = text[: MAX_CHUNK // 4]
        text = text[MAX_CHUNK // 4:]
        send({"id": jid, "type": tag, "data": part})


def cancel(jid):
    jid = str(jid)
    _cancelled.add(jid)
    with _procs_lock:
        proc = _processes.get(jid)
    if proc:
        _kill_tree(proc)


def main():
    if os.environ.get("NOVA_HOST_DEBUG"):
        log("host starting, pid", os.getpid())
    while True:
        msg = recv()
        if msg is None:
            break
        mtype = msg.get("type")
        if mtype == "ping":
            send({
                "type": "pong", "version": VERSION,
                "os": platform.system().lower(),
                "shell": os.environ.get("SHELL") or ("cmd.exe" if os.name == "nt" else "/bin/sh"),
                "python": platform.python_version(),
            })
        elif mtype == "exec":
            threading.Thread(target=run_exec, args=(msg,), daemon=True).start()
        elif mtype == "cancel":
            cancel(msg.get("id"))
        # unknown messages ignored


def selftest():
    """Kiểm tra nhanh host: encode/decode đúng native messaging frame + thông tin môi trường.

    In ra stdout một dòng NOVA_HOST_SELFTEST_OK/FAIL + JSON — trình cài đặt
    (install.sh/install.ps1) và người dùng có thể chạy tay để chẩn đoán:
        python3 ~/.nova-agent/nova_host.py --selftest
    """
    detail = {
        "version": VERSION,
        "os": platform.system().lower(),
        "python": platform.python_version(),
    }
    ok = True
    try:
        sample = {"type": "ping", "payload": "tự-kiểm-tra"}
        data = json.dumps(sample, ensure_ascii=False).encode("utf-8")
        frame = struct.pack("<I", len(data)) + data
        (n,) = struct.unpack("<I", frame[:4])
        if n != len(data) or json.loads(frame[4:].decode("utf-8")) != sample:
            raise ValueError("frame round-trip mismatch")
        detail["frame"] = "ok"
    except Exception as e:  # pragma: no cover
        detail["frame"] = f"fail: {e}"
        ok = False
    print(("NOVA_HOST_SELFTEST_OK " if ok else "NOVA_HOST_SELFTEST_FAIL ")
          + json.dumps(detail, ensure_ascii=False), flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    main()
