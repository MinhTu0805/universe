#!/usr/bin/env node
/**
 * Nova Agent Browser — validation suite (no external deps).
 * Checks manifest, tool registry integrity, JS syntax of every file,
 * core source invariants (no eval, no remote code, CSP sanity), and runs
 * real unit tests on the LLM serializers and history sanitizer by
 * importing the actual source modules.
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
import { execFileSync } from 'node:child_process';

const ROOT = path.dirname(path.dirname(url.fileURLToPath(import.meta.url)));
const imp = f => import(url.pathToFileURL(path.join(ROOT, f)).href);
let failures = 0;
const ok = m => console.log('  ✓ ' + m);
const bad = m => { console.error('  ✗ ' + m); failures++; };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const f = path.join(dir, e.name);
    if (e.isDirectory()) walk(f, out); else out.push(f);
  }
  return out;
}

console.log('\n[1] manifest.json');
const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
m.manifest_version === 3 ? ok('MV3') : bad('not MV3');
const perms = m.permissions || [];
for (const p of ['sidePanel', 'tabs', 'scripting', 'storage', 'downloads', 'contextMenus', 'alarms', 'debugger'])
  perms.includes(p) ? ok(`permission: ${p}`) : bad(`missing permission: ${p}`);
if (!(m.host_permissions || []).includes('<all_urls>')) bad('host_permissions <all_urls> missing (required for a browser agent)');
else ok('host_permissions <all_urls> (justified in README)');
if (m.content_security_policy?.extension_pages?.includes('unsafe-eval')) bad('CSP allows unsafe-eval');
else ok('CSP: no unsafe-eval');

console.log('\n[2] JS syntax (node --check)');
const jsFiles = [...walk(path.join(ROOT, 'background')), ...walk(path.join(ROOT, 'content')), ...walk(path.join(ROOT, 'sidepanel')), ...walk(path.join(ROOT, 'scripts'))]
  .filter(f => f.endsWith('.js') && !f.includes('vendor'));
for (const f of jsFiles) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); ok(path.relative(ROOT, f)); }
  catch (e) { bad(path.relative(ROOT, f) + ' — ' + String(e.stderr).split('\n')[0]); }
}

console.log('\n[3] Source invariants');
// invariants apply to RUNTIME code only — not to this script (its own check
// strings would self-trigger) nor build tooling
const runtimeFiles = jsFiles.filter(f => !f.includes(path.sep + 'scripts' + path.sep));
const allSrc = runtimeFiles.map(f => fs.readFileSync(f, 'utf8')).join('\n');
/\beval\s*\(/.test(allSrc) ? bad('eval() usage found') : ok('no eval()');
/new\s+Function\s*\(/.test(allSrc) ? bad('new Function() found') : ok('no new Function()');
/https:\/\/cdn\.|unpkg\.com|jsdelivr/.test(allSrc) ? bad('remote code URL in runtime code') : ok('no remote code URLs in runtime code');
// strip comments so documentation of a fixed bug doesn't self-trigger
const codeOnly = allSrc.replace(/\/\*[\s\S]*?\*\//g, '').split('\n').filter(l => !l.trim().startsWith('//')).join('\n');
/slice\(0,\s*-0\)/.test(codeOnly) ? bad('slice(0, -0) bug pattern found (returns empty array)') : ok('no slice(0, -0) bug pattern');
const provSrc = fs.readFileSync(path.join(ROOT, 'background', 'providers.js'), 'utf8');
/\bsafeJson\b/.test(provSrc) ? bad('safeJson() silent-recovery helper still present in providers.js') : ok('no safeJson silent {} recovery in providers.js');

console.log('\n[4] Tool registry coherence (static scan)');
const toolsFile = fs.readFileSync(path.join(ROOT, 'background', 'tools-browser.js'), 'utf8')
  + fs.readFileSync(path.join(ROOT, 'background', 'tools-system.js'), 'utf8')
  + fs.readFileSync(path.join(ROOT, 'background', 'tools-cdp.js'), 'utf8');
const toolNames = [...toolsFile.matchAll(/(?:registerTool\(\{\s*name:\s*|\bT\(|canvasTool\()'([a-z_0-9]+)'/g)].map(x => x[1]);
const dup = toolNames.filter((n, i) => toolNames.indexOf(n) !== i);
toolNames.length >= 70 ? ok(`${toolNames.length} tools registered`) : bad(`only ${toolNames.length} tools (<70)`);
dup.length ? bad('duplicate tools: ' + dup.join(',')) : ok('no duplicate tool names');
const required = ['browser_click', 'browser_type', 'browser_screenshot', 'browser_navigate', 'browser_scroll', 'terminal_execute', 'browser_get_accessibility_tree', 'canvas_list', 'task_complete',
  'browser_debug_attach', 'browser_debug_detach', 'browser_debug_status', 'browser_debug_evaluate', 'browser_debug_click', 'browser_debug_type', 'browser_debug_key', 'browser_debug_screenshot', 'browser_network_log'];
for (const r of required) toolNames.includes(r) ? ok(`tool: ${r}`) : bad(`missing tool: ${r}`);
// service worker must actually import the CDP tool module, else tools never register
const swSrc = fs.readFileSync(path.join(ROOT, 'background', 'service-worker.js'), 'utf8');
/import\s+['"]\.\/tools-cdp\.js['"]/.test(swSrc) ? ok('service-worker imports tools-cdp.js') : bad('service-worker.js does not import ./tools-cdp.js — CDP tools would never register');

console.log('\n[5] Icons');
for (const s of [16, 32, 48, 128])
  fs.existsSync(path.join(ROOT, 'icons', `icon-${s}.png`)) ? ok(`icon-${s}.png`) : bad(`icon-${s}.png missing`);

/* ---------- [6] real tool registry import + per-tool schema ---------- */
console.log('\n[6] Tool registry (dynamic import, per-tool schema)');
try {
  const reg = await imp('background/tool-registry.js');
  await imp('background/tools-browser.js');
  await imp('background/tools-system.js');
  await imp('background/tools-cdp.js');
  const tools = reg.listTools();
  tools.length >= 70 ? ok(`${tools.length} tools live in registry`) : bad(`registry holds only ${tools.length} tools`);
  const cdpTools = tools.filter(t => t.group === 'cdp');
  cdpTools.length === 10 ? ok('10 CDP tools in group "cdp" (incl. browser_debug_drag)') : bad(`expected 10 cdp tools, got ${cdpTools.length}`);
  for (const want of ['browser_slide', 'browser_debug_drag']) {
    tools.some(t => t.name === want) ? ok(`${want} registered`) : bad(`${want} missing from registry`);
  }
  // slide engine lives in the content script (NC.act.slide)
  const interSrc = fs.readFileSync(path.join(ROOT, 'content', 'interaction.js'), 'utf8');
  /async function slide\(/.test(interSrc) && /humanPath/.test(interSrc) && /return \{ resolve, pointOf.*slide/.test(interSrc)
    ? ok('content/interaction.js: slide() + humanized path exported')
    : bad('content/interaction.js: slide()/humanPath missing or not exported');
  const seen = new Set();
  let schemaBad = 0;
  for (const t of tools) {
    const tag = `tool ${t.name}`;
    if (seen.has(t.name)) { bad(tag + ': duplicate at runtime'); continue; }
    seen.add(t.name);
    if (!/^[a-z0-9_]{1,64}$/.test(t.name)) { bad(tag + ': name violates ^[a-z0-9_]{1,64}$'); schemaBad++; }
    if (!t.description || typeof t.description !== 'string') { bad(tag + ': missing description'); schemaBad++; }
    if (typeof t.execute !== 'function') { bad(tag + ': execute is not a function'); schemaBad++; }
    const s = t.schema;
    if (!s || s.type !== 'object') { bad(tag + ': schema.type must be "object" (OpenAI/Anthropic reject others)'); schemaBad++; }
    else {
      const props = Object.keys(s.properties || {});
      for (const r of s.required || []) if (!props.includes(r)) { bad(`${tag}: required "${r}" not in properties`); schemaBad++; }
    }
    if (!['low', 'medium', 'high'].includes(t.risk)) { bad(tag + ': invalid risk ' + t.risk); schemaBad++; }
  }
  schemaBad === 0 ? ok('every tool: valid name, description, object schema, required ⊆ properties, risk') : bad(schemaBad + ' tool schema problem(s)');
} catch (e) { bad('registry import failed: ' + e.message); }

/* ---------- [7] provider serializers (real import) ---------- */
console.log('\n[7] Provider serializers (OpenAI + Anthropic)');
try {
  const { __test } = await imp('background/providers.js');
  const { toOpenAI, toAnthropic, toOpenAITools, toAnthropicTools, parseToolArgs, isGeminiEndpoint } = __test;

  // parseToolArgs — the "no silent {}" contract
  const p1 = parseToolArgs('{"a":1}', 't');
  eq(p1.args, { a: 1 }) && !p1.argsError ? ok('parseToolArgs: valid JSON parsed') : bad('parseToolArgs valid JSON: ' + JSON.stringify(p1));
  const p2 = parseToolArgs('{broken', 'my_tool');
  p2.argsError && /my_tool/.test(p2.argsError) && !p2.args ? ok('parseToolArgs: invalid JSON → argsError diagnostic (never silent {})') : bad('parseToolArgs must surface argsError, got ' + JSON.stringify(p2));
  const p3 = parseToolArgs('', 't');
  eq(p3.args, {}) && !p3.argsError ? ok('parseToolArgs: empty string = no arguments (legitimate {})') : bad('parseToolArgs empty string: ' + JSON.stringify(p3));

  // OpenAI: assistant tool_calls + tool result pairing, arguments stringified
  const oai = toOpenAI([
    { role: 'user', content: [{ type: 'text', text: 'hi' }] },
    { role: 'assistant', content: [{ type: 'text', text: 'checking' }], toolCalls: [{ id: 'c1', name: 'browser_click', arguments: { x: 1 } }] },
    { role: 'tool', toolCallId: 'c1', content: 'done' },
  ]);
  const asst = oai.find(x => x.role === 'assistant');
  const toolMsg = oai.find(x => x.role === 'tool');
  Array.isArray(asst?.tool_calls) && asst.tool_calls[0].id === 'c1' && typeof asst.tool_calls[0].function.arguments === 'string'
    ? ok('toOpenAI: tool_calls serialized with string arguments')
    : bad('toOpenAI tool_calls: ' + JSON.stringify(asst));
  toolMsg?.tool_call_id === 'c1' && typeof toolMsg.content === 'string' && toolMsg.content.length > 0
    ? ok('toOpenAI: tool result carries tool_call_id and non-empty content')
    : bad('toOpenAI tool message: ' + JSON.stringify(toolMsg));

  // Gemini 3.x thought signatures: the OAI-compat endpoint 400s any replayed
  // tool_call without extra_content.google.thought_signature. Captured
  // signatures must round-trip verbatim; history that lost them gets the
  // documented skip-validator dummy; other providers must never see the field.
  const tcMsg = extra => ({ role: 'assistant', content: [], toolCalls: [{ id: 'fc1', name: 'browser_click', arguments: {}, ...(extra ? { extraContent: extra } : null) }] });
  const gem1 = toOpenAI([tcMsg(null)], { gemini: true });
  gem1[0].tool_calls[0].extra_content?.google?.thought_signature === 'skip_thought_signature_validator'
    ? ok('toOpenAI(gemini): missing signature → skip-validator injected (fixes Gemini 3.x 400)')
    : bad('toOpenAI gemini dummy injection: ' + JSON.stringify(gem1));
  const SIG = { google: { thought_signature: 'SIG_ABC' } };
  const gem2 = toOpenAI([tcMsg(SIG)], { gemini: true });
  gem2[0].tool_calls[0].extra_content === SIG
    ? ok('toOpenAI(gemini): captured thought_signature replayed verbatim')
    : bad('toOpenAI gemini replay: ' + JSON.stringify(gem2));
  const gem3 = toOpenAI([tcMsg(null)]);
  !('extra_content' in gem3[0].tool_calls[0])
    ? ok('toOpenAI(non-gemini): no extra_content leaked to other providers')
    : bad('toOpenAI leaked extra_content: ' + JSON.stringify(gem3));
  isGeminiEndpoint('gemini', '') && isGeminiEndpoint('custom', 'https://generativelanguage.googleapis.com/v1beta/openai') && !isGeminiEndpoint('openai', 'https://api.openai.com/v1')
    ? ok('isGeminiEndpoint: provider id OR generativelanguage base URL')
    : bad('isGeminiEndpoint wrong');

  // Anthropic: strict alternation — consecutive user messages must merge
  const ant = toAnthropic([
    { role: 'user', content: [{ type: 'text', text: 'a' }] },
    { role: 'user', content: [{ type: 'text', text: 'b' }] },
  ]);
  ant.messages.length === 1 && ant.messages[0].role === 'user'
    ? ok('toAnthropic: consecutive same-role messages merged (alternation kept)')
    : bad('toAnthropic alternation: ' + JSON.stringify(ant.messages));

  // Anthropic: first message must be user — leading assistant gets a user shim
  const ant2 = toAnthropic([{ role: 'assistant', content: [{ type: 'text', text: 'hello' }] }]);
  ant2.messages[0]?.role === 'user'
    ? ok('toAnthropic: leading non-user message preceded by user shim')
    : bad('toAnthropic first message: ' + JSON.stringify(ant2.messages));

  // Anthropic: no empty text blocks (a classic HTTP 400 cause)
  const ant3 = toAnthropic([
    { role: 'user', content: [{ type: 'text', text: 'do it' }] },
    { role: 'assistant', content: [], toolCalls: [{ id: 'c9', name: 'browser_scroll', arguments: {} }] },
    { role: 'tool', toolCallId: 'c9', content: '' },
  ]);
  const a3 = ant3.messages.find(x => x.role === 'assistant');
  const hasEmptyText = JSON.stringify(ant3).includes('"text":""');
  const toolUse = a3?.content?.find(b => b.type === 'tool_use');
  const toolRes = ant3.messages.flatMap(x => x.content || []).find(b => b.type === 'tool_result');
  !hasEmptyText ? ok('toAnthropic: no empty text blocks') : bad('toAnthropic emitted empty text block: ' + JSON.stringify(ant3));
  toolUse?.id === 'c9' && toolRes?.tool_use_id === 'c9'
    ? ok('toAnthropic: tool_use/tool_result pairing preserved')
    : bad('toAnthropic tool pairing: ' + JSON.stringify(ant3.messages));

  // Anthropic: system extracted out of messages
  const ant4 = toAnthropic([{ role: 'system', content: [{ type: 'text', text: 'SYS' }] }, { role: 'user', content: [{ type: 'text', text: 'x' }] }]);
  ant4.system === 'SYS' && !ant4.messages.some(x => x.role === 'system')
    ? ok('toAnthropic: system prompt moved to top-level field')
    : bad('toAnthropic system handling: ' + JSON.stringify(ant4).slice(0, 200));

  // tool schema export shapes
  const toolDef = [{ name: 'browser_click', description: 'click', schema: { type: 'object', properties: { x: { type: 'number' } }, required: ['x'] } }];
  const ot = toOpenAITools(toolDef)[0];
  ot?.type === 'function' && ot.function?.name === 'browser_click' && ot.function?.parameters?.type === 'object'
    ? ok('toOpenAITools: function + parameters shape')
    : bad('toOpenAITools: ' + JSON.stringify(ot));
  const at = toAnthropicTools(toolDef)[0];
  at?.name === 'browser_click' && at?.input_schema?.type === 'object'
    ? ok('toAnthropicTools: input_schema shape')
    : bad('toAnthropicTools: ' + JSON.stringify(at));
} catch (e) { bad('serializer tests failed: ' + e.message); }

/* ---------- [8] history sanitizer (real import) ---------- */
console.log('\n[8] sanitizeHistory (agent-runtime)');
try {
  const { sanitizeHistory } = await imp('background/agent-runtime.js');
  const U = t => ({ role: 'user', content: [{ type: 'text', text: t }] });
  const A = (t, tc) => { const x = { role: 'assistant', content: t ? [{ type: 'text', text: t }] : [] }; if (tc) x.toolCalls = tc; return x; };
  const TR = (id, c) => ({ role: 'tool', toolCallId: id, content: c });

  // orphan tool result (no matching tool_call) must be dropped
  const s1 = sanitizeHistory([U('q'), TR('ghost', 'x'), A('a')]);
  !s1.some(x => x.role === 'tool') && s1.length === 2
    ? ok('orphan tool result dropped')
    : bad('orphan tool result survived: ' + JSON.stringify(s1));

  // dangling tool_calls interrupted by a user message → synthetic TOOL_INTERRUPTED results
  const s2 = sanitizeHistory([U('q'), A('', [{ id: 'c1', name: 'browser_click', arguments: {} }]), U('stop')]);
  const injected = s2.find(x => x.role === 'tool' && x.toolCallId === 'c1');
  injected && /TOOL_INTERRUPTED/.test(JSON.stringify(injected.content)) && s2[s2.length - 1].role === 'user'
    ? ok('dangling tool_calls closed with TOOL_INTERRUPTED (sequence stays valid)')
    : bad('dangling tool_calls not repaired: ' + JSON.stringify(s2));

  // valid tool round-trip must pass through untouched
  const valid = [U('q'), A('', [{ id: 'c1', name: 'browser_click', arguments: {} }]), TR('c1', 'ok'), A('done')];
  eq(sanitizeHistory(valid), valid)
    ? ok('valid tool sequence untouched')
    : bad('valid sequence mutated: ' + JSON.stringify(sanitizeHistory(valid)));

  // consecutive plain assistant messages merged
  const s4 = sanitizeHistory([U('q'), A('one'), A('two')]);
  s4.filter(x => x.role === 'assistant').length === 1 && /one/.test(s4[1].content[0].text) && /two/.test(s4[1].content[0].text)
    ? ok('consecutive assistant turns merged')
    : bad('assistant merge: ' + JSON.stringify(s4));

  // empty assistant message (no text, no toolCalls) dropped
  const s5 = sanitizeHistory([U('q'), A(''), A('real')]);
  s5.length === 2 && s5[1].content[0].text === 'real'
    ? ok('empty assistant message dropped')
    : bad('empty assistant survived: ' + JSON.stringify(s5));
} catch (e) { bad('sanitizeHistory tests failed: ' + e.message); }

/* ---------- [9] reasoning-effort request shaping (real import) ---------- */
console.log('\n[9] Reasoning effort → request bodies');
try {
  const { __test, modelCaps } = await imp('background/providers.js');
  const { buildOpenAIBody, buildAnthropicBody, toAnthropic, THINKING_BUDGET } = __test;
  const baseReq = (over = {}) => ({
    model: 'gpt-4o-mini', messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }],
    stream: false, temperature: 0.4, maxTokens: 4096, ...over,
  });

  // strict-spec reasoning models: max_completion_tokens, NO max_tokens/temperature
  const r1 = buildOpenAIBody('openai', baseReq({ model: 'o3-mini', reasoning: 'high' }));
  r1.max_completion_tokens === 4096 && r1.max_tokens === undefined && r1.temperature === undefined
    ? ok('strict-spec (o3-mini): max_completion_tokens, no max_tokens/temperature (400 fix)')
    : bad('strict-spec body wrong: ' + JSON.stringify(r1));
  r1.reasoning_effort === 'high'
    ? ok('reasoning_effort passed for reasoning-capable model on allowlisted provider')
    : bad('reasoning_effort missing for o3-mini/high: ' + JSON.stringify(r1));

  // non-reasoning model must NOT receive reasoning_effort even if user asked
  const r2 = buildOpenAIBody('openai', baseReq({ model: 'gpt-4o-mini', reasoning: 'high' }));
  r2.reasoning_effort === undefined && r2.max_tokens === 4096 && r2.temperature === 0.4
    ? ok('non-reasoning model: no reasoning_effort, normal max_tokens/temperature')
    : bad('gpt-4o-mini body wrong: ' + JSON.stringify(r2));

  // reasoning model on a NON-allowlisted provider must NOT receive the field
  const r3 = buildOpenAIBody('custom', baseReq({ model: 'deepseek-r1-distill', reasoning: 'medium' }));
  r3.reasoning_effort === undefined && r3.temperature === undefined // reasoning model → temperature dropped
    ? ok('reasoning model on custom endpoint: field withheld, temperature dropped (no 400)')
    : bad('custom reasoning body wrong: ' + JSON.stringify(r3));

  // 'off' sends nothing
  const r4 = buildOpenAIBody('openai', baseReq({ model: 'o3-mini', reasoning: 'off' }));
  r4.reasoning_effort === undefined ? ok('effort=off → no reasoning_effort field') : bad('effort=off leaked: ' + JSON.stringify(r4));

  // Anthropic: thinking ONLY on tool-free turns, budget bumps max_tokens
  const mapped = toAnthropic([{ role: 'user', content: [{ type: 'text', text: 'hi' }] }]);
  const a1 = buildAnthropicBody(baseReq({ model: 'claude-sonnet-4-5', reasoning: 'medium', maxTokens: 4096 }), mapped);
  a1.thinking?.type === 'enabled' && a1.thinking.budget_tokens === THINKING_BUDGET.medium && a1.max_tokens > a1.thinking.budget_tokens && a1.temperature === undefined
    ? ok('anthropic: thinking enabled (budget 5000), max_tokens > budget, no temperature')
    : bad('anthropic thinking body wrong: ' + JSON.stringify(a1));
  const a2 = buildAnthropicBody(baseReq({ model: 'claude-sonnet-4-5', reasoning: 'high', tools: [{ name: 'browser_click', description: 'x', schema: { type: 'object', properties: {} } }] }), mapped);
  a2.thinking === undefined && a2.temperature === 0.4 && Array.isArray(a2.tools)
    ? ok('anthropic: thinking suppressed on tool turns (thinking-block replay conflict avoided)')
    : bad('anthropic tool-turn body wrong: ' + JSON.stringify(a2));

  // capability heuristics sanity
  const caps1 = modelCaps('openai', 'o3-mini');
  caps1.reasoning && caps1.strictSpec ? ok('modelCaps: o3-mini → reasoning + strictSpec') : bad('modelCaps o3-mini: ' + JSON.stringify(caps1));
  const caps2 = modelCaps('openai', 'gpt-4o-mini');
  !caps2.reasoning && !caps2.strictSpec && caps2.vision ? ok('modelCaps: gpt-4o-mini → plain vision model') : bad('modelCaps gpt-4o-mini: ' + JSON.stringify(caps2));
} catch (e) { bad('reasoning shaping tests failed: ' + e.message); }

/* ---------- [10] 2-mode merge + CDP module Node-safety ---------- */
console.log('\n[10] Mode merge (ask|agent) + cdp.js import safety');
try {
  const store = await imp('background/storage.js');
  eq(store.MODES, ['ask', 'agent']) ? ok('MODES = [ask, agent]') : bad('MODES wrong: ' + JSON.stringify(store.MODES));
  const map = { chat: 'ask', computer: 'agent', research: 'agent', ask: 'ask', agent: 'agent', bogus: 'agent', undefined: 'agent' };
  let migOk = true;
  for (const [k, want] of Object.entries(map)) {
    const got = store.normalizeMode(k === 'undefined' ? undefined : k);
    if (got !== want) { migOk = false; bad(`normalizeMode(${k}) = ${got}, want ${want}`); }
  }
  if (migOk) ok('normalizeMode: legacy chat→ask, computer/research→agent, fallback agent');
  store.DEFAULT_SETTINGS.settings.reasoningEffort === 'off' ? ok('settings default: reasoningEffort=off') : bad('reasoningEffort default missing');
  store.DEFAULT_SETTINGS.settings.debuggerEnabled === false ? ok('settings default: debuggerEnabled=false') : bad('debuggerEnabled default missing');
  store.DEFAULT_SETTINGS.settings.toolPerms?.cdp === 'ask' ? ok('toolPerms.cdp default = ask') : bad('toolPerms.cdp default missing');

  // system prompt covers exactly the two modes
  const sp = await imp('background/system-prompt.js');
  const askP = sp.systemPrompt('ask', {});
  const agentP = sp.systemPrompt('agent', {});
  /READ-ONLY|chỉ-đọc|CHỈ ĐỌC/i.test(askP) ? ok('ask prompt: read-only contract present') : bad('ask prompt lacks read-only contract');
  /COMPUTER USE/.test(agentP) && /DEBUG|CDP/.test(agentP) && /RESEARCH/.test(agentP)
    ? ok('agent prompt: absorbs computer-use + CDP debug + research')
    : bad('agent prompt missing absorbed-mode sections');

  // cdp.js must import cleanly in Node (validate imports it transitively) —
  // a top-level chrome.* access would throw here
  const cdp = await imp('background/cdp.js');
  typeof cdp.attach === 'function' && typeof cdp.detachAll === 'function' && Array.isArray(cdp.attachedIds())
    ? ok('cdp.js: Node-safe import (hasChrome guard), API surface intact')
    : bad('cdp.js import unsafe or API missing');
} catch (e) { bad('mode-merge / cdp tests failed: ' + e.message); }

console.log(failures ? `\nFAILED: ${failures} problem(s)` : '\nALL CHECKS PASSED');
process.exit(failures ? 1 : 0);
