/* Nova Agent Browser — side panel app.
 * Talks to the service worker over a long-lived Port ("nova-sidepanel").
 * Falls back to NovaMock (mock.js) when opened outside the extension. */
'use strict';
(() => {

/* ==================== tiny DOM utils ==================== */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html; // only ever fed static strings + nicon() svgs
  return e;
}
function fmtN(n) {
  n = Math.round(n || 0);
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(n);
}
function fmtDur(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
function fmtTime(ts) {
  const d = new Date(ts || Date.now());
  const diff = Date.now() - d.getTime();
  if (diff < 60e3) return 'vừa xong';
  if (diff < 3600e3) return Math.floor(diff / 60e3) + ' phút';
  if (diff < 86400e3) return Math.floor(diff / 3600e3) + ' giờ';
  return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

/* base64 → UTF-8 safe text/bytes (plain atob() mangles Vietnamese) */
function b64Bytes(b64) {
  const bin = atob(b64 || '');
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
function b64Text(b64) { try { return new TextDecoder().decode(b64Bytes(b64)); } catch (e) { return atob(b64 || ''); } }

function toast(text, kind = 'ok', icon) {
  const t = el('div', 'toast ' + kind, (icon || (kind === 'err' ? nicon('alert') : nicon('check'))) + '<span></span>');
  t.querySelector('span').textContent = text;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 350); }, 3200);
}

/* ==================== bridge to service worker ==================== */
function realBridge() {
  let port = null;
  let seq = 0;
  const pending = new Map();
  const handlers = new Set();

  function connect() {
    port = chrome.runtime.connect({ name: 'nova-sidepanel' });
    port.onMessage.addListener(m => {
      if (m?.kind === 'res') {
        const p = pending.get(m.id);
        if (p) {
          pending.delete(m.id);
          if (m.ok) p.res(m.data);
          else p.rej(Object.assign(new Error(m.error?.message || 'Lỗi không xác định'), { code: m.error?.code }));
        }
      } else if (m?.kind === 'event') {
        for (const f of handlers) { try { f(m.event, m.data); } catch (e) { console.error(e); } }
      }
    });
    port.onDisconnect.addListener(() => {
      port = null;
      for (const [, p] of pending) p.rej(new Error('Mất kết nối với background — đang kết nối lại…'));
      pending.clear();
      setTimeout(() => {
        try { connect(); for (const f of reconnectHandlers) f(); } catch (e) { }
      }, 400);
    });
  }
  const reconnectHandlers = new Set();
  connect();
  return {
    cmd: (cmd, data) => new Promise((res, rej) => {
      if (!port) { try { connect(); } catch (e) { return rej(e); } }
      const id = ++seq;
      pending.set(id, { res, rej });
      try { port.postMessage({ kind: 'cmd', id, cmd, data }); }
      catch (e) { pending.delete(id); rej(e); }
    }),
    onEvent: fn => { handlers.add(fn); return () => handlers.delete(fn); },
    onReconnect: fn => reconnectHandlers.add(fn),
    isMock: false,
  };
}

const bridge = (typeof chrome !== 'undefined' && chrome.runtime?.id)
  ? realBridge()
  : window.NovaMock.bridge();

/* ==================== app state ==================== */
const S = {
  settings: null,
  providers: null,       // masked
  presets: null,
  conversations: [],
  activeConvId: null,
  feed: new Map(),       // item id -> {item, el}
  mode: 'agent',
  selection: null,
  agentState: 'idle',
  agentStep: 0,
  agentStartedAt: null,
  convUsage: { input: 0, output: 0, calls: 0 },
  prefs: {},
  usage: { input: 0, output: 0, calls: 0 },
  tab: null,
  drawerOpen: false,
  attachments: [],   // {id, name, mime, size, kind:'text'|'image', text?, dataUrl?}
  termActive: false, // a terminal_* tool is streaming right now (capability, not a mode)
  debugTabs: new Set(), // tabIds đang attach chrome.debugger (CDP)
};

const MODES = {
  ask:   { name: 'Ask',   icon: 'question', desc: 'Hỏi đáp về trang hiện tại — chỉ đọc, không thao tác' },
  agent: { name: 'Agent', icon: 'zap',      desc: 'Tự động hoá toàn phần: nhìn → hiểu → click/gõ → kiểm chứng (gồm Computer Use, Research, debug CDP)' },
};
/* mức suy luận gửi kèm request (reasoning_effort / thinking budget) */
const REASONING_LEVELS = {
  off:    { name: 'Tắt',  desc: 'Không bật suy luận mở rộng — nhanh nhất, rẻ nhất' },
  low:    { name: 'Thấp', desc: 'Suy luận nhẹ — phản hồi vẫn nhanh' },
  medium: { name: 'Vừa',  desc: 'Cân bằng tốc độ và chất lượng suy luận' },
  high:   { name: 'Cao',  desc: 'Suy luận sâu nhất — chậm hơn và tốn token hơn' },
};
const RUNNING = new Set(['thinking', 'planning', 'observing', 'acting', 'waiting', 'verifying', 'recovering', 'awaiting_approval', 'awaiting_user', 'paused']);
const STATE_TEXT = {
  idle: 'Sẵn sàng', thinking: 'Đang suy nghĩ', planning: 'Đang lập kế hoạch', observing: 'Đang quan sát',
  acting: 'Đang thao tác', waiting: 'Đang chờ', verifying: 'Đang kiểm chứng', recovering: 'Đang khôi phục',
  awaiting_approval: 'Chờ phê duyệt', awaiting_user: 'Chờ bạn trả lời', paused: 'Đã tạm dừng',
  completed: 'Hoàn thành', failed: 'Có lỗi xảy ra', stopped: 'Đã dừng',
};
/* agent state → orb state (thinking-orbs vocabulary) */
const ORB_STATE = {
  thinking: 'working', planning: 'weaving', observing: 'searching', acting: 'shaping',
  waiting: 'listening', verifying: 'solving', recovering: 'connecting',
  awaiting_approval: 'breathing', awaiting_user: 'listening', paused: 'breathing',
};

/* ---- orb instances living in the status pill / agent bar ---- */
const orbs = { pill: null, bar: null };
const feedOrbs = new Set(); // orbs inside feed bubbles — destroyed when content arrives / conv closed
function orbDark() { return document.documentElement.dataset.theme !== 'light'; }
function ensureOrb(key, hostSel) {
  const host = $(hostSel);
  if (!host) return null;
  if (!orbs[key]) {
    orbs[key] = NovaOrb.create({ state: 'working', size: key === 'pill' ? 16 : 20, dark: orbDark() });
    orbs[key].el.classList.add('orb-in-' + key);
    host.prepend(orbs[key].el);
  }
  return orbs[key];
}
function syncOrbs(state) {
  const running = RUNNING.has(state);
  const paused = state === 'paused' || !running;
  // terminal streaming alongside thinking → connecting state wins
  const orbState = S.termActive && running && state !== 'paused' ? 'connecting' : (ORB_STATE[state] || 'working');
  for (const k of ['pill', 'bar']) {
    const o = orbs[k];
    if (!o) continue;
    o.el.style.display = running ? '' : 'none';
    if (running) { o.setState(orbState); o.setPaused(paused); }
  }
}

/* ==================== status / agent bar ==================== */
let elapsedTimer = null;
function setAgentState(state, extra = {}) {
  S.agentState = state;
  if (extra.step) S.agentStep = extra.step;
  const pill = $('#status-pill');
  const txt = STATE_TEXT[state] || state;
  const pillTxt = pill.querySelector('span:not(.nova-orb)');
  pillTxt.textContent = txt;
  pill.className = 'pill stat ' + (
    state === 'awaiting_approval' || state === 'awaiting_user' || state === 'paused' ? 'ask' :
    state === 'failed' ? 'err' :
    state === 'completed' ? 'done' :
    RUNNING.has(state) ? 'run' : '');
  // light sweep across the status text while running
  pillTxt.classList.toggle('shimmer', RUNNING.has(state) && state !== 'paused');

  const bar = $('#agent-bar');
  if (RUNNING.has(state)) {
    bar.hidden = false;
    bar.classList.toggle('paused', state === 'paused');
    const abText = $('#ab-text');
    abText.textContent = txt + '…';
    abText.classList.toggle('shimmer', state !== 'paused');
    $('#btn-pause').innerHTML = state === 'paused' ? nicon('play') : nicon('pause');
    $('#btn-pause').title = state === 'paused' ? 'Tiếp tục' : 'Tạm dừng';
    if (state === 'acting' || state === 'thinking') S.agentStartedAt ||= Date.now();
    clearInterval(elapsedTimer);
    elapsedTimer = setInterval(updateAgentMeta, 1000);
    updateAgentMeta();
  } else {
    bar.hidden = true;
    S.termActive = false;
    clearInterval(elapsedTimer);
  }

  // thinking orbs in the status pill + agent bar
  if (RUNNING.has(state)) {
    ensureOrb('pill', '#status-pill');
    ensureOrb('bar', '#agent-bar');
  }
  syncOrbs(state);
  const pillDot = pill.querySelector('i');
  const barDot = bar.querySelector('.ab-dot');
  if (pillDot) pillDot.style.display = RUNNING.has(state) ? 'none' : '';
  if (barDot) barDot.style.display = RUNNING.has(state) ? 'none' : '';
}
function updateAgentMeta() {
  const bits = [];
  if (S.agentStep) bits.push(`bước ${S.agentStep}`);
  if (S.agentStartedAt) bits.push(fmtDur(Date.now() - S.agentStartedAt));
  $('#ab-meta').textContent = bits.join(' · ');
}

/* ==================== context bar ==================== */
function renderTab(tab) {
  if (!tab) return;
  S.tab = tab;
  $('#ctx-title').textContent = tab.title || '(không tiêu đề)';
  let host = '';
  try { host = new URL(tab.url).hostname; } catch (e) { }
  $('#ctx-url').textContent = host || tab.url || '';
  const fav = $('#ctx-favicon');
  // MV3: never hotlink remote favicons (CSP) — route through the favicon API
  let favUrl = null;
  if (!bridge.isMock && typeof chrome !== 'undefined' && chrome.runtime?.getURL && /^https?:/.test(tab.url || '')) {
    favUrl = chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(tab.url)}&size=32`);
  }
  if (favUrl) {
    fav.innerHTML = '';
    const img = new Image();
    img.src = favUrl;
    img.onerror = () => { fav.innerHTML = nicon('globe'); };
    fav.appendChild(img);
  } else fav.innerHTML = nicon('globe');
  renderDebugChip();
}

function renderCtxToggles() {
  const inc = S.settings?.includeContext || {};
  for (const b of $$('#ctx-toggles .ctx-t')) {
    b.classList.toggle('on', !!inc[b.dataset.k]);
  }
}

function renderSelection() {
  const chip = $('#sel-chip');
  const inc = S.settings?.includeContext?.selection;
  if (S.selection?.text && inc) {
    chip.hidden = false;
    chip.querySelector('.sel-txt').textContent = '“' + S.selection.text.slice(0, 120) + (S.selection.text.length > 120 ? '…' : '') + '”';
  } else chip.hidden = true;
}

/* chip "đang debug (CDP)" trên context bar — hiện khi tab hiện tại bị attach */
function renderDebugChip() {
  const chip = $('#ctx-debug');
  if (!chip) return;
  const on = S.tab?.id != null && S.debugTabs.has(S.tab.id);
  chip.hidden = !on;
  if (on) chip.innerHTML = `${nicon('bug')}<span>DEBUG</span>${nicon('x')}`;
}

/* ==================== boot ==================== */
async function boot() {
  wireStaticUI();
  const st = await bridge.cmd('get_state');
  S.settings = st.settings;
  S.providers = st.providers;
  S.presets = st.providerPresets;
  S.conversations = st.conversations;
  S.usage = st.usage || S.usage;
  S.prefs = st.prefs || {};
  S.debugTabs = new Set(st.debugTabs || []);
  if (MODES[S.settings.defaultMode]) S.mode = S.settings.defaultMode;
  applyTheme();
  applyFontSize();
  renderCtxToggles();
  syncReasonUI();
  renderDebugChip();
  buildStarters(); // footer's "API key" status needs the real provider state

  // active conversation
  let convId = st.activeConvId;
  if (!convId || !S.conversations.find(c => c.id === convId)) {
    if (S.conversations[0]) convId = S.conversations[0].id;
    else {
      const c = await bridge.cmd('new_conversation', { mode: S.mode });
      convId = c.conversation.id;
    }
  }
  await openConversation(convId, false);

  // pending context-menu action
  if (st.pendingAction) handlePendingAction(st.pendingAction);

  // onboarding on first run
  if (!S.prefs.onboarded) $('#onboard').classList.add('show');

  // tab info for context bar
  if (!bridge.isMock) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab) renderTab(tab);
    } catch (e) { }
  } else renderTab({ title: 'Mock Page — demo', url: 'https://example.com', favIconUrl: '' });

  if (bridge.isMock) {
    const b = el('span', 'tag', 'MOCK');
    b.style.cssText = 'background:var(--ac-wash);color:var(--ac)';
    $('#status-pill').after(b);
    const q = new URLSearchParams(location.search);
    if (q.has('demo')) { $('#input').value = 'Phân tích trang này và lưu báo cáo markdown'; sendMessage(); }
    if (q.get('settingsTab')) openSettings(q.get('settingsTab'));
    if (q.has('drawer')) openDrawer();
    if (q.has('onboard')) $('#onboard').classList.add('show');
  }
  updateCtxMeter();
}

function handlePendingAction(a) {
  if (a.mode && MODES[a.mode]) setMode(a.mode);
  if (a.selection?.text) { S.selection = a.selection; renderSelection(); }
  if (a.text) { $('#input').value = a.text; autogrow(); }
  if (a.autoRun && a.text) sendMessage();
}

/* reconnect: refetch everything */
function onReconnect() {
  boot().catch(() => { });
}

document.addEventListener('DOMContentLoaded', () => {
  bridge.onEvent(onEvent);
  bridge.onReconnect?.(onReconnect);
  boot().catch(e => toast(e.message, 'err'));
});

/* ==================== conversations ==================== */
async function openConversation(convId, persist = true) {
  S.activeConvId = convId;
  if (persist) bridge.cmd('set_active_conv', { convId }).catch(() => { });
  const { conversation: c } = await bridge.cmd('get_conversation', { convId });
  S.feed.clear();
  for (const o of [...feedOrbs]) o.destroy(); // stop placeholder animations of the previous conv
  $('#feed').innerHTML = '';
  if (c) {
    // storage.migrate() đã chuẩn hoá mode cũ (chat/computer/research) — fallback
    // 'agent' chỉ còn là phòng hộ cho dữ liệu mock/lạ
    S.mode = MODES[c.mode] ? c.mode : 'agent';
    S.convUsage = c.usage || { input: 0, output: 0, calls: 0 };
    for (const item of c.feed || []) upsertFeedItem(item, false);
    setAgentState(c.agent?.state || 'idle', { step: c.agent?.steps });
    if (RUNNING.has(c.agent?.state)) S.agentStartedAt = c.agent.startedAt || Date.now();
  }
  S.agentStep = c?.agent?.steps || 0;
  setMode(S.mode, true);
  updateCtxMeter();
  updateEmpty();
  scrollBottom(true);
  renderConvList();
}

function updateEmpty() {
  const has = S.feed.size > 0;
  $('#empty').classList.toggle('on', !has);
  $('#feed').style.display = has ? '' : 'none';
}

/* ==================== feed rendering ==================== */
function toolIcon(name) {
  if (name.startsWith('browser_debug') || name.startsWith('browser_network')) return 'bug';
  if (name.startsWith('browser_navigate') || name.startsWith('browser_open') || name.startsWith('browser_go')) return 'globe';
  if (name.includes('screenshot') || name.includes('compare')) return 'camera';
  if (name.includes('click') || name.includes('hover') || name.includes('drag') || name.includes('scroll') || name.includes('type') || name.includes('key') || name.includes('select') || name.includes('check') || name.includes('submit')) return 'mouse';
  if (name.startsWith('canvas')) return 'canvas';
  if (name.startsWith('terminal')) return 'terminal';
  if (name.includes('tab')) return 'layers';
  if (name.includes('download')) return 'download';
  if (name.includes('upload')) return 'download';
  if (name.includes('dom') || name.includes('accessibility') || name.includes('page_info') || name.includes('find') || name.includes('visible') || name.includes('links') || name.includes('forms') || name.includes('tables') || name.includes('text')) return 'eye';
  if (name.includes('artifact')) return 'file';
  if (name.includes('search') || name.includes('fetch')) return 'search';
  if (name === 'task_complete') return 'check';
  if (name === 'ask_user') return 'question';
  return 'cpu';
}

function upsertFeedItem(item, scroll = true) {
  let rec = S.feed.get(item.id);
  if (!rec) {
    const e = renderFeedItem(item);
    if (!e) return;
    rec = { item, el: e };
    S.feed.set(item.id, rec);
    $('#feed').appendChild(e);
    updateEmpty();
  } else {
    rec.item = { ...rec.item, ...item };
    updateFeedItem(rec);
  }
  if (scroll) scrollBottom();
}

function renderFeedItem(item) {
  switch (item.t) {
    case 'user': {
      const m = el('div', 'msg user');
      const b = el('div', 'u-bubble');
      b.textContent = item.text || '';
      m.appendChild(b);
      if (item.attachments?.length) m.appendChild(attachChips(item.attachments));
      return m;
    }
    case 'ai': {
      const m = el('div', 'msg ai');
      m.innerHTML = `<div class="avatar"><img src="../icons/icon-32.png" alt=""></div>`;
      const body = el('div', 'ai-body');
      const head = el('div', 'ai-head', '<span>Nova</span>');
      const tag = el('span', 'tag mode', MODES[S.mode]?.name || 'Agent');
      head.appendChild(tag);
      const md = el('div', 'md-host');
      body.appendChild(head); body.appendChild(md);
      if (item.md) NM.renderInto(md, item.md);
      else {
        // thinking placeholder: orb + light-sweep text (replaces the old dots)
        const row = el('div', 'think-row');
        const orb = NovaOrb.create({ state: 'working', size: 20, dark: orbDark() });
        const baseDestroy = orb.destroy.bind(orb);
        orb.destroy = () => { feedOrbs.delete(orb); baseDestroy(); };
        feedOrbs.add(orb);
        row.appendChild(orb.el);
        row.appendChild(el('span', 'shimmer think-tx', 'Nova đang suy nghĩ…'));
        md.appendChild(row);
      }
      const acts = el('div', 'acts');
      const cp = el('button', '', nicon('copy'));
      cp.title = 'Sao chép';
      cp.onclick = () => { navigator.clipboard.writeText(S.feed.get(item.id)?.item.md || item.md || '').then(() => toast('Đã sao chép')); };
      acts.appendChild(cp);
      body.appendChild(acts);
      m.appendChild(body);
      m.dataset.t = 'ai';
      return m;
    }
    case 'tool':
    case 'terminal': return renderToolCard(item);
    case 'plan': return renderPlan(item);
    case 'approval': return renderApproval(item);
    case 'ask': return renderAsk(item);
    case 'shot': return renderShot(item);
    case 'artifact': return renderArtifact(item);
    case 'note': {
      const icons = { ok: 'check', warn: 'alert', error: 'alert', info: 'info' };
      const n = el('div', 'note ' + (item.kind || 'info'), `<span class="ni">${nicon(icons[item.kind] || 'info')}</span><span class="nt"></span>`);
      n.querySelector('.nt').textContent = item.text || '';
      return n;
    }
  }
  return null;
}

function updateFeedItem(rec) {
  const item = rec.item;
  if (item.t === 'ai') {
    const md = rec.el.querySelector('.md-host');
    if (item.md) {
      // swap the thinking orb for real content — stop its animation loop
      const holder = md.querySelector('.nova-orb');
      if (holder) for (const o of [...feedOrbs]) if (o.el === holder || o.el.parentNode === null || !document.contains(o.el)) o.destroy();
      rec.el.style.display = '';
      NM.renderInto(md, item.md);
    } else if (item.done) {
      rec.el.style.display = 'none'; // streamed step that ended with tool calls only
      const holder = md.querySelector('.nova-orb');
      if (holder) for (const o of [...feedOrbs]) if (o.el === holder) o.destroy();
    }
    return;
  }
  if (item.t === 'tool' || item.t === 'terminal') return updateToolCard(rec.el, item);
  if (item.t === 'plan') return updatePlan(rec.el, item);
  if (item.t === 'approval') return updateApproval(rec.el, item);
  if (item.t === 'ask') return updateAsk(rec.el, item);
  if (item.t === 'note') {
    // notes can be upserted in place (e.g. the missing-API-key warning is one
    // stable item that flips to "resolved" once a key is configured) — so an
    // update must re-render kind + icon + text, not just the stored data
    const icons = { ok: 'check', warn: 'alert', error: 'alert', info: 'info' };
    rec.el.className = 'note ' + (item.kind || 'info');
    const ni = rec.el.querySelector('.ni');
    if (ni) ni.innerHTML = nicon(icons[item.kind] || 'info');
    const nt = rec.el.querySelector('.nt');
    if (nt) nt.textContent = item.text || '';
    return;
  }
}

/* --- plan checklist (plan_update tool) --- */
function planStepRow(s) {
  const row = el('div', 'plan-step ' + (s.status || 'pending'));
  const icon = s.status === 'done' ? '✓' : s.status === 'in_progress' ? '◐' : '○';
  row.innerHTML = `<span class="ps-ic">${icon}</span><span class="ps-tx"></span>`;
  row.querySelector('.ps-tx').textContent = s.content || '';
  return row;
}
function renderPlan(item) {
  const c = el('div', 'plan-card');
  const head = el('div', 'plan-head');
  head.innerHTML = `<b>Kế hoạch</b><span class="plan-count">${item.done || 0}/${item.total || (item.steps || []).length}</span>`;
  const list = el('div', 'plan-list');
  for (const s of item.steps || []) list.appendChild(planStepRow(s));
  c.appendChild(head); c.appendChild(list);
  return c;
}
function updatePlan(card, item) {
  card.querySelector('.plan-count').textContent = `${item.done || 0}/${item.total || (item.steps || []).length}`;
  const list = card.querySelector('.plan-list');
  list.innerHTML = '';
  for (const s of item.steps || []) list.appendChild(planStepRow(s));
}

/* --- tool / terminal cards --- */
function renderToolCard(item) {
  const isTerm = item.t === 'terminal';
  const c = el('div', 'tool' + (isTerm ? ' terminal' : ''));
  c.innerHTML = `
    <button class="tool-head">
      <span class="st"></span>
      <span class="ti">${nicon(toolIcon(item.name || ''))}</span>
      <span class="lb"></span>
      <span class="exit-chip" hidden></span>
      <span class="dur"></span>
      <span class="chev">${nicon('chevronDown')}</span>
    </button>
    <div class="tool-body">
      <div class="io-label">Input</div><pre class="io-in"></pre>
      <div class="io-label">Output</div><pre class="io-out"></pre>
    </div>`;
  c.querySelector('.tool-head').onclick = () => c.classList.toggle('open');
  updateToolCard(c, item);
  return c;
}

function updateToolCard(c, item) {
  const st = c.querySelector('.st');
  const status = item.status || 'running';
  st.className = 'st ' + (status === 'running' ? 'run' : status === 'success' ? 'ok' : status === 'error' ? 'err' : 'denied');
  st.innerHTML = nicon(status === 'running' ? 'spinner' : status === 'success' ? 'check' : 'x');
  c.classList.toggle('error', status === 'error');
  c.querySelector('.lb').textContent = item.label || item.name || '';
  c.querySelector('.tn')?.remove();
  const dur = c.querySelector('.dur');
  dur.textContent = item.duration != null ? (item.duration < 1000 ? item.duration + 'ms' : (item.duration / 1000).toFixed(1) + 's') : '';
  const exit = c.querySelector('.exit-chip');
  if (item.exitCode != null) {
    exit.hidden = false;
    exit.textContent = 'exit ' + item.exitCode;
    exit.className = 'exit-chip ' + (item.exitCode === 0 ? 'ok' : 'bad');
  }
  c.querySelector('.io-in').textContent = item.input || '—';
  c.querySelector('.io-out').textContent = item.output || (status === 'running' ? '…' : '—');
  if (item.t === 'terminal') {
    // terminal: output streams visibly in the header area instead
    c.querySelector('.io-out').textContent = item.output || '…';
  }
}

/* --- approval --- */
function renderApproval(item) {
  const c = el('div', 'approval');
  c.innerHTML = `
    <div class="ap-head"><span class="ai-ic">${nicon('shield')}</span><span class="ap-title"></span>
      <span class="risk-chip ${item.risk === 'high' ? 'high' : 'medium'}">${item.risk === 'high' ? 'rủi ro cao' : 'cần xác nhận'}</span></div>
    <div class="ap-detail"></div>
    <div class="ap-btns">
      <button class="btn pri" data-s="once">Cho phép</button>
      <button class="btn" data-s="task">Cho phép cả task</button>
      <button class="btn" data-s="always">Luôn cho phép</button>
      <button class="btn danger" data-s="no">Từ chối</button>
    </div>
    <div class="ap-status"></div>`;
  c.querySelector('.ap-title').textContent = item.title || 'Nova muốn thực hiện hành động';
  const det = c.querySelector('.ap-detail');
  const detail = item.detail || '';
  if (detail.length > 60 && detail.includes('\n')) {
    const pre = el('div', 'ap-cmd');
    pre.textContent = detail;
    det.replaceWith(pre);
  } else det.textContent = detail;
  for (const b of c.querySelectorAll('.ap-btns button')) {
    b.onclick = () => {
      const scope = b.dataset.s;
      bridge.cmd('approval_response', { convId: S.activeConvId, ok: scope !== 'no', scope }).catch(e => toast(e.message, 'err'));
      updateApproval(c, { ...item, status: scope === 'no' ? 'rejected' : 'approved' });
      S.feed.get(item.id) && (S.feed.get(item.id).item.status = scope === 'no' ? 'rejected' : 'approved');
    };
  }
  updateApproval(c, item);
  return c;
}
function updateApproval(c, item) {
  const resolved = item.status === 'approved' || item.status === 'rejected' || item.status === 'expired';
  c.classList.toggle('resolved', resolved);
  c.classList.toggle('ok', item.status === 'approved');
  c.classList.toggle('no', item.status === 'rejected' || item.status === 'expired');
  const st = c.querySelector('.ap-status');
  st.innerHTML = item.status === 'approved'
    ? nicon('check') + '<span>Đã cho phép</span>'
    : item.status === 'rejected' ? nicon('x') + '<span>Đã từ chối</span>'
    : item.status === 'expired' ? nicon('alert') + '<span>Hết hạn — Nova đã tự từ chối sau 5 phút chờ</span>' : '';
}

/* --- ask --- */
function renderAsk(item) {
  const c = el('div', 'ask');
  c.innerHTML = `<div class="q"><span class="q-ic">${nicon('question')}</span><span class="qt"></span></div>
    <div class="ask-opts"></div>
    <div class="ask-input"><input placeholder="Trả lời Nova…"><button title="Gửi">${nicon('send')}</button></div>
    <div class="ans"><b>Bạn: </b><span class="ans-t"></span></div>`;
  c.querySelector('.qt').textContent = item.question || '';
  const opts = c.querySelector('.ask-opts');
  for (const o of item.options || []) {
    const b = el('button');
    b.textContent = o;
    b.onclick = () => answer(item, o);
    opts.appendChild(b);
  }
  const input = c.querySelector('input');
  const submit = () => { if (input.value.trim()) answer(item, input.value.trim()); };
  c.querySelector('.ask-input button').onclick = submit;
  input.onkeydown = e => { if (e.key === 'Enter') submit(); };
  function answer(it, ans) {
    bridge.cmd('ask_response', { convId: S.activeConvId, answer: ans }).catch(e => toast(e.message, 'err'));
    updateAsk(c, { ...it, status: 'answered', answer: ans });
    S.feed.get(it.id) && Object.assign(S.feed.get(it.id).item, { status: 'answered', answer: ans });
  }
  updateAsk(c, item);
  return c;
}
function updateAsk(c, item) {
  const answered = item.status === 'answered';
  const expired = item.status === 'expired';
  c.classList.toggle('answered', answered || expired);
  if (answered) c.querySelector('.ans-t').textContent = item.answer || '';
  else if (expired) { c.querySelector('.ans').innerHTML = '<b></b><span class="ans-t">Hết hạn — Nova đã tự quyết định sau 10 phút chờ.</span>'; }
}

/* --- shot --- */
function renderShot(item) {
  const c = el('div', 'shot');
  c.innerHTML = `<div class="cap"></div>`;
  const img = new Image();
  img.alt = 'screenshot';
  img.style.cssText = 'display:block;width:100%;max-height:260px;object-fit:cover;object-position:top';
  c.prepend(img);
  c.querySelector('.cap').textContent = item.caption || 'screenshot';
  bridge.cmd('get_shot', { shotId: item.shotId })
    .then(({ shot }) => { img.src = shot.dataUrl; img.onload = () => scrollBottom(); })
    .catch(() => { img.remove(); c.querySelector('.cap').textContent = 'Ảnh chụp đã hết hạn (chỉ giữ trong bộ nhớ phiên).'; });
  c.onclick = () => {
    if (!img.src) return;
    $('#lb-img').src = img.src;
    $('#lb-cap').textContent = item.caption || '';
    $('#lightbox').classList.add('show');
  };
  return c;
}

/* --- artifact --- */
function renderArtifact(item) {
  const c = el('div', 'artifact');
  c.innerHTML = `
    <div class="art-top">
      <span class="art-ic">${nicon('file')}</span>
      <div class="art-tt"><b></b><span></span></div>
    </div>
    <div class="art-acts">
      <button class="btn" data-a="preview">${nicon('eye')} Xem</button>
      <button class="btn" data-a="dl">${nicon('download')} Tải xuống</button>
    </div>`;
  c.querySelector('b').textContent = item.name || 'artifact';
  c.querySelector('.art-tt span').textContent = `${item.mime || 'text'} · ${fmtN(item.size)}B`;
  const fetchArt = () => bridge.cmd('get_artifact', { artifactId: item.artifactId }).then(r => r.artifact);
  c.querySelector('[data-a=preview]').onclick = async () => {
    try {
      const art = await fetchArt();
      $('#art-name').textContent = art.name;
      const txt = art.text ?? (art.base64 ? b64Text(art.base64) : '');
      $('#art-body').textContent = txt.slice(0, 200000);
      $('#art-overlay').dataset.artId = art.id;
      $('#art-overlay').classList.add('show');
    } catch (e) { toast(e.message, 'err'); }
  };
  c.querySelector('[data-a=dl]').onclick = async () => {
    try {
      const art = await fetchArt();
      const blob = art.base64
        ? new Blob([b64Bytes(art.base64)], { type: art.mime || 'application/octet-stream' })
        : new Blob([art.text || ''], { type: art.mime || 'text/plain' });
      const u = URL.createObjectURL(blob);
      const a = el('a');
      a.href = u; a.download = art.name;
      a.click();
      setTimeout(() => URL.revokeObjectURL(u), 4000);
    } catch (e) { toast(e.message, 'err'); }
  };
  return c;
}

/* ==================== scrolling ==================== */
let userScrolledUp = false; // only the user can pin the scroll position
function nearBottom() {
  const w = $('#feed-wrap');
  return w.scrollHeight - w.scrollTop - w.clientHeight < 90;
}
function scrollBottom(force) {
  const w = $('#feed-wrap');
  if (force || !userScrolledUp) w.scrollTo({ top: w.scrollHeight, behavior: 'instant' });
}

/* ==================== events from the service worker ==================== */
const refreshConvs = debounce(async () => {
  try {
    const st = await bridge.cmd('get_state');
    S.conversations = st.conversations;
    S.usage = st.usage || S.usage;
    renderConvList();
  } catch (e) { }
}, 250);

function onEvent(event, data) {
  switch (event) {
    case 'FEED_ITEM':
      if (data.convId === S.activeConvId) upsertFeedItem(data.item);
      else refreshConvs();
      break;
    case 'AGENT_STATE_CHANGED':
      refreshConvs();
      if (data.convId === S.activeConvId) {
        if (RUNNING.has(data.state) && !RUNNING.has(S.agentState)) S.agentStartedAt = Date.now();
        if (data.state === 'idle' || data.state === 'completed' || data.state === 'failed' || data.state === 'stopped') S.agentStep = 0;
        setAgentState(data.state, data);
      }
      break;
    case 'STREAM_DELTA': {
      if (data.convId !== S.activeConvId) break;
      const rec = S.feed.get(data.id);
      if (rec) { rec.item.md = data.md; updateFeedItem(rec); scrollBottom(); }
      break;
    }
    case 'TAB_CHANGED': renderTab(data); break;
    case 'TOOL_STARTED':
      // terminal tools stream alongside thinking — flip the orbs to "connecting"
      if (data.convId === S.activeConvId && String(data.name || '').startsWith('terminal')) {
        S.termActive = true;
        syncOrbs(S.agentState);
      }
      break;
    case 'TOOL_COMPLETED':
    case 'TOOL_FAILED':
      if (data.convId === S.activeConvId && String(data.name || '').startsWith('terminal')) {
        S.termActive = false;
        syncOrbs(S.agentState);
      }
      break;
    case 'SELECTION_CHANGED': S.selection = data.selection; renderSelection(); break;
    case 'CONVERSATIONS_CHANGED': refreshConvs(); break;
    case 'SETTINGS_CHANGED':
      S.settings = data.settings;
      applyTheme(); applyFontSize(); renderCtxToggles(); renderSelection(); renderChips();
      syncReasonUI();
      break;
    case 'DEBUGGER_CHANGED':
      if (data.attached) S.debugTabs.add(data.tabId);
      else S.debugTabs.delete(data.tabId);
      renderDebugChip();
      break;
    case 'MODEL_FALLBACK': toast('Đã chuyển sang model dự phòng', 'ok', 'refresh'); break;
    case 'HUMAN_INTERFERENCE': toast('Phát hiện bạn đang thao tác — agent tạm dừng', 'err', 'hand'); break;
    case 'NEW_CHAT': newConversation(); break;
    case 'USAGE':
      if (data.convId === S.activeConvId && data.usage) {
        S.convUsage.input += data.usage.prompt || 0;
        S.convUsage.output += data.usage.completion || 0;
        S.convUsage.calls += 1;
        updateCtxMeter();
      }
      break;
  }
}

/* ==================== composer ==================== */
const input = () => $('#input');

function autogrow() {
  const ta = input();
  ta.style.height = 'auto';
  ta.style.height = Math.min(180, ta.scrollHeight) + 'px';
}

/* ==================== attachments (tải tài liệu lên) ==================== */
const ATTACH_MAX_FILES = 5;
const ATTACH_MAX_IMG = 6 * 1024 * 1024;   // 6 MB per image
const ATTACH_MAX_TXT = 512 * 1024;        // 512 KB per text file
const ATTACH_TEXT_CHARS = 120000;         // truncate huge text files
const TEXT_EXT = /\.(txt|md|markdown|csv|tsv|json|jsonl|xml|ya?ml|toml|ini|log|jsx?|tsx?|py|java|c|cc|cpp|h|hpp|cs|go|rs|rb|php|html?|css|scss|less|sql|sh|bash|bat|ps1|env|srt|vtt|diff|patch)$/i;
const TEXT_MIME = /^(text\/|application\/(json|xml|javascript|x-yaml|x-sh))/;
let attachSeq = 0;

function fmtBytes(n) {
  if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
  if (n >= 1024) return Math.round(n / 1024) + ' KB';
  return n + ' B';
}

/* static chip list for user feed items (meta only, no payload) */
function attachChips(list) {
  const row = el('div', 'u-atts');
  for (const a of list) {
    const chip = el('span', 'u-att');
    chip.innerHTML = `<span class="ua-ic">${nicon(a.kind === 'image' ? 'camera' : 'file')}</span><span class="ua-name"></span><span class="ua-size">${fmtBytes(a.size || 0)}</span>`;
    chip.querySelector('.ua-name').textContent = a.name || 'tệp';
    chip.title = `${a.name} · ${a.mime || ''} · ${fmtBytes(a.size || 0)}`;
    row.appendChild(chip);
  }
  return row;
}

function renderAttachRow() {
  const row = $('#attach-row');
  row.innerHTML = '';
  row.hidden = S.attachments.length === 0;
  for (const a of S.attachments) {
    const chip = el('span', 'att-chip');
    if (a.kind === 'image' && a.dataUrl) {
      const img = new Image();
      img.src = a.dataUrl; img.alt = a.name;
      chip.appendChild(img);
    } else {
      chip.insertAdjacentHTML('beforeend', `<span class="att-ic">${nicon('file')}</span>`);
    }
    chip.appendChild(el('span', 'att-name'));
    chip.querySelector('.att-name').textContent = a.name;
    const sz = el('span', 'att-size');
    sz.textContent = fmtBytes(a.size);
    chip.appendChild(sz);
    const x = el('button', 'att-x', nicon('x'));
    x.title = 'Gỡ tệp';
    x.onclick = () => { S.attachments = S.attachments.filter(v => v.id !== a.id); renderAttachRow(); };
    chip.appendChild(x);
    row.appendChild(chip);
  }
}

async function addFiles(fileList) {
  const files = [...(fileList || [])];
  if (!files.length) return;
  for (const f of files) {
    if (S.attachments.length >= ATTACH_MAX_FILES) { toast(`Tối đa ${ATTACH_MAX_FILES} tệp mỗi lần gửi`, 'err', 'alert'); break; }
    if (S.attachments.some(a => a.name === f.name && a.size === f.size)) continue;
    const isImg = /^image\//.test(f.type);
    const isTxt = TEXT_MIME.test(f.type) || TEXT_EXT.test(f.name);
    try {
      if (isImg) {
        if (f.size > ATTACH_MAX_IMG) { toast(`"${f.name}" quá lớn — ảnh tối đa ${fmtBytes(ATTACH_MAX_IMG)}`, 'err', 'alert'); continue; }
        const dataUrl = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
        S.attachments.push({ id: ++attachSeq, name: f.name, mime: f.type, size: f.size, kind: 'image', dataUrl });
      } else if (isTxt) {
        if (f.size > ATTACH_MAX_TXT) { toast(`"${f.name}" quá lớn — văn bản tối đa ${fmtBytes(ATTACH_MAX_TXT)}`, 'err', 'alert'); continue; }
        let text = await f.text();
        if (text.length > ATTACH_TEXT_CHARS) text = text.slice(0, ATTACH_TEXT_CHARS) + `\n[…cắt bớt ${fmtN(text.length - ATTACH_TEXT_CHARS)} ký tự]`;
        S.attachments.push({ id: ++attachSeq, name: f.name, mime: f.type || 'text/plain', size: f.size, kind: 'text', text });
      } else {
        toast(`"${f.name}" chưa hỗ trợ — hãy dùng ảnh hoặc file văn bản/code (txt, md, csv, json, js, py…)`, 'err', 'alert');
      }
    } catch (e) { toast('Không đọc được ' + f.name, 'err'); }
  }
  renderAttachRow();
  input().focus();
}

async function newConversation() {
  const { conversation } = await bridge.cmd('new_conversation', { mode: S.mode });
  await refreshConvs();
  await openConversation(conversation.id);
  input().focus();
}

async function sendMessage() {
  const text = input().value.trim();
  const atts = S.attachments.map(a => ({ name: a.name, mime: a.mime, size: a.size, kind: a.kind, text: a.text, dataUrl: a.dataUrl }));
  if (!text && !atts.length) return;
  if (!S.activeConvId) { toast('Chưa có hội thoại — đang tạo mới…', 'err', 'alert'); await newConversation().catch(() => { }); if (!S.activeConvId) return; }
  if (RUNNING.has(S.agentState)) { toast('Agent đang chạy — dừng (Alt+S) trước khi gửi tiếp', 'err', 'alert'); return; }
  input().value = '';
  autogrow();
  S.attachments = [];
  renderAttachRow();
  userScrolledUp = false;
  const sel = (!$('#sel-chip').hidden && S.selection) ? S.selection : null;
  S.selection = null; renderSelection();
  S.agentStartedAt = Date.now(); S.agentStep = 0;
  try {
    await bridge.cmd('run_task', { convId: S.activeConvId, text, mode: S.mode, selection: sel, attachments: atts });
    setAgentState('thinking');
  } catch (e) {
    toast(e.message, 'err');
    // gửi thất bại (agent busy, SW restart…) → trả lại nội dung cho composer,
    // trước đây input bị xoá trắng và người dùng mất toàn bộ đoạn đã gõ
    input().value = text;
    S.attachments = atts.map(a => ({ ...a, id: ++attachSeq }));
    renderAttachRow();
    autogrow();
  }
}

function setMode(mode, silent) {
  if (!MODES[mode]) return;
  S.mode = mode;
  syncModeSeg();
  renderChips();
  // persist the mode onto the active conversation so UI, conversation.mode
  // and the next run_task can never diverge (silent = change came FROM the
  // conversation itself, e.g. openConversation — don't echo it back)
  if (!silent && S.activeConvId) {
    bridge.cmd('set_conversation_mode', { convId: S.activeConvId, mode }).catch(() => { });
  }
  if (!silent) input().focus();
}

/* segmented 2-mode switch (Ask | Agent) — thay dropdown 5 chế độ cũ */
function buildModeSeg() {
  const segBox = $('#mode-seg');
  segBox.innerHTML = '<span class="seg-thumb" aria-hidden="true"></span>'; // thumb trượt kiểu Nova Web
  segBox.style.setProperty('--n', Object.keys(MODES).length);
  for (const [id, m] of Object.entries(MODES)) {
    const b = el('button', '', `${nicon(m.icon)}<span>${m.name}</span>`);
    b.dataset.mode = id;
    b.title = `${m.name} — ${m.desc}`;
    b.setAttribute('role', 'tab');
    b.onclick = () => setMode(id);
    segBox.appendChild(b);
  }
  syncModeSeg();
}
function syncModeSeg() {
  const ids = Object.keys(MODES);
  $('#mode-seg')?.style.setProperty('--i', Math.max(0, ids.indexOf(S.mode)));
  for (const b of $$('#mode-seg button')) {
    const on = b.dataset.mode === S.mode;
    b.classList.toggle('on', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
  }
}

/* ---- reasoning effort selector ---- */
function currentReasoning() {
  const r = S.settings?.reasoningEffort;
  return REASONING_LEVELS[r] ? r : 'off';
}
function setReasoning(level, silent) {
  if (!REASONING_LEVELS[level]) return;
  saveSettings({ reasoningEffort: level });
  syncReasonUI();
  if (!silent) input().focus();
}
function syncReasonUI() {
  const lv = currentReasoning();
  const btn = $('#btn-reason');
  if (!btn) return;
  btn.classList.toggle('on', lv !== 'off');
  btn.innerHTML = `${nicon('brain')}<span>${REASONING_LEVELS[lv].name}</span><span class="chev">${nicon('chevronDown')}</span>`;
  btn.title = `Mức suy luận: ${REASONING_LEVELS[lv].name} — ${REASONING_LEVELS[lv].desc}`;
  const menu = $('#reason-menu');
  if (menu?.dataset.built) {
    for (const b of menu.querySelectorAll('.pm-item')) b.classList.toggle('on', b.dataset.level === lv);
  }
}
function buildReasonMenu() {
  const menu = $('#reason-menu');
  menu.dataset.built = '1';
  menu.innerHTML = '<div class="pm-label">Mức suy luận (reasoning effort)</div>';
  for (const [id, m] of Object.entries(REASONING_LEVELS)) {
    const b = el('button', 'pm-item' + (currentReasoning() === id ? ' on' : ''));
    b.dataset.level = id;
    b.innerHTML = `<span class="pi">${nicon('brain')}</span><span class="grow"><b>${m.name}</b><small>${m.desc}</small></span><span class="tick">${nicon('check')}</span>`;
    b.onclick = () => { setReasoning(id); menu.classList.remove('show'); };
    menu.appendChild(b);
  }
  menu.appendChild(el('div', 'pm-label sm', 'Chỉ tác dụng với model hỗ trợ suy luận (o1/o3/o4, gpt-5, deepseek-r1, qwq, grok-3-mini, claude thinking…).'));
}

function renderChips() {
  const c = $('#chips');
  c.innerHTML = '';
  // terminal is a capability, not a mode — no mode chip needed here anymore.
  // (bridge status lives in Cài đặt → Terminal; policy gates each call.)
}

/* ==================== drawer ==================== */
function renderConvList() {
  const q = ($('#conv-search').value || '').toLowerCase();
  const list = $('#conv-list');
  list.innerHTML = '';
  const convs = S.conversations.filter(c => !q || (c.title || '').toLowerCase().includes(q));
  if (!convs.length) {
    list.appendChild(el('div', 'pal-empty', 'Chưa có hội thoại nào'));
    return;
  }
  for (const c of convs) {
    const st = c.agent?.state || 'idle';
    const dot = RUNNING.has(st) ? (st === 'awaiting_approval' || st === 'awaiting_user' ? 'awaiting' : 'running') : st === 'failed' ? 'failed' : '';
    const it = el('button', 'chat-item' + (c.id === S.activeConvId ? ' active' : ''));
    it.innerHTML = `<span class="ci-dot ${dot}"></span><span class="ci-t"><b></b><small></small></span>
      <span class="acts"><button data-a="del" title="Xóa">${nicon('trash')}</button></span>`;
    it.querySelector('b').textContent = c.title || 'Hội thoại';
    it.querySelector('small').textContent = `${MODES[c.mode]?.name || c.mode || 'agent'} · ${fmtTime(c.updatedAt)}${c.usage?.calls ? ` · ${fmtN((c.usage.input || 0) + (c.usage.output || 0))} tok` : ''}`;
    it.onclick = async e => {
      if (e.target.closest('[data-a=del]')) return;
      closeDrawer();
      await openConversation(c.id);
    };
    it.querySelector('[data-a=del]').onclick = async e => {
      e.stopPropagation();
      await bridge.cmd('delete_conversation', { convId: c.id }).catch(err => toast(err.message, 'err'));
      await refreshConvs();
      if (c.id === S.activeConvId) {
        const next = S.conversations.find(x => x.id !== c.id);
        if (next) await openConversation(next.id);
        else await newConversation();
      }
    };
    list.appendChild(it);
  }
}
function openDrawer() { S.drawerOpen = true; $('#drawer').classList.add('show'); $('#scrim').classList.add('show'); renderConvList(); }
function closeDrawer() { S.drawerOpen = false; $('#drawer').classList.remove('show'); $('#scrim').classList.remove('show'); }

function updateCtxMeter() {
  $('#ctx-meter').textContent = S.convUsage.calls ? `${fmtN(S.convUsage.input + S.convUsage.output)} tok` : '';
  $('#ctx-meter').title = `Token hội thoại này: ${fmtN(S.convUsage.input)} vào · ${fmtN(S.convUsage.output)} ra · ${S.convUsage.calls} lượt gọi`;
}

/* ==================== theme ==================== */
const DARK_MQ = matchMedia('(prefers-color-scheme: dark)'); // reuse one MediaQueryList
function applyTheme() {
  const t = S.settings?.theme || 'light'; // mặc định Light Mode (v0.6+)
  const dark = t === 'dark' || (t === 'system' && DARK_MQ.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  for (const k of ['pill', 'bar']) orbs[k]?.setDark(dark);
}
function applyFontSize() {
  document.documentElement.style.fontSize = (S.settings?.fontSize || 15) + 'px';
}
DARK_MQ.addEventListener?.('change', applyTheme);

/* ==================== settings modal ==================== */
/* Dirty tracking cho nút "Lưu thay đổi": các control vẫn áp dụng ngay
 * (live preview + debounced persist ở SW), còn nút Save ép flushStore() và
 * xác nhận bằng toast — người dùng có một điểm cam kết "đã ghi vào storage". */
let settingsDirty = false;
let savingSettings = false;

const saveSettings = async patch => {
  const r = await bridge.cmd('update_settings', { patch });
  S.settings = r.settings;
  applyTheme(); applyFontSize(); renderCtxToggles(); renderSelection(); renderChips();
  settingsDirty = true;
  syncSaveBar();
  return r.settings;
};

function syncSaveBar(flash) {
  const stateEl = $('#st-save-state');
  const btn = $('#st-save');
  if (!stateEl || !btn) return;
  stateEl.className = 'st-save-state' + (flash === 'saved' ? ' saved' : settingsDirty ? ' dirty' : '');
  stateEl.innerHTML = flash === 'saved'
    ? nicon('check') + '<span>Đã lưu vào chrome.storage.local</span>'
    : settingsDirty
      ? '<i class="dot"></i><span>Có thay đổi — bấm Lưu để ghi ngay</span>'
      : '<span>Thay đổi được áp dụng ngay; bấm Lưu để chắc chắn đã ghi.</span>';
  btn.classList.toggle('dirty', settingsDirty && flash !== 'saved');
  if (flash === 'saved') setTimeout(() => { if (!settingsDirty) syncSaveBar(); }, 2600);
}

async function flushSettingsNow() {
  if (savingSettings) return;
  savingSettings = true;
  const btn = $('#st-save');
  btn.disabled = true;
  btn.innerHTML = nicon('spinner') + ' Đang lưu…';
  const sp = btn.querySelector('svg');
  if (sp) sp.style.animation = 'spin 1s linear infinite';
  try {
    const r = await bridge.cmd('flush_settings');
    if (r?.settings) S.settings = r.settings;
    settingsDirty = false;
    syncSaveBar('saved');
    toast('Đã lưu cài đặt', 'ok');
  } catch (e) {
    syncSaveBar();
    toast('Lưu thất bại: ' + (e.message || 'lỗi không xác định'), 'err');
  } finally {
    btn.disabled = false;
    btn.innerHTML = nicon('check') + ' Lưu thay đổi';
    savingSettings = false;
  }
}

function fld(label, inputEl, desc) {
  const f = el('div', 'field');
  const l = el('label'); l.textContent = label;
  f.appendChild(l); f.appendChild(inputEl);
  if (desc) { const d = el('div', 'desc'); d.textContent = desc; f.appendChild(d); }
  return f;
}
function seg(options, current, onChange) {
  const s = el('div', 'seg');
  for (const [v, t] of options) {
    const b = el('button');
    b.textContent = t;
    b.classList.toggle('on', v === current);
    b.onclick = () => { for (const x of s.children) x.classList.remove('on'); b.classList.add('on'); onChange(v); };
    s.appendChild(b);
  }
  return s;
}
function sw(on, onChange) {
  const s = el('button', 'switch' + (on ? ' on' : ''));
  s.setAttribute('role', 'switch');
  s.onclick = () => { const v = !s.classList.contains('on'); s.classList.toggle('on', v); onChange(v); };
  return s;
}
function switchRow(title, desc, get, set) {
  const r = el('div', 'switch-row');
  const t = el('div');
  const b = el('b'); b.textContent = title; t.appendChild(b);
  if (desc) { const sm = el('small'); sm.textContent = desc; t.appendChild(sm); }
  r.appendChild(t);
  r.appendChild(sw(!!get(), v => set(v)));
  return r;
}
function numInput(value, min, max, onChange) {
  const i = el('input');
  i.type = 'number'; i.min = min; i.max = max; i.value = value;
  i.onchange = () => { const v = Math.max(min, Math.min(max, +i.value || min)); i.value = v; onChange(v); };
  return i;
}
function textInput(value, placeholder, onChange, type = 'text') {
  const i = el('input');
  i.type = type; i.value = value || ''; i.placeholder = placeholder || '';
  i.spellcheck = false;
  if (onChange) i.onchange = () => onChange(i.value);
  return i;
}
function paneTitle(t) { const p = el('div', 'pane-h'); p.textContent = t; return p; }

/* ---------- hướng dẫn cài Terminal bridge theo từng hệ điều hành ---------- */
function cmdChip(cmd) {
  const row = el('div', 'cmd-chip');
  const code = el('code');
  code.textContent = cmd;
  const cp = el('button', 'copy-btn', nicon('copy'));
  cp.title = 'Sao chép lệnh';
  cp.onclick = async () => {
    try { await navigator.clipboard.writeText(cmd); cp.innerHTML = nicon('check'); setTimeout(() => cp.innerHTML = nicon('copy'), 1500); }
    catch (e) { toast('Không sao chép được — hãy bôi đen và copy thủ công', 'err'); }
  };
  row.appendChild(code); row.appendChild(cp);
  return row;
}
function guideStep(n, text, cmds = []) {
  const s = el('div', 'g-step');
  const badge = el('span', 'g-n', String(n));
  const body = el('div', 'g-tx');
  const t = el('div');
  t.innerHTML = text; // static markup do chúng ta kiểm soát hoàn toàn
  body.appendChild(t);
  for (const c of cmds) body.appendChild(cmdChip(c));
  s.appendChild(badge); s.appendChild(body);
  return s;
}
function detectHostOS() {
  const p = (navigator.userAgent + ' ' + (navigator.platform || '')).toLowerCase();
  if (p.includes('win')) return 'windows';
  if (p.includes('mac')) return 'macos';
  return 'linux';
}
function buildTerminalGuide() {
  const wrap = el('div', 'term-guide');
  const extId = (typeof chrome !== 'undefined' && chrome.runtime?.id) || 'EXTENSION_ID';
  let os = detectHostOS();

  const osSeg = seg([['macos', 'macOS'], ['linux', 'Linux'], ['windows', 'Windows']], os, v => { os = v; renderSteps(); });
  osSeg.classList.add('os-seg');
  wrap.appendChild(osSeg);

  const stepsBox = el('div', 'g-steps');
  wrap.appendChild(stepsBox);

  const renderSteps = () => {
    stepsBox.innerHTML = '';
    const steps = [];
    if (os === 'windows') {
      steps.push(
        ['Mở <b>PowerShell</b>: nhấn <code>Win + X</code> → chọn <i>Terminal</i> / <i>Windows PowerShell</i>.', []],
        ['<code>cd</code> tới thư mục <code>native-host</code> của extension (nằm trong thư mục <code>dist</code> bạn đã load).', ['cd đường\\\\dẫn\\\\tới\\\\dist\\\\native-host']],
        ['Chạy installer (ExecutionPolicy Bypass chỉ áp dụng cho đúng phiên này):', [`powershell -ExecutionPolicy Bypass -File install.ps1 -ExtensionId ${extId}`]],
        ['Installer sẽ: copy <code>nova_host.py</code> vào <code>%LOCALAPPDATA%\\\\NovaAgent</code>, tạo <code>nova_host.bat</code>, ghi manifest <code>com.nova.agent.host.json</code> và đăng ký registry <code>HKCU\\\\Software\\\\Google\\\\Chrome\\\\NativeMessagingHosts</code>. Không cần quyền admin.', []],
        ['Quay lại đây và bấm <b>Kiểm tra kết nối</b> ở trên — trạng thái xanh là thành công.', []],
      );
    } else {
      const openHow = os === 'macos'
        ? 'Mở <b>Terminal</b>: nhấn <code>⌘ + Space</code> → gõ <i>Terminal</i> → Enter.'
        : 'Mở <b>Terminal</b>: nhấn <code>Ctrl + Alt + T</code> (hoặc mở từ menu ứng dụng).';
      steps.push(
        [openHow, []],
        ['<code>cd</code> tới thư mục <code>native-host</code> của extension (nằm trong thư mục <code>dist</code> bạn đã load).', ['cd đường/dẫn/tới/dist/native-host']],
        ['Cấp quyền thực thi cho installer (chỉ cần làm một lần):', ['chmod +x install.sh']],
        ['Chạy installer với Extension ID của Nova:', [`./install.sh ${extId}`]],
        ['Installer sẽ: kiểm tra <code>python3</code>, copy host vào <code>~/.nova-agent</code>, ghi manifest <code>com.nova.agent.host.json</code> và đăng ký vào thư mục NativeMessagingHosts của Chrome/Chromium/Edge/Brave có trên máy, rồi tự self-test.', []],
        ['Quay lại đây và bấm <b>Kiểm tra kết nối</b> ở trên — trạng thái xanh là thành công.', []],
      );
    }
    steps.forEach((s, i) => stepsBox.appendChild(guideStep(i + 1, s[0], s[1])));
  };
  renderSteps();

  /* ---- xử lý lỗi thường gặp ---- */
  const faq = el('div', 'ts-faq');
  const faqTitle = el('div', 'pane-h');
  faqTitle.textContent = 'Lỗi thường gặp';
  wrap.appendChild(faqTitle);
  const QA = [
    ['Permission denied (macOS/Linux)',
      'Installer chưa được cấp quyền thực thi. Chạy lại:',
      ['chmod +x install.sh', './install.sh ' + extId, '# hoặc bỏ qua chmod, chạy trực tiếp bằng bash:', 'bash install.sh ' + extId]],
    ['Python not found / không tìm thấy Python',
      'Bridge cần Python ≥ 3.8 trong PATH.',
      ['# macOS (Homebrew):', 'brew install python3', '# Ubuntu/Debian:', 'sudo apt install python3', '# Windows: cài từ python.org và TICK "Add python.exe to PATH"', 'python --version   # kiểm tra sau khi cài']],
    ['Registry key missing (Windows)',
      'Chrome Windows tìm native host qua registry. Nếu installer bị gián đoạn, đăng ký lại hoặc kiểm tra:',
      ['reg query "HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\com.nova.agent.host"', '# nếu báo ERROR: chạy lại install.ps1 đúng Extension ID']],
    ['Specified native messaging host not found',
      'Extension ID trong manifest không khớp ID hiện tại (ID đổi khi bạn load lại unpacked từ thư mục khác). Lấy ID mới ở chrome://extensions rồi chạy lại installer.',
      []],
    ['host did not answer ping / bridge không phản hồi',
      'Thường do Python quá cũ hoặc antivirus chặn. Tự kiểm tra host thủ công:',
      ['# macOS/Linux:', 'python3 ~/.nova-agent/nova_host.py --selftest', '# Windows (PowerShell):', 'python "$env:LOCALAPPDATA\\NovaAgent\\nova_host.py" --selftest']],
  ];
  for (const [q, a, cmds] of QA) {
    const det = el('details', 'faq-item');
    const sum = el('summary');
    sum.innerHTML = `${nicon('alert')}<span></span>`;
    sum.querySelector('span').textContent = q;
    det.appendChild(sum);
    const body = el('div', 'faq-body');
    const t = el('p'); t.textContent = a; body.appendChild(t);
    for (const c of cmds) {
      if (c.startsWith('#')) { const cmt = el('div', 'cmd-cmt'); cmt.textContent = c; body.appendChild(cmt); }
      else body.appendChild(cmdChip(c));
    }
    det.appendChild(body);
    faq.appendChild(det);
  }
  wrap.appendChild(faq);
  return wrap;
}

const TABS = [
  ['general', 'Chung', p => {
    p.appendChild(paneTitle('Hành vi agent'));
    p.appendChild(fld('Mức tự chủ', seg([['manual', 'Thủ công'], ['assisted', 'Có hỏi'], ['autonomous', 'Tự chủ']], S.settings.autonomy, v => saveSettings({ autonomy: v })),
      'Thủ công: hỏi mọi hành động từ mức trung bình trở lên. Có hỏi: chỉ hỏi hành động rủi ro. Tự chủ: chỉ hỏi hành động rủi ro cao.'));
    p.appendChild(fld('Nhịp thao tác', seg([['natural', 'Tự nhiên'], ['fast', 'Nhanh'], ['instant', 'Tức thì']], S.settings.actionDelay, v => saveSettings({ actionDelay: v })),
      'Khoảng nghỉ giữa các thao tác để bạn theo dõi kịp.'));
    p.appendChild(fld('Chế độ mặc định', (() => {
      const s = el('select');
      for (const [id, m] of Object.entries(MODES)) { const o = el('option'); o.value = id; o.textContent = m.name; s.appendChild(o); }
      s.value = S.settings.defaultMode || 'agent';
      s.onchange = () => saveSettings({ defaultMode: s.value });
      return s;
    })()));
    p.appendChild(paneTitle('Hội thoại'));
    p.appendChild(switchRow('Streaming', 'Hiển thị câu trả lời ngay khi model sinh ra.', () => S.settings.stream, v => saveSettings({ stream: v })));
    p.appendChild(switchRow('Tự đặt tên hội thoại', 'Dùng model đặt tiêu đề sau tin nhắn đầu.', () => S.settings.autoTitle, v => saveSettings({ autoTitle: v })));
    p.appendChild(switchRow('Enter để gửi', 'Tắt nếu bạn hay cần xuống dòng bằng Enter.', () => S.settings.enterSend, v => saveSettings({ enterSend: v })));
  }],

  ['models', 'Models', p => {
    const provSel = el('select');
    for (const [id, pr] of Object.entries(S.presets)) {
      const o = el('option'); o.value = id; o.textContent = pr.name + (S.providers.configs[id]?.hasKey ? '' : pr.noKey ? ' · local' : ' · chưa có key');
      provSel.appendChild(o);
    }
    provSel.value = S.providers.active || 'openai';
    p.appendChild(fld('Provider chính', provSel, 'Provider dùng cho mọi hội thoại.'));
    const curCfg = () => S.providers.configs[provSel.value] || {};
    const modelIn = textInput(curCfg().model || S.presets[provSel.value]?.model, 'vd: gpt-4o-mini', v => bridge.cmd('set_provider', { id: provSel.value, cfg: { model: v } }));
    const visIn = textInput(curCfg().visionModel || S.presets[provSel.value]?.vision, 'vd: gpt-4o', v => bridge.cmd('set_provider', { id: provSel.value, cfg: { visionModel: v } }));
    provSel.onchange = () => {
      bridge.cmd('set_active_provider', { id: provSel.value, fallback: S.providers.fallback, fallbackEnabled: S.providers.fallbackEnabled })
        .then(r => { S.providers = r.providers; const c = curCfg(); modelIn.value = c.model || S.presets[provSel.value]?.model || ''; visIn.value = c.visionModel || S.presets[provSel.value]?.vision || ''; buildStarters(); })
        .catch(e => toast(e.message, 'err'));
    };
    p.appendChild(fld('Model chính', modelIn));
    p.appendChild(fld('Vision model', visIn, 'Dùng khi cần phân tích ảnh chụp màn hình mà model chính không hỗ trợ.'));
    p.appendChild(switchRow('Tự chuyển vision model', 'Khi gửi ảnh cho model không hỗ trợ ảnh, tự dùng vision model.', () => S.settings.visionFallback, v => saveSettings({ visionFallback: v })));
    p.appendChild(fld('Chất lượng ảnh chụp', seg([['low', 'Thấp'], ['balanced', 'Cân bằng'], ['high', 'Cao']], S.settings.visionQuality, v => saveSettings({ visionQuality: v })),
      'Cao = sắc nét hơn nhưng tốn token hơn.'));
    p.appendChild(fld('Mức suy luận (reasoning effort)', seg([['off', 'Tắt'], ['low', 'Thấp'], ['medium', 'Vừa'], ['high', 'Cao']], S.settings.reasoningEffort || 'off', v => { saveSettings({ reasoningEffort: v }); syncReasonUI(); }),
      'Chỉ tác dụng với model hỗ trợ suy luận (o1/o3/o4, gpt-5, deepseek-r1, qwq, grok-3-mini, claude thinking…). Model khác chạy bình thường.'));
    p.appendChild(paneTitle('Dự phòng'));
    p.appendChild(switchRow('Bật fallback', 'Khi provider chính lỗi, tự chuyển sang provider dự phòng.', () => S.providers.fallbackEnabled, v => bridge.cmd('set_active_provider', { id: S.providers.active, fallback: S.providers.fallback, fallbackEnabled: v }).then(r => S.providers = r.providers)));
    const fbSel = el('select');
    const none = el('option'); none.value = ''; none.textContent = '— Không —'; fbSel.appendChild(none);
    for (const [id, pr] of Object.entries(S.presets)) { const o = el('option'); o.value = id; o.textContent = pr.name; fbSel.appendChild(o); }
    fbSel.value = S.providers.fallback || '';
    fbSel.onchange = () => bridge.cmd('set_active_provider', { id: S.providers.active, fallback: fbSel.value || null, fallbackEnabled: S.providers.fallbackEnabled }).then(r => S.providers = r.providers);
    p.appendChild(fld('Provider dự phòng', fbSel));
    p.appendChild(paneTitle('Sinh văn bản'));
    p.appendChild(fld('Temperature', (() => {
      const r = el('input'); r.type = 'range'; r.min = 0; r.max = 1; r.step = 0.05; r.value = S.settings.temperature;
      r.onchange = () => saveSettings({ temperature: +r.value });
      return r;
    })(), 'Thấp = chính xác, nhất quán. Cao = sáng tạo hơn.'));
    p.appendChild(fld('Max tokens / lượt', numInput(S.settings.maxTokens, 256, 32000, v => saveSettings({ maxTokens: v }))));
  }],

  ['providers', 'Providers', p => {
    const info = el('div', 'note info', `${nicon('info')}<span>API key chỉ lưu trong chrome.storage.local của trình duyệt này — không gửi đi đâu ngoài provider tương ứng.</span>`);
    p.appendChild(info);
    for (const [id, pr] of Object.entries(S.presets)) p.appendChild(providerCard(id, pr));
  }],

  ['agent', 'Agent', p => {
    p.appendChild(fld('Số bước tối đa / task', numInput(S.settings.maxSteps, 5, 200, v => saveSettings({ maxSteps: v })), 'Agent dừng lại và hỏi bạn khi đạt giới hạn.'));
    p.appendChild(fld('Thời gian chạy tối đa (phút)', numInput(S.settings.maxRuntimeMin, 1, 120, v => saveSettings({ maxRuntimeMin: v }))));
    p.appendChild(fld('Số lần retry khi lỗi mạng/tool', numInput(S.settings.maxRetries, 0, 5, v => saveSettings({ maxRetries: v }))));
    p.appendChild(fld('Ảnh chụp tối đa / task', numInput(S.settings.maxScreenshots, 4, 60, v => saveSettings({ maxScreenshots: v }))));
    p.appendChild(fld('Mức kiểm chứng', seg([['relaxed', 'Thoải mái'], ['standard', 'Chuẩn'], ['strict', 'Nghiêm']], S.settings.verification, v => saveSettings({ verification: v })),
      'Nghiêm: sau mỗi hành động quan trọng, agent phải quan sát lại để xác nhận kết quả.'));
    p.appendChild(fld('Chiến lược khôi phục lỗi', seg([['conservative', 'Thận trọng'], ['standard', 'Chuẩn'], ['aggressive', 'Quyết liệt']], S.settings.recovery, v => saveSettings({ recovery: v })),
      'Khi một hành động thất bại: thận trọng = hỏi bạn sớm; quyết liệt = tự thử nhiều cách khác.'));
    p.appendChild(switchRow('Stream suy luận từng bước', 'Hiển thị trực tiếp phần suy luận của agent giữa các bước (tự tắt nếu provider không hỗ trợ).', () => S.settings.streamAgent !== false, v => saveSettings({ streamAgent: v })));
    p.appendChild(switchRow('Chống lặp vòng (loop guard)', 'Phát hiện agent gọi lặp cùng một hành động và tự yêu cầu đổi chiến lược / dừng.', () => S.settings.loopGuard !== false, v => saveSettings({ loopGuard: v })));
  }],

  ['browser', 'Trình duyệt', p => {
    p.appendChild(paneTitle('Hiệu ứng trên trang'));
    p.appendChild(switchRow('Edge lightning', 'Viền sáng chạy quanh trang khi agent đang làm việc.', () => S.settings.edgeLightning, v => saveSettings({ edgeLightning: v })));
    p.appendChild(switchRow('Hiệu ứng hành động', 'Highlight phần tử, ripple khi click, con trỏ ảo.', () => S.settings.showActionOverlay, v => saveSettings({ showActionOverlay: v })));
    p.appendChild(switchRow('Badge trạng thái', 'Huy hiệu nhỏ góc màn hình (NOVA · ACTING…).', () => S.settings.showStatusBadge, v => saveSettings({ showStatusBadge: v })));
    p.appendChild(paneTitle('Chế độ debug (CDP)'));
    p.appendChild(switchRow('Bật chế độ debug của Chrome', 'Cho phép AI attach chrome.debugger vào tab để điều khiển mức thấp: chạy JS trong trang, input tin cậy, chụp màn hình nền, đọc network log. Chrome hiện banner "đang debug" khi hoạt động — đó là chuẩn của Chrome.', () => S.settings.debuggerEnabled, v => saveSettings({ debuggerEnabled: v })));
    p.appendChild(paneTitle('Ngữ cảnh mặc định gửi kèm'));
    p.appendChild(switchRow('Thông tin trang', 'URL, tiêu đề, viewport, vị trí cuộn.', () => S.settings.includeContext.page, v => saveSettings({ includeContext: { page: v } })));
    p.appendChild(switchRow('DOM tương tác', 'Danh sách phần tử click/gõ được (khi không dùng a11y).', () => S.settings.includeContext.dom, v => saveSettings({ includeContext: { dom: v } })));
    p.appendChild(switchRow('Accessibility tree', 'Cấu trúc ngữ nghĩa của trang — tiết kiệm token hơn DOM.', () => S.settings.includeContext.a11y, v => saveSettings({ includeContext: { a11y: v } })));
    p.appendChild(switchRow('Đoạn bôi đen', 'Văn bản bạn chọn trên trang.', () => S.settings.includeContext.selection, v => saveSettings({ includeContext: { selection: v } })));
  }],

  ['terminal', 'Terminal', p => {
    p.appendChild(switchRow('Bật terminal thật', 'Cho phép agent chạy lệnh shell trên máy bạn qua bridge local.', () => S.settings.terminalEnabled, v => saveSettings({ terminalEnabled: v })));
    p.appendChild(fld('Chính sách phê duyệt', seg([['ask-all', 'Luôn hỏi'], ['ask-risky', 'Hỏi lệnh rủi ro'], ['auto-safe', 'Tự chạy lệnh an toàn']], S.settings.terminalPolicy, v => saveSettings({ terminalPolicy: v })),
      'Lệnh phá hủy (rm -rf, format, sudo…) luôn hỏi bất kể chính sách.'));
    p.appendChild(fld('Timeout mặc định (giây)', numInput(S.settings.terminalTimeout, 5, 1800, v => saveSettings({ terminalTimeout: v }))));
    p.appendChild(fld('Thư mục làm việc', textInput(S.settings.workspace, '~/nova-agent', v => saveSettings({ workspace: v }))));
    p.appendChild(paneTitle('Trạng thái bridge'));
    const status = el('div', 'term-status', '<span class="ts-dot"></span><span class="ts-txt">Chưa kiểm tra</span>');
    const btn = el('button', 'btn sm', nicon('refresh') + ' Kiểm tra kết nối');
    btn.onclick = async () => {
      status.className = 'term-status'; status.querySelector('.ts-txt').textContent = 'Đang kiểm tra…';
      try {
        const r = await bridge.cmd('terminal_status');
        if (r.installed) { status.className = 'term-status ok'; status.querySelector('.ts-txt').textContent = `Đã kết nối · ${r.info?.os || ''} · python ${r.info?.python || ''}`; }
        else { status.className = 'term-status bad'; status.querySelector('.ts-txt').textContent = 'Chưa cài bridge — làm theo hướng dẫn bên dưới'; }
      } catch (e) { status.className = 'term-status bad'; status.querySelector('.ts-txt').textContent = e.message; }
    };
    p.appendChild(status); p.appendChild(btn);
    p.appendChild(paneTitle('Cài đặt bridge (native host)'));
    p.appendChild(buildTerminalGuide());
    const d = el('div', 'desc');
    d.textContent = 'Bridge là một script Python chạy local, nói chuyện với extension qua native messaging (stdio JSON). Mọi lệnh đều bị policy engine kiểm soát và (tuỳ cài đặt) cần bạn phê duyệt trước.';
    p.appendChild(d);
  }],

  ['tools', 'Công cụ', p => {
    const info = el('div', 'note info', `${nicon('info')}<span>Kiểm soát quyền từng nhóm công cụ. "Hỏi" = agent phải xin phép trước mỗi lần dùng.</span>`);
    p.appendChild(info);
    const grid = el('div', 'perm-grid');
    const GROUPS = [
      ['browser', 'Trình duyệt', 'Click, gõ phím, cuộn, điều hướng, tab'],
      ['vision', 'Ảnh chụp', 'Chụp màn hình, phân tích ảnh'],
      ['downloads', 'Tải xuống', 'Tải file từ trang web về máy'],
      ['uploads', 'Tải lên', 'Đưa file/artifact lên trang web'],
      ['files', 'Artifacts', 'Tạo và đọc file trong phiên'],
      ['terminal', 'Terminal', 'Chạy lệnh shell qua bridge'],
      ['multitab', 'Đa tab', 'Mở/đóng/chuyển tab'],
      ['canvas', 'Canvas', 'Vẽ và thao tác trên phần tử canvas'],
      ['research', 'Nghiên cứu', 'Tìm kiếm web, đọc trang'],
      ['scripts', 'Script trang', 'Chạy script nhỏ trong trang (đã giới hạn)'],
      ['cdp', 'Debug (CDP)', 'chrome.debugger: JS trong trang, input tin cậy, network log'],
    ];
    for (const [k, name, desc] of GROUPS) {
      const row = el('div', 'perm-row');
      const t = el('div');
      const b = el('b'); b.textContent = name;
      const sm = el('small'); sm.textContent = desc;
      t.appendChild(b); t.appendChild(sm);
      row.appendChild(t);
      row.appendChild(seg([['allowed', 'Cho phép'], ['ask', 'Hỏi'], ['denied', 'Cấm']], S.settings.toolPerms[k] || 'ask', v => saveSettings({ toolPerms: { [k]: v } })));
      grid.appendChild(row);
    }
    p.appendChild(grid);
  }],

  ['privacy', 'Riêng tư', p => {
    p.appendChild(switchRow('Chế độ debug', 'Log chi tiết vào console của service worker.', () => S.settings.debug, v => saveSettings({ debug: v })));
    const rows = [
      ['API key', 'Chỉ lưu trong chrome.storage.local, không bao giờ hiển thị đầy đủ hay đưa vào URL/log.'],
      ['Mật khẩu & OTP', 'Giá trị ô nhập nhạy cảm bị thay bằng [REDACTED] trước khi gửi cho model.'],
      ['Nội dung trang web', 'Luôn được đánh dấu UNTRUSTED — trang không thể ra lệnh cho agent.'],
      ['Terminal output', 'Được quét và che token/mật khẩu trước khi đưa vào ngữ cảnh.'],
      ['Dữ liệu hội thoại', 'Nằm hoàn toàn trong trình duyệt của bạn; xoá bất cứ lúc nào ở tab Dữ liệu.'],
    ];
    for (const [t, d] of rows) {
      const n = el('div', 'switch-row');
      const x = el('div'); const b = el('b'); b.textContent = t; const sm = el('small'); sm.textContent = d;
      x.appendChild(b); x.appendChild(sm); n.appendChild(x);
      const ic = el('span', '', nicon('shield')); ic.style.color = 'var(--ok)'; n.appendChild(ic);
      p.appendChild(n);
    }
  }],

  ['appearance', 'Giao diện', p => {
    p.appendChild(fld('Chủ đề', seg([['dark', 'Tối'], ['light', 'Sáng'], ['system', 'Hệ thống']], S.settings.theme, v => saveSettings({ theme: v }))));
    p.appendChild(fld('Cỡ chữ', (() => {
      const wrap = el('div');
      const r = el('input'); r.type = 'range'; r.min = 12; r.max = 17; r.step = 0.5; r.value = S.settings.fontSize || 14;
      const lab = el('div', 'desc'); lab.textContent = (S.settings.fontSize || 14) + 'px';
      r.oninput = () => { lab.textContent = r.value + 'px'; applyFontSizePreview(+r.value); };
      r.onchange = () => saveSettings({ fontSize: +r.value });
      wrap.appendChild(r); wrap.appendChild(lab);
      return wrap;
    })()));
  }],

  ['data', 'Dữ liệu', p => {
    p.appendChild(paneTitle('Sử dụng token (toàn bộ)'));
    const grid = el('div', 'data-grid');
    const cells = [
      [fmtN(S.usage.input), 'token vào'], [fmtN(S.usage.output), 'token ra'],
      [fmtN(S.usage.calls), 'lượt gọi model'], [S.conversations.length, 'hội thoại'],
    ];
    for (const [v, l] of cells) {
      const c = el('div', 'data-cell');
      const b = el('b'); b.textContent = v;
      const s = el('span'); s.textContent = l;
      c.appendChild(b); c.appendChild(s);
      grid.appendChild(c);
    }
    p.appendChild(grid);
    const exp = el('button', 'btn', nicon('download') + ' Xuất toàn bộ dữ liệu (JSON)');
    exp.onclick = async () => {
      const st = await bridge.cmd('get_state');
      const convs = {};
      for (const c of st.conversations) {
        const full = await bridge.cmd('get_conversation', { convId: c.id }).catch(() => null);
        if (full) convs[c.id] = full.conversation;
      }
      const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), settings: st.settings, conversations: convs }, null, 2)], { type: 'application/json' });
      const u = URL.createObjectURL(blob);
      const a = el('a'); a.href = u; a.download = 'nova-agent-export.json'; a.click();
      setTimeout(() => URL.revokeObjectURL(u), 4000);
    };
    p.appendChild(exp);
    p.appendChild(paneTitle('Vùng nguy hiểm'));
    const dz = el('div', 'danger-zone');
    const dzb = el('b'); dzb.textContent = 'Xoá toàn bộ dữ liệu';
    const dzs = el('small'); dzs.textContent = 'Xoá hội thoại, cài đặt và API key đã lưu. Không thể hoàn tác.';
    const btn = el('button', 'btn danger sm', nicon('trash') + ' Xoá tất cả');
    btn.onclick = async () => {
      if (btn.dataset.arm !== '1') { btn.dataset.arm = '1'; btn.textContent = 'Nhấn lần nữa để xác nhận xoá'; return; }
      await bridge.cmd('wipe_all');
      toast('Đã xoá toàn bộ dữ liệu');
      setTimeout(() => location.reload(), 600);
    };
    dz.appendChild(dzb); dz.appendChild(dzs); dz.appendChild(btn);
    p.appendChild(dz);
  }],
];

function applyFontSizePreview(px) { document.documentElement.style.fontSize = px + 'px'; }

function providerCard(id, pr) {
  const cfg = S.providers.configs[id] || {};
  const isActive = S.providers.active === id;
  const c = el('div', 'keycard' + (isActive ? ' active' : ''));
  c.dataset.pid = id;
  const top = el('div', 'kc-top');
  const b = el('b'); b.textContent = pr.name; top.appendChild(b);
  const state = el('span', 'kc-state');
  state.textContent = pr.noKey ? 'local' : cfg.hasKey ? ('có key ' + (cfg.keyPreview || '')) : 'chưa có key';
  top.appendChild(state);
  c.appendChild(top);
  if (pr.note) { const s = el('div', 'kc-sub'); s.textContent = pr.note; c.appendChild(s); }

  const keyIn = textInput('', cfg.hasKey ? '••••••••' + (cfg.keyPreview || '').slice(-4) + ' (giữ nguyên nếu bỏ trống)' : (pr.noKey ? 'không cần key' : 'dán API key vào đây'), null, 'password');
  if (pr.noKey) keyIn.disabled = true;
  const baseIn = textInput(cfg.base || pr.base, pr.base || 'https://…', null);
  const r1 = el('div', 'kc-row'); r1.appendChild(keyIn);
  c.appendChild(r1);
  c.appendChild(fld2('Base URL', baseIn));

  const tstat = el('div', 'tstat');
  const acts = el('div', 'kc-acts');
  const save = el('button', 'btn sm pri', 'Lưu');
  save.onclick = async () => {
    const keyRaw = keyIn.value;
    if (keyRaw && !keyRaw.trim()) { toast('API key chỉ toàn khoảng trắng — chưa lưu', 'err', 'alert'); return; }
    const cfgPatch = { base: baseIn.value.trim() || pr.base };
    if (keyRaw.trim()) cfgPatch.apiKey = keyRaw.trim();
    const r = await bridge.cmd('set_provider', { id, cfg: cfgPatch }).catch(e => (toast(e.message, 'err'), null));
    if (r) {
      S.providers = r.providers; // SW may have auto-activated this provider (single source of truth)
      keyIn.value = '';
      toast('Đã lưu ' + pr.name + (S.providers.active === id ? ' · đang dùng làm provider chính' : ''));
      // keep the old UI-side activation for no-key local providers
      if (!S.providers.active && pr.noKey) {
        const r2 = await bridge.cmd('set_active_provider', { id, fallback: S.providers.fallback, fallbackEnabled: S.providers.fallbackEnabled }).catch(() => null);
        if (r2) S.providers = r2.providers;
      }
      rerenderSettingsPane('providers');
      buildStarters(); // the "API key" footnote depends on live provider state
    }
  };
  const test = el('button', 'btn sm', nicon('refresh') + ' Test');
  test.onclick = async () => {
    tstat.className = 'tstat'; tstat.innerHTML = nicon('spinner') + '<span>Đang test…</span>';
    tstat.querySelector('svg').style.animation = 'spin 1s linear infinite';
    try {
      // test exactly what the user sees: unsaved field values win, otherwise
      // the SW falls back to the stored key (resolveProviderCfg)
      const override = { base: baseIn.value.trim() || undefined };
      if (keyIn.value.trim()) override.apiKey = keyIn.value.trim();
      const r = await bridge.cmd('test_provider', { id, cfg: override });
      if (r.ok) {
        // AUTO-SAVE: test thành công mà key/base còn nằm trong ô nhập (chưa bấm
        // Lưu) → lưu luôn, nếu không agent sẽ báo "chưa có API key" dù user đã
        // nhập key đúng và test pass. Cập nhật chip trạng thái tại chỗ để không
        // re-render (mất dòng kết quả test).
        let saved = false;
        const keyRaw = keyIn.value.trim();
        if (keyRaw || baseIn.value.trim()) {
          const cfgPatch = { base: baseIn.value.trim() || pr.base };
          if (keyRaw) cfgPatch.apiKey = keyRaw;
          const sr = await bridge.cmd('set_provider', { id, cfg: cfgPatch }).catch(() => null);
          if (sr) {
            S.providers = sr.providers;
            keyIn.value = '';
            saved = true;
            const newCfg = S.providers.configs[id] || {};
            state.textContent = pr.noKey ? 'local' : newCfg.hasKey ? ('có key ' + (newCfg.keyPreview || '')) : 'chưa có key';
            c.classList.toggle('active', S.providers.active === id);
            buildStarters(); // footnote "Chưa có API key" phụ thuộc trạng thái live
          }
        }
        tstat.className = 'tstat ok';
        tstat.innerHTML = nicon('check') + `<span>${r.model || 'OK'} · ${r.latencyMs}ms${saved ? ' · đã tự động lưu' : ''}</span>`;
      }
      else { tstat.className = 'tstat bad'; tstat.innerHTML = nicon('x') + `<span></span>`; tstat.querySelector('span').textContent = r.message || 'lỗi'; }
    } catch (e) { tstat.className = 'tstat bad'; tstat.innerHTML = nicon('x') + '<span></span>'; tstat.querySelector('span').textContent = e.message; }
  };
  const setActive = el('button', 'btn sm', 'Đặt làm chính');
  setActive.onclick = async () => {
    const r = await bridge.cmd('set_active_provider', { id, fallback: S.providers.fallback, fallbackEnabled: S.providers.fallbackEnabled });
    S.providers = r.providers;
    rerenderSettingsPane('providers');
    toast('Provider chính: ' + pr.name);
  };
  acts.appendChild(save); acts.appendChild(test); acts.appendChild(setActive);
  if (pr.keyUrl) {
    const lk = el('button', 'link-btn', nicon('external') + ' Lấy API key');
    lk.onclick = () => bridge.isMock ? toast(pr.keyUrl) : chrome.tabs.create({ url: pr.keyUrl });
    acts.appendChild(el('span', 'spacer'));
    acts.appendChild(lk);
  }
  c.appendChild(acts);
  c.appendChild(tstat);
  return c;
}
function fld2(label, inputEl) { const f = el('div', 'field'); const l = el('label'); l.textContent = label; l.style.cssText = 'font-size:.68rem;font-weight:620;color:var(--tx3);margin-bottom:4px;display:block'; f.appendChild(l); f.appendChild(inputEl); return f; }

let currentTab = 'general';
function openSettings(tab) {
  currentTab = tab || currentTab;
  $('#settings-overlay').classList.add('show');
  renderSettingsTabs();
  rerenderSettingsPane(currentTab);
  syncSaveBar();
  // arrows need real measurements → wait one frame for layout
  requestAnimationFrame(updateTabNav);
}
function renderSettingsTabs() {
  const t = $('#st-tabs');
  t.innerHTML = '';
  for (const [id, name] of TABS) {
    const b = el('button', 'tab' + (id === currentTab ? ' on' : ''));
    b.textContent = name;
    b.onclick = () => {
      currentTab = id;
      renderSettingsTabs();
      rerenderSettingsPane(id);
    };
    t.appendChild(b);
  }
  // tab đang chọn phải luôn nằm trong vùng nhìn thấy của strip cuộn ngang
  requestAnimationFrame(() => {
    t.querySelector('.tab.on')?.scrollIntoView({ inline: 'nearest', block: 'nearest' });
    updateTabNav();
  });
}
/* Mũi tên ‹ › + trạng thái enable: không bắt user kéo rộng sidepanel
 * chỉ để chạm vào tab bị khuất */
function updateTabNav() {
  const t = $('#st-tabs');
  const wrap = t?.closest('.tabs-wrap');
  const prev = $('#st-tab-prev'), next = $('#st-tab-next');
  if (!t || !wrap || !prev || !next) return;
  const overflow = t.scrollWidth > t.clientWidth + 4;
  wrap.classList.toggle('overflow', overflow);
  prev.disabled = !overflow || t.scrollLeft <= 2;
  next.disabled = !overflow || t.scrollLeft >= (t.scrollWidth - t.clientWidth - 2);
}
function rerenderSettingsPane(tabId) {
  const body = $('#st-body');
  body.innerHTML = '';
  const pane = el('div', 'pane on');
  const def = TABS.find(t => t[0] === tabId);
  def[2](pane);
  body.appendChild(pane);
}

/* ==================== command palette ==================== */
function paletteActions() {
  const running = RUNNING.has(S.agentState);
  const paused = S.agentState === 'paused';
  const acts = [
    { icon: 'plus', t: 'Chat mới', k: 'Alt+Shift+N', fn: () => newConversation() },
    {
      icon: 'stop', t: 'Dừng agent', k: 'Alt+S',
      when: () => running, why: 'Agent hiện không chạy — không có gì để dừng',
      fn: () => bridge.cmd('stop', { convId: S.activeConvId }),
    },
    {
      icon: 'pause', t: 'Tạm dừng agent',
      when: () => running && !paused, why: paused ? 'Agent đã tạm dừng rồi' : 'Agent hiện không chạy',
      fn: () => bridge.cmd('pause', { convId: S.activeConvId }),
    },
    {
      icon: 'play', t: 'Tiếp tục agent',
      when: () => paused, why: 'Chỉ dùng được khi agent đang tạm dừng',
      fn: () => bridge.cmd('resume', { convId: S.activeConvId }),
    },
    { icon: 'menu', t: 'Lịch sử hội thoại', k: 'Ctrl+O', fn: () => openDrawer() },
    { icon: 'settings', t: 'Mở cài đặt', fn: () => openSettings('general') },
    { icon: 'key', t: 'Cài đặt → Providers', fn: () => openSettings('providers') },
    { icon: 'terminal', t: 'Cài đặt → Terminal', fn: () => openSettings('terminal') },
    { icon: 'sun', t: 'Đổi chủ đề sáng/tối', fn: () => saveSettings({ theme: document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark' }) },
    {
      icon: 'camera', t: 'Chụp & phân tích màn hình',
      when: () => !!S.activeConvId && !running, why: running ? 'Agent đang chạy — dừng trước đã' : 'Chưa có hội thoại nào',
      fn: () => { setMode('agent'); input().value = 'Chụp màn hình trang hiện tại rồi mô tả những gì bạn thấy.'; autogrow(); return sendMessage(); },
    },
    {
      icon: 'trash', t: 'Xoá lịch sử hội thoại',
      when: () => !running, why: 'Agent đang chạy — dừng trước khi xoá',
      fn: async () => { await bridge.cmd('clear_conversations'); await refreshConvs(); await newConversation(); toast('Đã xoá lịch sử'); },
    },
  ];
  for (const [id, m] of Object.entries(MODES)) {
    acts.push({
      icon: m.icon, t: 'Chế độ: ' + m.name,
      when: () => !running, why: 'Không đổi chế độ khi agent đang chạy',
      fn: () => setMode(id),
    });
  }
  return acts;
}

/* standard async wrapper — no rejected promise is ever swallowed */
let palRunning = false;
async function execPaletteAction(a) {
  if (!a || palRunning) return;
  if (a.when && !a.when()) { toast(a.why || 'Lệnh này hiện không khả dụng', 'err', 'alert'); return; }
  palRunning = true;
  try { await a.fn(); }
  catch (e) { console.error('[nova] palette command failed:', a.t, e); toast(`${a.t}: ${e.message || 'lỗi không xác định'}`, 'err', 'alert'); }
  finally { palRunning = false; }
}

let palSel = 0;
function openPalette() {
  palSel = 0; // reopening always resets selection + query
  $('#palette-overlay').classList.add('show');
  const inp = $('#palette-input');
  inp.value = '';
  renderPalette('');
  setTimeout(() => inp.focus(), 0);
}
function closePalette() {
  const wasOpen = $('#palette-overlay').classList.contains('show');
  $('#palette-overlay').classList.remove('show');
  if (wasOpen) input().focus(); // focus returns to the composer
}
function renderPalette(q) {
  const list = $('#palette-list');
  list.innerHTML = '';
  const acts = paletteActions().filter(a => !q || a.t.toLowerCase().includes(q.toLowerCase()));
  palSel = Math.min(Math.max(0, palSel), Math.max(0, acts.length - 1));
  if (!acts.length) { list.appendChild(el('div', 'pal-empty', 'Không có lệnh phù hợp')); list._acts = acts; return; }
  acts.forEach((a, i) => {
    const usable = !a.when || a.when();
    const it = el('button', 'pal-item' + (i === palSel ? ' sel' : '') + (usable ? '' : ' dim'));
    it.innerHTML = `<span class="pi">${nicon(a.icon)}</span><b></b>${!usable && a.why ? '<span class="why"></span>' : ''}${a.k ? `<span class="kbd">${a.k}</span>` : ''}`;
    it.querySelector('b').textContent = a.t;
    if (!usable) { it.title = a.why || 'Hiện không khả dụng'; const w = it.querySelector('.why'); if (w) w.textContent = a.why; }
    it.onclick = () => { closePalette(); execPaletteAction(a); };
    // hover only moves the highlight — re-rendering the whole list here used to
    // destroy the node under the cursor and retrigger mouseenter forever
    it.onmouseenter = () => { if (palSel !== i) { palSel = i; paintPaletteSel(); } };
    list.appendChild(it);
  });
  list._acts = acts;
  paintPaletteSel();
}
function paintPaletteSel() {
  const list = $('#palette-list');
  [...list.children].forEach((node, i) => {
    const on = i === palSel && node.classList.contains('pal-item');
    node.classList.toggle('sel', on);
    if (on) node.scrollIntoView({ block: 'nearest' });
  });
}

/* ==================== starters ==================== */
function buildStarters() {
  const items = [
    ['question', 'Hỏi về trang này', 'Tóm tắt, giải thích, trích xuất — chỉ đọc, không thao tác', 'ask', 'Tóm tắt nội dung chính của trang này, kèm các điểm đáng chú ý.'],
    ['zap', 'Tự động hoá tác vụ', 'Nova tự click, gõ, cuộn để hoàn thành mục tiêu', 'agent', ''],
    ['book', 'Nghiên cứu một chủ đề', 'Tìm kiếm đa nguồn và tổng hợp báo cáo', 'agent', 'Nghiên cứu chủ đề: '],
    ['bug', 'Điều khiển bằng debug (CDP)', 'Attach debugger của Chrome để AI điều khiển tab ở mức thấp', 'agent', 'Bật chế độ debug (attach debugger vào tab này) rồi '],
    ['terminal', 'Chạy lệnh trên máy', 'Nova tự gọi terminal khi cần — kể cả giữa chừng', 'agent', 'Dùng terminal chạy lệnh: '],
  ];
  const wrap = $('#starters');
  wrap.innerHTML = '';
  for (const [ic, t, d, mode, fill] of items) {
    const b = el('button', 'starter');
    b.innerHTML = `<span class="si-ic">${nicon(ic)}</span><span class="grow"><b>${t}</b><small>${d}</small></span><span class="go">${nicon('arrowRight')}</span>`;
    b.onclick = () => {
      setMode(mode);
      if (fill) { input().value = fill; autogrow(); }
      input().focus();
    };
    wrap.appendChild(b);
  }
  const foot = $('#empty-foot');
  foot.innerHTML = '';
  const hasKey = S.providers?.active && (S.providers.configs[S.providers.active]?.hasKey || S.presets?.[S.providers.active]?.noKey);
  const f1 = el('span', '', nicon(hasKey ? 'check' : 'key') + `<span>${hasKey ? 'API key đã sẵn sàng' : 'Chưa có API key — bấm để thêm'}</span>`);
  if (!hasKey) { f1.style.cursor = 'pointer'; f1.style.color = 'var(--warn)'; f1.onclick = () => openSettings('providers'); }
  foot.appendChild(f1);
  foot.appendChild(el('span', '', nicon('shield') + '<span>Mọi hành động rủi ro đều hỏi trước</span>'));
  foot.appendChild(el('span', '', nicon('command') + '<span>Ctrl+Shift+P mở bảng lệnh</span>'));
}

/* ==================== static UI wiring ==================== */
let uiWired = false; // reconnect re-runs boot() — listeners must not multiply
function wireStaticUI() {
  if (uiWired) return;
  uiWired = true;
  // icons
  $('#btn-history').innerHTML = nicon('sidebar');
  $('#btn-new').innerHTML = nicon('pencil');
  $('#btn-palette').innerHTML = nicon('command');
  $('#btn-settings').innerHTML = nicon('settings');
  $('#send').innerHTML = nicon('send');
  $('#to-bottom').innerHTML = nicon('chevronDown');
  $('#btn-pause').innerHTML = nicon('pause');
  $('#btn-stop').innerHTML = nicon('stop');
  $('#st-icon').innerHTML = nicon('settings');
  $('#st-close').innerHTML = nicon('x');
  $('#lb-close').innerHTML = nicon('x');
  $('#art-close').innerHTML = nicon('x');
  $('#art-dl').innerHTML = nicon('download');
  $('#btn-new2').innerHTML = nicon('pencil') + ' Chat mới';
  $('#btn-wipe').innerHTML = nicon('trash') + ' Xoá hết';
  $$('.search-wrap .si, .p-input .si').forEach(e => e.innerHTML = nicon('search'));
  $('#sel-chip .sel-ic').innerHTML = nicon('quote');
  $('#sel-chip .sel-x').innerHTML = nicon('x');

  // topbar
  $('#btn-history').onclick = openDrawer;
  $('#btn-new').onclick = () => newConversation();
  $('#btn-palette').onclick = openPalette;
  $('#btn-settings').onclick = () => openSettings('general');
  $('#scrim').onclick = closeDrawer;

  // ctx toggles
  for (const b of $$('#ctx-toggles .ctx-t')) {
    b.onclick = () => saveSettings({ includeContext: { [b.dataset.k]: !S.settings.includeContext[b.dataset.k] } });
  }
  $('#sel-chip .sel-x').onclick = () => { S.selection = null; renderSelection(); };

  // composer
  const ta = input();
  ta.addEventListener('input', autogrow);
  ta.addEventListener('focus', () => $('#composer').classList.add('focus'));
  ta.addEventListener('blur', () => $('#composer').classList.remove('focus'));
  ta.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey && (S.settings?.enterSend !== false)) {
      e.preventDefault();
      sendMessage();
    }
  });
  $('#send').onclick = sendMessage;

  // attachments: picker + drag-drop + paste
  $('#btn-attach').innerHTML = nicon('plus');
  $('#btn-attach').onclick = () => $('#file-input').click();
  $('#file-input').addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; });
  ta.addEventListener('paste', e => {
    const files = [...(e.clipboardData?.files || [])];
    if (files.length) { e.preventDefault(); addFiles(files); }
  });
  const cw = $('#composer-wrap');
  const veil = $('#drop-veil');
  let dragDepth = 0;
  cw.addEventListener('dragenter', e => { e.preventDefault(); dragDepth++; veil.hidden = false; });
  cw.addEventListener('dragover', e => e.preventDefault());
  cw.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; veil.hidden = true; } });
  cw.addEventListener('drop', e => {
    e.preventDefault();
    dragDepth = 0; veil.hidden = true;
    addFiles(e.dataTransfer?.files);
  });

  $('#btn-stop').onclick = () => bridge.cmd('stop', { convId: S.activeConvId }).catch(() => { });
  $('#btn-pause').onclick = () => {
    const paused = S.agentState === 'paused';
    bridge.cmd(paused ? 'resume' : 'pause', { convId: S.activeConvId }).catch(() => { });
  };
  buildModeSeg();
  buildReasonMenu();
  syncReasonUI();
  $('#btn-reason').onclick = e => { e.stopPropagation(); $('#reason-menu').classList.toggle('show'); };
  document.addEventListener('click', e => {
    if (!e.target.closest('#reason-menu') && !e.target.closest('#btn-reason')) $('#reason-menu').classList.remove('show');
  });
  $('#ctx-debug').onclick = () => {
    const tabId = S.tab?.id;
    if (tabId == null) return;
    bridge.cmd('debug_detach', { tabId }).catch(e => toast(e.message, 'err'));
  };

  // scroll
  $('#feed-wrap').addEventListener('scroll', () => {
    userScrolledUp = !nearBottom();
    $('#to-bottom').classList.toggle('show', !nearBottom() && S.feed.size > 0);
  });
  $('#to-bottom').onclick = () => scrollBottom(true);

  // overlays
  $('#st-close').onclick = () => $('#settings-overlay').classList.remove('show');
  $('#settings-overlay').addEventListener('mousedown', e => { if (e.target.id === 'settings-overlay') e.target.classList.remove('show'); });

  // settings: nút "Lưu thay đổi" cố định ở chân modal
  $('#st-save').innerHTML = nicon('check') + ' Lưu thay đổi';
  $('#st-save').onclick = flushSettingsNow;
  syncSaveBar();

  // settings: tab strip cuộn ngang — mũi tên + con lăn chuột
  const stTabs = $('#st-tabs');
  $('#st-tab-prev').innerHTML = nicon('chevronLeft');
  $('#st-tab-next').innerHTML = nicon('chevronRight');
  $('#st-tab-prev').onclick = () => stTabs.scrollBy({ left: -170, behavior: 'smooth' });
  $('#st-tab-next').onclick = () => stTabs.scrollBy({ left: 170, behavior: 'smooth' });
  stTabs.addEventListener('wheel', e => {
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      e.preventDefault();
      stTabs.scrollLeft += e.deltaY; // con lăn dọc → cuộn ngang tab
    }
  }, { passive: false });
  stTabs.addEventListener('scroll', updateTabNav, { passive: true });
  addEventListener('resize', updateTabNav);
  $('#lb-close').onclick = () => $('#lightbox').classList.remove('show');
  $('#lightbox').addEventListener('mousedown', e => { if (e.target.id === 'lightbox') e.target.classList.remove('show'); });
  $('#art-close').onclick = () => $('#art-overlay').classList.remove('show');
  $('#art-overlay').addEventListener('mousedown', e => { if (e.target.id === 'art-overlay') e.target.classList.remove('show'); });
  $('#art-dl').onclick = async () => {
    const id = $('#art-overlay').dataset.artId;
    if (!id) return;
    try {
      const { artifact: art } = await bridge.cmd('get_artifact', { artifactId: id });
      const blob = art.base64
        ? new Blob([b64Bytes(art.base64)], { type: art.mime || 'application/octet-stream' })
        : new Blob([art.text || ''], { type: art.mime || 'text/plain' });
      const u = URL.createObjectURL(blob);
      const a = el('a'); a.href = u; a.download = art.name; a.click();
      setTimeout(() => URL.revokeObjectURL(u), 4000);
    } catch (e) { toast(e.message, 'err'); }
  };

  // palette
  $('#palette-input').addEventListener('input', e => { palSel = 0; renderPalette(e.target.value); });
  $('#palette-input').addEventListener('keydown', e => {
    const acts = $('#palette-list')._acts || [];
    if (e.key === 'ArrowDown') { e.preventDefault(); if (acts.length) { palSel = (palSel + 1) % acts.length; paintPaletteSel(); } }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (acts.length) { palSel = (palSel - 1 + acts.length) % acts.length; paintPaletteSel(); } }
    else if (e.key === 'Enter') { e.preventDefault(); const a = acts[palSel]; if (a) { closePalette(); execPaletteAction(a); } }
    else if (e.key === 'Escape') { e.preventDefault(); closePalette(); }
  });
  $('#palette-overlay').addEventListener('mousedown', e => { if (e.target.id === 'palette-overlay') closePalette(); });

  // drawer
  $('#btn-new2').onclick = () => { closeDrawer(); newConversation(); };
  $('#conv-search').addEventListener('input', renderConvList);
  $('#btn-wipe').onclick = async () => {
    const b = $('#btn-wipe');
    if (b.dataset.arm !== '1') { b.dataset.arm = '1'; b.textContent = 'Nhấn lần nữa để xác nhận'; setTimeout(() => { b.dataset.arm = ''; b.innerHTML = nicon('trash') + ' Xoá hết'; }, 2500); return; }
    await bridge.cmd('clear_conversations');
    await refreshConvs();
    closeDrawer();
    await newConversation();
  };

  // onboarding
  $('#ob-later').onclick = async () => { $('#onboard').classList.remove('show'); bridge.cmd('set_prefs', { onboarded: true }).catch(() => { }); };
  $('#ob-go').onclick = async () => { $('#onboard').classList.remove('show'); bridge.cmd('set_prefs', { onboarded: true }).catch(() => { }); openSettings('providers'); };

  // global keys
  document.addEventListener('keydown', e => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.shiftKey && (e.key === 'P' || e.key === 'p')) { e.preventDefault(); openPalette(); }
    else if (mod && (e.key === 'o' || e.key === 'O')) { e.preventDefault(); S.drawerOpen ? closeDrawer() : openDrawer(); }
    else if (e.key === 'Escape') {
      closePalette(); closeDrawer();
      $('#reason-menu').classList.remove('show');
      $('#settings-overlay').classList.remove('show');
      $('#lightbox').classList.remove('show');
      $('#art-overlay').classList.remove('show');
      $('#onboard').classList.remove('show');
    }
  });

  buildStarters();
}
})();
