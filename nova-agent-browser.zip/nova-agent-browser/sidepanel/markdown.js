/* Nova Agent Browser — minimal markdown renderer (CSP-safe: pure string→DOM,
 * no eval, no raw-HTML passthrough — every text node is escaped).
 * Supports: headings, bold/italic/strike, inline code, fenced code blocks,
 * links, ul/ol (1 level of nesting), blockquote, GFM tables, hr, paragraphs. */
'use strict';
(function () {

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* inline: code, bold, italic, strike, links */
  function inline(src) {
    const codes = [];
    // protect inline code first
    src = src.replace(/`([^`\n]+)`/g, (_, c) => `\u0000${codes.push(c) - 1}\u0000`);
    let out = esc(src);
    out = out
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^_]+)__/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
      .replace(/(^|[^_])_([^_\n]+)_/g, '$1<em>$2</em>')
      .replace(/~~([^~]+)~~/g, '<del>$1</del>');
    out = out.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[+i])}</code>`);
    return out;
  }

  function tableHtml(lines) {
    const rows = lines.map(l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim()));
    const head = rows[0];
    const body = rows.slice(2); // skip align row
    let h = '<div class="table-wrap"><table><thead><tr>' + head.map(c => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
    for (const r of body) h += '<tr>' + r.map(c => `<td>${inline(c)}</td>`).join('') + '</tr>';
    return h + '</tbody></table></div>';
  }

  function listHtml(lines, i0) {
    const isUl = /^[-*•]\s/.test(lines[i0]);
    const tag = isUl ? 'ul' : 'ol';
    let h = `<${tag}>`, i = i0;
    const itemRe = isUl ? /^[-*•]\s+/ : /^\d+[.)]\s+/;
    const subRe = isUl ? /^\s{2,}[-*•]\s+/ : /^\s{2,}\d+[.)]\s+/;
    while (i < lines.length) {
      const l = lines[i];
      if (itemRe.test(l)) {
        h += `<li>${inline(l.replace(itemRe, ''))}`;
        // nested level
        if (i + 1 < lines.length && subRe.test(lines[i + 1])) {
          const sub = [];
          while (i + 1 < lines.length && subRe.test(lines[i + 1])) { sub.push(lines[i + 1].trim()); i++; }
          const nested = listHtml(sub, 0);
          h += nested.html;
        }
        h += '</li>';
        i++;
      } else break;
    }
    return { html: h + `</${tag}>`, next: i };
  }

  /** markdown string → safe HTML string */
  function render(src) {
    src = String(src || '').replace(/\r\n?/g, '\n');
    const lines = src.split('\n');
    let html = '', i = 0;
    let para = [];
    const flushPara = () => {
      if (para.length) { html += `<p>${para.map(inline).join('<br>')}</p>`; para = []; }
    };

    while (i < lines.length) {
      const l = lines[i];

      // fenced code
      const fence = l.match(/^```(\w*)\s*$/);
      if (fence) {
        flushPara();
        const lang = fence[1] || '';
        const buf = [];
        i++;
        while (i < lines.length && !/^```\s*$/.test(lines[i])) buf.push(lines[i++]);
        i++;
        html += `<div class="code-block"><div class="code-head"><span>${esc(lang || 'code')}</span><button type="button" data-copy>${window.nicon('copy')}<span> Sao chép</span></button></div><pre>${esc(buf.join('\n'))}</pre></div>`;
        continue;
      }
      // table
      if (/^\|.*\|\s*$/.test(l) && i + 1 < lines.length && /^\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
        flushPara();
        const buf = [l, lines[i + 1]];
        i += 2;
        while (i < lines.length && /^\|.*\|\s*$/.test(lines[i])) buf.push(lines[i++]);
        html += tableHtml(buf);
        continue;
      }
      // heading
      const h = l.match(/^(#{1,4})\s+(.*)$/);
      if (h) { flushPara(); html += `<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`; i++; continue; }
      // hr
      if (/^\s*(---|\*\*\*|___)\s*$/.test(l)) { flushPara(); html += '<hr>'; i++; continue; }
      // blockquote
      if (/^>\s?/.test(l)) {
        flushPara();
        const buf = [];
        while (i < lines.length && /^>\s?/.test(lines[i])) buf.push(lines[i++].replace(/^>\s?/, ''));
        html += `<blockquote>${render(buf.join('\n'))}</blockquote>`;
        continue;
      }
      // list
      if (/^([-*•]|\d+[.)])\s+/.test(l)) {
        flushPara();
        const r = listHtml(lines, i);
        html += r.html; i = r.next;
        continue;
      }
      // blank
      if (!l.trim()) { flushPara(); i++; continue; }
      para.push(l);
      i++;
    }
    flushPara();
    return html;
  }

  /** render into an element (also wires copy buttons) */
  function renderInto(el, src) {
    el.classList.add('md');
    el.innerHTML = render(src);
    for (const btn of el.querySelectorAll('[data-copy]')) {
      btn.addEventListener('click', () => {
        const code = btn.closest('.code-block')?.querySelector('pre')?.textContent || '';
        navigator.clipboard.writeText(code).then(() => {
          const s = btn.querySelector('span');
          if (s) { const t = s.textContent; s.textContent = ' Đã chép'; setTimeout(() => s.textContent = t, 1200); }
        });
      });
    }
  }

  window.NM = { render, renderInto };
})();
