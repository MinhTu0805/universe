/* Nova Agent Browser — mock backend for UI development.
 * Activates ONLY when the panel is opened outside the extension
 * (no chrome.runtime.id) — e.g. file:// or a plain HTTP server.
 * Simulates the service worker: state, events, a scripted agent run
 * with tools, terminal streaming, approval, screenshot and artifact. */
'use strict';
window.NovaMock = (() => {
  const available = !(typeof chrome !== 'undefined' && chrome.runtime?.id);

  const DEFAULT_SETTINGS = {
    defaultMode: 'agent', autonomy: 'assisted', showActionOverlay: true, edgeLightning: true, showStatusBadge: true,
    showTimeline: true, autoTitle: true, enterSend: true, actionDelay: 'fast', maxSteps: 40, maxRetries: 2,
    maxRuntimeMin: 15, maxScreenshots: 24, visionQuality: 'balanced', verification: 'standard', recovery: 'standard',
    visionFallback: true, stream: true, temperature: 0.4, maxTokens: 4096,
    reasoningEffort: 'off', debuggerEnabled: false,
    terminalEnabled: false, terminalPolicy: 'ask-risky', terminalTimeout: 60, workspace: '~/nova-agent',
    toolPerms: { browser: 'allowed', screenshots: 'allowed', vision: 'allowed', downloads: 'ask', uploads: 'ask', files: 'allowed', terminal: 'ask', multitab: 'allowed', canvas: 'allowed', research: 'allowed', scripts: 'ask', cdp: 'ask' },
    includeContext: { page: true, screenshot: false, dom: true, a11y: true, selection: true },
    theme: 'light', accent: 'mono', fontSize: 15, debug: false,
  };
  const PRESETS = {
    openai: { name: 'OpenAI', base: 'https://api.openai.com/v1', model: 'gpt-4o-mini', vision: 'gpt-4o', keyUrl: 'https://platform.openai.com/api-keys' },
    anthropic: { name: 'Anthropic', base: 'https://api.anthropic.com', model: 'claude-sonnet-4-5', vision: 'claude-sonnet-4-5', keyUrl: 'https://console.anthropic.com/settings/keys' },
    gemini: { name: 'Google Gemini', base: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-2.0-flash', vision: 'gemini-2.0-flash', keyUrl: 'https://aistudio.google.com/app/apikey' },
    ollama: { name: 'Ollama (local)', base: 'http://localhost:11434/v1', model: 'llama3.2', vision: '', noKey: true, note: 'Chạy local — không cần API key' },
    custom: { name: 'Custom (OpenAI-compatible)', base: '', model: '', vision: '', note: 'Endpoint bất kỳ tương thích OpenAI' },
  };

  function bridge() {
    const listeners = new Set();
    const emit = (event, data) => listeners.forEach(f => { try { f(event, data); } catch (e) { } });
    let seq = 0;
    const uid = () => 'm' + (++seq).toString(36) + Date.now().toString(36);

    const settings = structuredClone(DEFAULT_SETTINGS);
    const providers = { active: 'openai', fallback: null, fallbackEnabled: true, configs: {} };
    const usage = { input: 12840, output: 3120, calls: 17, byProvider: {} };
    const prefs = { onboarded: true };
    const convs = new Map();
    let order = [];
    let activeConvId = null;
    let stopped = false;

    const convList = () => order.map(id => convs.get(id)).filter(Boolean).map(c => ({
      id: c.id, title: c.title, updatedAt: c.updatedAt, createdAt: c.createdAt, status: c.status, mode: c.mode,
      usage: c.usage, agent: c.agent, feedCount: c.feed.length, artifacts: c.artifacts.length,
    }));

    function newConv(mode = 'agent') {
      const c = {
        id: uid(), title: 'Cuộc trò chuyện mới', createdAt: Date.now(), updatedAt: Date.now(),
        mode, status: 'idle', feed: [], artifacts: [], usage: { input: 0, output: 0, calls: 0 },
        agent: { state: 'idle', steps: 0 },
      };
      convs.set(c.id, c);
      order = [c.id, ...order];
      return c;
    }
    function feed(c, item) {
      const full = { id: uid(), ts: Date.now(), ...item };
      const i = c.feed.findIndex(x => x.id === full.id);
      if (i >= 0) c.feed[i] = { ...c.feed[i], ...full }; else c.feed.push(full);
      emit('FEED_ITEM', { convId: c.id, item: full });
      return full;
    }
    function feedUpd(c, id, patch) {
      const it = c.feed.find(x => x.id === id);
      if (it) Object.assign(it, patch);
      emit('FEED_ITEM', { convId: c.id, item: { id, ...patch } });
    }
    function state(c, s, extra = {}) {
      c.agent = { ...c.agent, state: s, ...extra };
      emit('AGENT_STATE_CHANGED', { convId: c.id, state: s, ...extra });
    }

    /* fake screenshot: draw a mini "web page" on a canvas */
    function fakeShot() {
      const cv = document.createElement('canvas');
      cv.width = 800; cv.height = 500;
      const g = cv.getContext('2d');
      g.fillStyle = '#181818'; g.fillRect(0, 0, 800, 500);
      g.fillStyle = '#222'; g.fillRect(0, 0, 800, 44);
      g.fillStyle = '#333'; g.fillRect(16, 14, 220, 16);
      g.fillStyle = '#fff'; g.font = '600 26px Inter, sans-serif'; g.fillText('Example Domain', 40, 110);
      g.fillStyle = '#999'; g.font = '15px Inter, sans-serif';
      g.fillText('This is a simulated screenshot produced by mock mode.', 40, 145);
      g.fillText('Inside the real extension, this comes from chrome.tabs.captureVisibleTab.', 40, 170);
      g.strokeStyle = '#555'; g.strokeRect(40, 210, 300, 40);
      g.fillStyle = '#777'; g.fillText('input field', 54, 235);
      g.fillStyle = '#e8e8e8'; g.fillRect(40, 270, 120, 38);
      g.fillStyle = '#111'; g.font = '600 14px Inter, sans-serif'; g.fillText('Submit', 74, 294);
      return cv.toDataURL('image/png');
    }
    let shotData = null;

    async function simulate(c, text, mode, attachments) {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      stopped = false;
      const guard = () => !stopped;
      feed(c, {
        t: 'user', text,
        attachments: attachments?.length ? attachments.map(a => ({ name: a.name, mime: a.mime, size: a.size, kind: a.kind })) : undefined,
      });
      c.title = text.split(/\s+/).slice(0, 6).join(' ');
      emit('CONVERSATIONS_CHANGED', {});
      state(c, 'observing');
      await wait(500); if (!guard()) return;

      // cả Ask lẫn Agent đều quan sát trang — Ask dừng ở đọc, Agent thao tác tiếp
      {
        // 1. navigate tool
        const t1 = feed(c, { t: 'tool', name: 'browser_get_page_info', label: location.href || 'mock page', status: 'running', input: '{}' });
        state(c, 'observing', { step: 1 });
        await wait(650); if (!guard()) return;
        feedUpd(c, t1.id, { status: 'success', output: '{"url":"https://example.com","title":"Example Domain","viewport":{"w":1280,"h":800}}', duration: 640 });

        // 2. screenshot
        state(c, 'observing', { step: 2 });
        const t2 = feed(c, { t: 'tool', name: 'browser_screenshot', label: 'chụp màn hình', status: 'running', input: '{}' });
        await wait(800); if (!guard()) return;
        feedUpd(c, t2.id, { status: 'success', output: '{"shotId":"mockshot","width":1280,"height":800}', duration: 790 });
        feed(c, { t: 'shot', shotId: 'mockshot', caption: 'browser_screenshot · 1280×800' });

        // 3. click (chỉ Agent — Ask là chế độ chỉ-đọc)
        if (mode === 'agent') {
          state(c, 'acting', { step: 3 });
          const t3 = feed(c, { t: 'tool', name: 'browser_click', label: '"More information..."', status: 'running', input: '{"text":"More information..."}' });
          await wait(700); if (!guard()) return;
          feedUpd(c, t3.id, { status: 'success', output: '{"clicked":true,"after":{"changed":true}}', duration: 410 });
        }
      }

      if (text.toLowerCase().includes('terminal') || text.toLowerCase().includes('lệnh')) {
        state(c, 'acting');
        const term = feed(c, { t: 'terminal', name: 'terminal_execute', label: 'ls -la ~/nova-agent', status: 'running', command: 'ls -la ~/nova-agent', input: '{"command":"ls -la ~/nova-agent"}' });
        const lines = ['total 24', 'drwxr-xr-x  5 user staff  160 Oct  6 10:00 .', 'drwx------+ 82 user staff 2624 Oct  6 09:58 ..', '-rw-r--r--  1 user staff  312 Oct  6 10:00 notes.md', '-rw-r--r--  1 user staff 1822 Oct  6 10:00 report.csv'];
        let out = '';
        for (const l of lines) {
          await wait(240); if (!guard()) return;
          out += l + '\n';
          feedUpd(c, term.id, { output: out });
        }
        feedUpd(c, term.id, { status: 'success', exitCode: 0, duration: 1240 });
      }

      if (mode === 'agent') {
        // approval
        state(c, 'awaiting_approval');
        const ap = feed(c, { t: 'approval', title: 'Nova muốn gửi form', detail: 'browser_submit → form#contact\nhttps://example.com/contact', risk: 'high', status: 'pending', tool: 'browser_submit' });
        await new Promise(res => {
          approvals.set(ap.id, res);
          if (new URLSearchParams(location.search).get('demo') === 'approve') setTimeout(() => { feedUpd(c, ap.id, { status: 'approved' }); res(true); }, 1500);
        });
        if (!guard()) return;
        state(c, 'acting');
        const t4 = feed(c, { t: 'tool', name: 'browser_submit', label: 'form#contact', status: 'running', input: '{"selector":"form#contact"}' });
        await wait(600); if (!guard()) return;
        feedUpd(c, t4.id, { status: 'success', output: '{"submitted":true}', duration: 380 });

        // artifact
        const art = { id: uid(), name: 'ket-qua.md', mime: 'text/markdown', text: '# Kết quả\n\nNova đã hoàn thành task trong **mock mode**.\n\n- Quan sát trang\n- Chụp màn hình\n- Click + submit (được phê duyệt)\n', size: 160 };
        artifacts.set(art.id, art);
        feed(c, { t: 'artifact', artifactId: art.id, name: art.name, mime: art.mime, size: art.size });
      }

      // final streaming answer
      state(c, 'thinking', { step: 4 });
      const ai = feed(c, { t: 'ai', md: '', done: false });
      const full = mode === 'ask'
        ? 'Đây là câu trả lời **chỉ-đọc** của chế độ Ask (mock mode).\n\nTrong extension thật, tôi đọc trang qua DOM/accessibility tree/ảnh chụp rồi trả lời — không bao giờ click hay gõ. Muốn tôi tự thao tác thì chuyển sang chế độ **Agent** nhé.'
        : '## Tóm tắt task\n\nĐã hoàn thành các bước mô phỏng:\n\n- Quan sát trang và chụp màn hình\n- Thao tác (click' + (text.toLowerCase().includes('lệnh') || text.toLowerCase().includes('terminal') ? ', chạy lệnh shell' : '') + ')\n- ' + 'Xin phê duyệt hành động rủi ro\n\n*Mock mode — kết nối extension thật để chạy với LLM.*';
      let acc = '';
      for (const ch of full) {
        await wait(8); if (!guard()) return;
        acc += ch;
        emit('STREAM_DELTA', { convId: c.id, id: ai.id, md: acc });
      }
      feedUpd(c, ai.id, { done: true });
      feed(c, { t: 'note', kind: 'ok', text: 'Task hoàn thành · 4 actions · 00:06 · 1.2k tokens' });
      state(c, 'completed');
    }

    const approvals = new Map();
    const artifacts = new Map();

    const api = {
      isMock: true,
      onEvent: fn => { listeners.add(fn); return () => listeners.delete(fn); },
      onReconnect: () => { },
      async cmd(cmd, data = {}) {
        const wait = ms => new Promise(r => setTimeout(r, ms));
        await wait(60);
        switch (cmd) {
          case 'get_state': {
            if (!convs.size) { const c = newConv(); activeConvId = c.id; }
            return {
              settings, providers: maskProviders(), providerPresets: PRESETS,
              conversations: convList(), activeConvId, usage, prefs, pendingAction: null, toolsCount: 75,
              debugTabs: [],
            };
          }
          case 'get_conversation': return { conversation: convs.get(data.convId) };
          case 'new_conversation': { const c = newConv(data.mode); activeConvId = c.id; emit('CONVERSATIONS_CHANGED', {}); return { conversation: c }; }
          case 'set_active_conv': activeConvId = data.convId; return { ok: true };
          case 'delete_conversation': { convs.delete(data.convId); order = order.filter(x => x !== data.convId); emit('CONVERSATIONS_CHANGED', {}); return { ok: true }; }
          case 'clear_conversations': { convs.clear(); order = []; emit('CONVERSATIONS_CHANGED', {}); return { ok: true }; }
          case 'update_settings': { deepMerge(settings, data.patch || {}); emit('SETTINGS_CHANGED', { settings }); return { settings }; }
          case 'flush_settings': return { settings, savedAt: Date.now() };
          case 'set_prefs': Object.assign(prefs, data.patch || {}); return { prefs };
          case 'set_provider': {
            const cur = providers.configs[data.id] || {};
            providers.configs[data.id] = { ...cur, ...data.cfg };
            return { providers: maskProviders() };
          }
          case 'set_active_provider': {
            providers.active = data.id;
            if (data.fallback !== undefined) providers.fallback = data.fallback;
            if (data.fallbackEnabled !== undefined) providers.fallbackEnabled = data.fallbackEnabled;
            return { providers: maskProviders() };
          }
          case 'test_provider': await wait(700); return { ok: true, model: providers.configs[data.id]?.model || PRESETS[data.id]?.model || 'mock-model', latencyMs: 680 };
          case 'list_models': return { models: ['mock-1', 'mock-2'] };
          case 'set_conversation_mode': {
            const c = convs.get(data.convId);
            if (!c) return { ok: false, error: 'conversation không tồn tại (mock)' };
            if (['running', 'paused', 'thinking', 'acting'].includes(c.agent?.state)) return { ok: false, error: 'agent đang chạy (mock)' };
            c.mode = data.mode; emit('CONVERSATIONS_CHANGED', {}); return { ok: true };
          }
          case 'terminal_status': return { installed: false, info: null, error: 'mock mode — no native host' };
          case 'debug_detach': emit('DEBUGGER_CHANGED', { tabId: data.tabId, attached: false }); return { debugTabs: [] };
          case 'get_shot': { shotData ||= fakeShot(); return { shot: { dataUrl: shotData, meta: {} } }; }
          case 'get_artifact': { const a = artifacts.get(data.artifactId); if (!a) throw new Error('artifact not found'); return { artifact: a }; }
          case 'list_tools': return { groups: {}, total: 75 };
          case 'wipe_all': convs.clear(); order = []; return { ok: true };
          case 'stop': { stopped = true; const c = convs.get(data.convId); if (c) state(c, 'stopped'); return { ok: true }; }
          case 'pause': { const c = convs.get(data.convId); if (c) state(c, 'paused'); return { ok: true }; }
          case 'resume': { const c = convs.get(data.convId); if (c) state(c, 'acting'); return { ok: true }; }
          case 'approval_response': { const r = approvals.get(data.approvalId); approvals.delete(data.approvalId); r?.(data.ok); for (const [, res] of approvals) res(data.ok); approvals.clear(); return { ok: true }; }
          case 'ask_response': return { ok: true };
          case 'run_task': {
            const c = convs.get(data.convId) || newConv(data.mode);
            simulate(c, data.text, data.mode, data.attachments).catch(console.error);
            return { ok: true };
          }
          default: throw new Error('mock: unknown cmd ' + cmd);
        }
      },
    };
    function maskProviders() {
      const configs = {};
      for (const [id, cfg] of Object.entries(providers.configs)) {
        configs[id] = { base: cfg.base, model: cfg.model, visionModel: cfg.visionModel, hasKey: !!cfg.apiKey, keyPreview: cfg.apiKey ? '•••' + cfg.apiKey.slice(-4) : null };
      }
      return { active: providers.active, fallback: providers.fallback, fallbackEnabled: providers.fallbackEnabled, configs };
    }
    function deepMerge(a, b) { for (const [k, v] of Object.entries(b || {})) { a[k] = (v && typeof v === 'object' && !Array.isArray(v) && typeof a[k] === 'object') ? deepMerge(a[k], v) : v; } return a; }
    return api;
  }

  return { available, bridge };
})();
