/* Nova Agent Browser — Thinking Orb.
 * Vanilla-canvas port of the "thinking-orbs" concept (libraries.dev/orbs):
 * replaces the spinner in AI thinking states with nine hand-tuned animated
 * states. Zero dependencies, CSP-safe (no external fetch, no eval).
 *
 * Usage:
 *   const orb = NovaOrb.create({ state: 'working', size: 20, speed: 1, dark: true, paused: false });
 *   hostElement.appendChild(orb.el);
 *   orb.setState('searching'); orb.setPaused(true); orb.setSpeed(1.4); orb.destroy();
 *
 * States: working | searching | solving | listening | connecting |
 *         weaving | composing | breathing | shaping
 * Sizes : 64 (chat-avatar scale) and 20 (inline-text scale) are separately
 *         tuned; any other number gets interpolated tuning.
 */
'use strict';
window.NovaOrb = (() => {

  const STATES = new Set(['working', 'searching', 'solving', 'listening', 'connecting', 'weaving', 'composing', 'breathing', 'shaping']);

  /* Per-state tuning. Each profile drives the shared renderer:
   *   core      — base core radius (fraction of R)
   *   pulse     — core pulse amplitude/speed
   *   glow      — halo strength 0..1
   *   ring      — dashed ring {on, segs, gap, width, rot} rot = rad/s
   *   dots      — orbiting particles {n, rMin, rMax, speed, size, wobble}
   *   sweep     — radar wedge {on, rot, span, fade}
   *   ripples   — expanding rings {on, n, speed}
   *   links     — connect nearby dots {on, dist}
   *   bands     — crossing sine ribbons {on, n, amp, speed}
   *   rise      — rising motes {on, n, speed}
   *   morph     — blob edge wobble {on, amp, lobes, speed}
   *   breathe   — whole-orb scale osc {on, amp, speed}
   */
  const PROFILES = {
    working: {
      core: .30, pulse: [.05, 2.2], glow: .85,
      ring: { on: 1, segs: 1, gap: 1.05, width: .085, rot: 2.4 },
      dots: { n: 3, rMin: .62, rMax: .72, speed: 1.6, size: .075, wobble: .02 },
    },
    searching: {
      core: .26, pulse: [.03, 1.6], glow: .6,
      ring: { on: 1, segs: 2, gap: 2.6, width: .06, rot: -.5 },
      sweep: { on: 1, rot: 1.9, span: .9, fade: 1 },
      ripples: { on: 1, n: 2, speed: .55 },
    },
    solving: {
      core: .28, pulse: [.04, 1.9], glow: .7,
      // segments breathe between broken and (almost) closed ring
      ring: { on: 1, segs: 4, gap: 2.2, width: .08, rot: 1.1, converge: .85 },
      dots: { n: 2, rMin: .66, rMax: .66, speed: -1.2, size: .07, wobble: 0 },
    },
    listening: {
      core: .24, pulse: [.10, 1.1], glow: .65,
      ripples: { on: 1, n: 3, speed: .8 },
      breathe: { on: 1, amp: .03, speed: 1.1 },
    },
    connecting: {
      core: .22, pulse: [.03, 1.4], glow: .55,
      dots: { n: 5, rMin: .38, rMax: .8, speed: .9, size: .062, wobble: .05 },
      links: { on: 1, dist: .72 },
    },
    weaving: {
      core: .24, pulse: [.04, 1.7], glow: .6,
      bands: { on: 1, n: 2, amp: .30, speed: 1.5 },
      dots: { n: 2, rMin: .55, rMax: .7, speed: .8, size: .055, wobble: .03 },
    },
    composing: {
      core: .26, pulse: [.06, 2.6], glow: .7,
      rise: { on: 1, n: 5, speed: .5 },
      ring: { on: 1, segs: 3, gap: 1.9, width: .05, rot: .7 },
    },
    breathing: {
      core: .34, pulse: [.02, .8], glow: .8,
      breathe: { on: 1, amp: .10, speed: .75 },
      ring: { on: 1, segs: 1, gap: 6.28, width: .045, rot: .25 },
    },
    shaping: {
      core: .30, pulse: [.03, 1.5], glow: .75,
      morph: { on: 1, amp: .09, lobes: 3, speed: 1.4 },
      dots: { n: 3, rMin: .6, rMax: .78, speed: 1.1, size: .06, wobble: .04 },
    },
  };

  /* Inline scale (≤28px) strips noise so the orb reads at favicon size. */
  function tuned(state, px) {
    const p = structuredClone(PROFILES[state] || PROFILES.working);
    if (px <= 28) {
      if (p.dots) p.dots.n = Math.min(p.dots.n, 3);
      if (p.ripples) p.ripples.n = Math.min(p.ripples.n, 2);
      if (p.rise) p.rise.n = 3;
      if (p.links && p.dots) p.dots.n = 4;
      if (p.ring) p.ring.width = Math.max(p.ring.width, .075);
    }
    return p;
  }

  const TAU = Math.PI * 2;

  class Orb {
    constructor(opts = {}) {
      this.state = STATES.has(opts.state) ? opts.state : 'working';
      this.size = opts.size === 64 ? 64 : (opts.size || 20);
      this.speed = opts.speed ?? 1;
      this.dark = opts.dark ?? (document.documentElement.dataset.theme !== 'light');
      this.paused = !!opts.paused;
      this.t = Math.random() * 100; // desync multiple orbs
      this.el = document.createElement('span');
      this.el.className = 'nova-orb';
      this.el.style.cssText = `display:inline-block;width:${this.size}px;height:${this.size}px;flex:0 0 auto;vertical-align:middle`;
      this.cv = document.createElement('canvas');
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      this.cv.width = this.size * dpr;
      this.cv.height = this.size * dpr;
      this.cv.style.width = this.cv.style.height = this.size + 'px';
      this.el.appendChild(this.cv);
      this.g = this.cv.getContext('2d');
      this.dpr = dpr;
      this._raf = null;
      this._last = 0;
      this._onVis = () => { if (!document.hidden) this._kick(); };
      document.addEventListener('visibilitychange', this._onVis);
      this._kick();
    }

    setState(s) { if (STATES.has(s) && s !== this.state) { this.state = s; this._kick(); } }
    setSpeed(v) { this.speed = Math.max(.1, +v || 1); }
    setDark(v) { this.dark = !!v; this._draw(); }
    setPaused(v) { this.paused = !!v; this._kick(); }
    destroy() {
      cancelAnimationFrame(this._raf);
      document.removeEventListener('visibilitychange', this._onVis);
      this.el.remove();
    }

    _kick() {
      if (this._raf || this.paused || document.hidden) { if (this.paused) this._draw(); return; }
      this._last = performance.now();
      const loop = (now) => {
        this._raf = null;
        const dt = Math.min(.05, (now - this._last) / 1000);
        this._last = now;
        if (!this.paused && !document.hidden) this.t += dt * this.speed;
        this._draw();
        if (!this.paused) this._raf = requestAnimationFrame(loop);
      };
      this._raf = requestAnimationFrame(loop);
    }

    _draw() {
      const g = this.g, S = this.size * this.dpr, R = S / 2;
      const p = tuned(this.state, this.size);
      const t = this.t;
      const fg = getComputedStyle(document.documentElement).getPropertyValue(this.dark ? '--ac' : '--ac').trim() || (this.dark ? '#fff' : '#222');
      g.clearRect(0, 0, S, S);
      g.save();
      g.translate(R, R);
      if (this.dark) g.globalCompositeOperation = 'lighter';

      let scale = 1;
      if (p.breathe?.on) scale += Math.sin(t * p.breathe.speed * TAU / 2) * p.breathe.amp;
      g.scale(scale, scale);
      const r = R * .92;

      /* halo */
      const pulse = 1 + Math.sin(t * (p.pulse?.[1] || 1.5)) * (p.pulse?.[0] || 0);
      const halo = g.createRadialGradient(0, 0, 0, 0, 0, r);
      const ha = .16 * (p.glow ?? .6);
      halo.addColorStop(0, fgA(fg, this.dark ? ha : ha * .8));
      halo.addColorStop(.55, fgA(fg, ha * .45));
      halo.addColorStop(1, fgA(fg, 0));
      g.fillStyle = halo;
      g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();

      /* expanding ripples */
      if (p.ripples?.on) {
        for (let i = 0; i < p.ripples.n; i++) {
          const ph = (t * p.ripples.speed + i / p.ripples.n) % 1;
          g.beginPath();
          g.arc(0, 0, r * (.3 + .62 * ph), 0, TAU);
          g.strokeStyle = fgA(fg, (1 - ph) * .34);
          g.lineWidth = Math.max(1, r * .028 * (1 - ph));
          g.stroke();
        }
      }

      /* radar sweep */
      if (p.sweep?.on) {
        const a0 = t * p.sweep.rot;
        const grad = g.createConicGradient ? g.createConicGradient(a0, 0, 0) : null;
        if (grad) {
          grad.addColorStop(0, fgA(fg, .34));
          grad.addColorStop(p.sweep.span / TAU, fgA(fg, 0));
          grad.addColorStop(1, fgA(fg, 0));
          g.fillStyle = grad;
          g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, r * .86, 0, TAU); g.fill();
        } else {
          g.save(); g.rotate(a0);
          g.fillStyle = fgA(fg, .22);
          g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, r * .86, -.35, .35); g.closePath(); g.fill();
          g.restore();
        }
      }

      /* sine bands */
      if (p.bands?.on) {
        for (let b = 0; b < p.bands.n; b++) {
          const ph = t * p.bands.speed + b * Math.PI;
          g.beginPath();
          for (let x = -1; x <= 1.001; x += .08) {
            const y = Math.sin(x * Math.PI * 1.6 + ph) * p.bands.amp;
            const px = x * r * .8, py = y * r;
            x <= -1 + .001 ? g.moveTo(px, py) : g.lineTo(px, py);
          }
          g.strokeStyle = fgA(fg, .4 - b * .12);
          g.lineWidth = Math.max(1, r * .045);
          g.lineCap = 'round';
          g.stroke();
        }
      }

      /* morph blob ring */
      if (p.morph?.on) {
        g.beginPath();
        for (let a = 0; a <= TAU + .01; a += .12) {
          const rr = r * .68 * (1 + p.morph.amp * Math.sin(a * p.morph.lobes + t * p.morph.speed * TAU / 2));
          const px = Math.cos(a) * rr, py = Math.sin(a) * rr;
          a === 0 ? g.moveTo(px, py) : g.lineTo(px, py);
        }
        g.closePath();
        g.strokeStyle = fgA(fg, .5);
        g.lineWidth = Math.max(1, r * .05);
        g.stroke();
      }

      /* segmented ring */
      if (p.ring?.on) {
        const segN = p.ring.segs;
        let gap = p.ring.gap;
        if (p.ring.converge) gap *= .5 + .5 * Math.abs(Math.sin(t * .9)); // close & reopen
        const segArc = (TAU - gap * (gap >= TAU ? 0 : segN)) / segN;
        g.save();
        g.rotate(t * p.ring.rot);
        g.strokeStyle = fgA(fg, .62);
        g.lineWidth = Math.max(1.2, r * p.ring.width);
        g.lineCap = 'round';
        for (let i = 0; i < segN; i++) {
          const a0 = i * (segArc + (gap >= TAU ? 0 : gap));
          g.beginPath();
          g.arc(0, 0, r * .78, a0, a0 + Math.max(.05, segArc));
          g.stroke();
        }
        g.restore();
      }

      /* orbiting dots (+ links) */
      let dotXY = [];
      if (p.dots?.n) {
        for (let i = 0; i < p.dots.n; i++) {
          const ang = t * p.dots.speed * TAU / 2 + (i / p.dots.n) * TAU;
          const rr = r * (p.dots.rMin + (p.dots.rMax - p.dots.rMin) * ((i * 0.618) % 1))
            * (1 + (p.dots.wobble || 0) * Math.sin(t * 3 + i * 2.1));
          dotXY.push([Math.cos(ang) * rr, Math.sin(ang) * rr]);
        }
        if (p.links?.on) {
          for (let i = 0; i < dotXY.length; i++) for (let j = i + 1; j < dotXY.length; j++) {
            const d = Math.hypot(dotXY[i][0] - dotXY[j][0], dotXY[i][1] - dotXY[j][1]);
            if (d < r * p.links.dist * 2) {
              g.beginPath();
              g.moveTo(dotXY[i][0], dotXY[i][1]);
              g.lineTo(dotXY[j][0], dotXY[j][1]);
              g.strokeStyle = fgA(fg, .3 * (1 - d / (r * p.links.dist * 2)));
              g.lineWidth = Math.max(.8, r * .02);
              g.stroke();
            }
          }
        }
        for (const [x, y] of dotXY) {
          g.beginPath();
          g.arc(x, y, Math.max(1, r * p.dots.size), 0, TAU);
          g.fillStyle = fgA(fg, .85);
          g.fill();
        }
      }

      /* rising motes */
      if (p.rise?.on) {
        for (let i = 0; i < p.rise.n; i++) {
          const ph = (t * p.rise.speed + i * .37) % 1;
          const x = Math.sin(i * 12.9898) * r * .38;
          const y = r * .55 - ph * r * 1.1;
          g.beginPath();
          g.arc(x, y, Math.max(.8, r * .035 * (1 - ph * .5)), 0, TAU);
          g.fillStyle = fgA(fg, (1 - ph) * .5);
          g.fill();
        }
      }

      /* core */
      const cr = r * p.core * pulse;
      const cg = g.createRadialGradient(0, 0, 0, 0, 0, cr * 1.9);
      cg.addColorStop(0, fgA(fg, this.dark ? .95 : .85));
      cg.addColorStop(.55, fgA(fg, .5));
      cg.addColorStop(1, fgA(fg, 0));
      g.fillStyle = cg;
      g.beginPath(); g.arc(0, 0, cr * 1.9, 0, TAU); g.fill();
      g.fillStyle = fgA(fg, this.dark ? 1 : .92);
      g.beginPath(); g.arc(0, 0, cr, 0, TAU); g.fill();

      g.restore();
    }
  }

  /* css color → rgba string with alpha (accepts oklch/hex/rgb via canvas) */
  function fgA(color, a) {
    const cv = fgA._cv || (fgA._cv = document.createElement('canvas').getContext('2d'));
    cv.fillStyle = color;
    const parsed = cv.fillStyle; // normalized
    if (parsed.startsWith('#')) {
      const h = parsed.slice(1);
      const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h.slice(0, 6), 16);
      return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
    }
    if (parsed.startsWith('rgba')) return parsed.replace(/[\d.]+\)$/, a + ')');
    if (parsed.startsWith('rgb')) return parsed.replace('rgb(', 'rgba(').replace(')', ',' + a + ')');
    // oklch / color() etc. — canvas keeps it as-is; wrap with color-mix fallback
    return `color-mix(in oklch, ${parsed} ${Math.round(a * 100)}%, transparent)`;
  }

  return {
    STATES: [...STATES],
    create: opts => new Orb(opts),
  };
})();
